# Aster 0.8.0 · r188 全蓝图、接口与参数审计

> 登记合同不等于完成迁移。只有真实可调用、方法核验和行为测试都通过，才可写 `implemented`；`partial` 不计完成。

## 结论

- 找到并核对 6 份蓝图文件；F3 早期稿已由 v1.4 取代。
- r188 成品边界共 83 个模块；Aster 合同注册 83/83，遗漏 0。
- 当前 Aster 运行模块 34 个；r188 对应项为 partial 35、pending 48，不宣称 83 模块已迁移。
- 跨书接口 19 份；当前方法核验 ready 7 份。
- 已注册参数 62 个；每项均有 type/scope/default，完整清单见下文与 JSON 报告。

## 蓝图真源

| 文件 | 权威状态 | 行 | 字节 | SHA-256 |
|---|---|---:|---:|---|
| Vic-vNext-02-功能书蓝图-v2.md | `authoritative_function` | 1984 | 106632 | `3de7327bc2b5862e…` |
| Vic-vNext-03-F3叙事链研究蓝图-v1.4.md | `authoritative_f3` | 895 | 89226 | `8b2f00e07d576d5d…` |
| Vic-vNext-03-F3叙事链研究蓝图.md | `superseded_by_v1.4` | 73 | 4401 | `ca8c4cd2f9550e43…` |
| Vic-vNext-04-F4初始化与回复蓝图-v1.0.md | `authoritative_f4` | 170 | 10353 | `7b059c91aa398285…` |
| Vic-vNext-05-图鉴书蓝图-v1.0.md | `authoritative_repository` | 205 | 13434 | `b9362e6dc10a9fdd…` |
| Vic-vNext-06-系统与皮肤蓝图-v1.0.md | `authoritative_system_skin` | 72 | 5609 | `ef35839e9cd5e260…` |

## 83 模块边界登记

| 书 | r188 数量 |
|---|---:|
| 功能 | 28 |
| 图鉴 | 11 |
| 核心 | 19 |
| 皮肤 | 8 |
| 系统 | 17 |

Aster 在 Core 中保存源 ID、所属书、order、蓝图来源、当前覆盖度和目标模块。pending 项调用 `Aster.contractAudit.require(id)` 会明确失败，不会返回空对象或伪成功。

## 跨书接口

| Aster 合同 | 版本 | 覆盖 | 方法核验 | 必需方法 |
|---|---|---|---|---|
| `repository.project` | `aster.repository/v2` | **pending** | not ready | `list`, `load`, `getRevision`, `queryRecords`, `promote` |
| `repository.save` | `aster.repository/v2` | **pending** | not ready | `list`, `create`, `load`, `applyTransaction`, `findReceipt`, `readback`, `rename`, `export` |
| `repository.resource` | `aster.repository/v2` | **implemented** | ready | `index`, `exists`, `load`, `store`, `getUrl`, `verify`, `mirror` |
| `repository.messageProjection` | `aster.repository/v2` | **pending** | not ready | `load`, `setViewRefs`, `replaceViewRefs` |
| `capability.port` | `aster.capability/v2` | **pending** | not ready | `probe`, `invoke`, `abort` |
| `narrative.queue` | `aster.narrative.queue/v2` | **pending** | not ready | `enqueuePlan`, `injectPlan`, `protocolPlan`, `selectForFrame`, `get` |
| `narrative.frame` | `aster.narrative.frame/v2` | **pending** | not ready | `assemble`, `stats`, `assertFresh` |
| `narrative.publisher` | `aster.narrative.publisher/v2` | **pending** | not ready | `ensureFresh`, `get`, `markDirty`, `assertCapacity` |
| `protocol.parser` | `aster.protocol/v2` | **pending** | not ready | `extract`, `parse`, `parseUpdate`, `visibleCount` |
| `protocol.coordinator` | `aster.protocol.coordinator/v2` | **pending** | not ready | `propose`, `accept`, `discard`, `project`, `status` |
| `prompt.bridge` | `aster.prompt.bridge/v2` | **pending** | not ready | `refresh`, `current`, `select`, `parse` |
| `search.evidence` | `aster.search.evidence/v1` | **pending** | not ready | `registerAdapter`, `search`, `cancel`, `current`, `forFrame` |
| `outline.workbench` | `aster.outline.workbench/v1` | **pending** | not ready | `basis`, `create`, `generate`, `get`, `list`, `accept`, `cancel` |
| `ui.preferences` | `aster.ui.preferences/v1` | **partial** | ready | `get`, `set`, `reset`, `list` |
| `ui.preferenceSlots` | `aster.ui.preference-slots/v1` | **implemented** | ready | `stamp`, `explain`, `schema`, `refresh`, `parameterId` |
| `ui.resourceSlots` | `aster.ui.resource-slots/v1` | **implemented** | ready | `stamp`, `value`, `refresh`, `parameterId` |
| `data.management` | `aster.data.management/v2` | **implemented** | ready | `list`, `get`, `count` |
| `phone.layout` | `aster.phone.layout/v1` | **implemented** | ready | `get`, `save`, `swap`, `reset` |
| `world.social` | `aster.world.social/v1` | **implemented** | ready | `open`, `state` |

RepositoryPort/CapabilityPort 的方法名来自 r188 已验收 fixture；当前数据管理工作台的 Tavo 适配器不会冒充 project/save repository。

## 参数登记

| 分类 | 数量 | 参数 ID |
|---|---:|---|
| `effects` | 4 | `theme.backgroundFx`, `theme.clickFx`, `theme.motion`, `theme.panelOpacity` |
| `feedback` | 2 | `feedback.sound.enabled`, `feedback.sound.volume` |
| `interaction` | 3 | `interaction.drag.edgePadding`, `interaction.drag.enabled`, `interaction.drag.threshold` |
| `layout` | 2 | `ui.compact`, `ui.density` |
| `phone` | 7 | `phone.festival`, `phone.location`, `phone.season`, `phone.userName`, `phone.widget.enabled`, `phone.worldDate`, `phone.worldTime` |
| `skin-resource` | 1 | `skin.resource.phone.wallpaper` |
| `skin-slot` | 36 | `skin.slot.inner.body.fontFamily`, `skin.slot.inner.body.fontScale`, `skin.slot.inner.body.fontWeight`, `skin.slot.inner.body.letterSpacing`, `skin.slot.inner.body.lineHeight`, `skin.slot.inner.body.motion`, `skin.slot.inner.button.fontFamily`, `skin.slot.inner.button.fontScale`, `skin.slot.inner.button.fontWeight`, `skin.slot.inner.button.letterSpacing`, `skin.slot.inner.button.lineHeight`, `skin.slot.inner.button.motion`, `skin.slot.inner.code.fontFamily`, `skin.slot.inner.code.fontScale`, `skin.slot.inner.code.fontWeight`, `skin.slot.inner.code.letterSpacing`, `skin.slot.inner.code.lineHeight`, `skin.slot.inner.code.motion`, `skin.slot.inner.metric.fontFamily`, `skin.slot.inner.metric.fontScale`, `skin.slot.inner.metric.fontWeight`, `skin.slot.inner.metric.letterSpacing`, `skin.slot.inner.metric.lineHeight`, `skin.slot.inner.metric.motion`, `skin.slot.inner.subtitle.fontFamily`, `skin.slot.inner.subtitle.fontScale`, `skin.slot.inner.subtitle.fontWeight`, `skin.slot.inner.subtitle.letterSpacing`, `skin.slot.inner.subtitle.lineHeight`, `skin.slot.inner.subtitle.motion`, `skin.slot.inner.title.fontFamily`, `skin.slot.inner.title.fontScale`, `skin.slot.inner.title.fontWeight`, `skin.slot.inner.title.letterSpacing`, `skin.slot.inner.title.lineHeight`, `skin.slot.inner.title.motion` |
| `theme` | 3 | `theme.accent`, `theme.active`, `theme.mode` |
| `typography` | 2 | `theme.fontFamily`, `theme.fontScale` |
| `world` | 2 | `world.diceSides`, `world.label` |

## 明确设计差异

- r188 要求 Skin 完全 code-free；Aster 按本轮用户裁定让 Skin 书拥有“槽位/资源声明注册代码”，但持久化、业务状态和平台调用仍不在 Skin。全部产品 CSS 仍只位于 Skin 书。
- 小手机、设置、主题、仪表盘和社交壳是 Aster 新接口，不兼容旧 Vic 名称、变量或持久化键。
- 9 个叙事应用目前只有明确标注“后续”的可打开骨架；它们不会在本报告中被算成功能迁移。

## 下一阶段边界

下一阶段应从 Function 100–107 的状态/命令/事务合同开始实现，再接 RepositoryPort；在此之前，不让玩家背包、任务、项目/存档或叙事协议直接写 Tavo 变量形成旁路。
