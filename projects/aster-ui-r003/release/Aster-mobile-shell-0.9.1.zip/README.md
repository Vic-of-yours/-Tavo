# Aster narrative engine 0.9.1 / Selected UI 1.1

Aster 是一个独立、与旧 Vic 不兼容的新项目。它只扫描
`Aster·核心 / 功能 / 图鉴 / 系统 / 皮肤`，只使用 `Aster` 全局与 `aster.*` 持久化键。
文件缩小不作为迁移完成证据；v117 逐条迁移账与 r188 蓝图合同账始终保留 `partial/pending`。

## 当前范围

- 36 个可独立加载模块、25 个真实面板、16 个已注册应用、62 个类型化参数；
- 276 个产品 CSS 类、284 个 Core 语义类注册、27 个共享容器、19 个槽位；产品 CSS 全部位于皮肤书；
- Core 内置原子工具与工作台双注册中心；搜索、筛选、排序、分面统计、分页、选择集、批改、前后缀、标签、CRUD、导出和写后回读只维护一份，应用可单独调用一个动作或用 `pipe` 组合多个动作；
- r188 全部 83 个模块边界与 19 份跨书接口登记到 Core，未实现接口明确失败，不提供伪服务；
- 单例小手机：仅外壳按上一版基准缩窄 1/4、加高 1/4（桌面 307×775 上限、390px 级手机 298×750 上限），数据管理与独立编辑器不跟随缩放；桌面、应用抽屉、编辑、开发者四种互斥状态；Pointer/Touch 双路长按、左右滑页、上滑抽屉、跨图标拖换、误触抑制、壁纸、Dock、○×△；活动状态内部滚动，经典三键栏固定在手机底部；
- 普通抽屉只显示玩家应用；点击世界名并二次确认才进入开发者模式；
- Selected UI 1.1 世界仪表盘采用紧凑 P1 双轨稿：顶栏、开放立绘玩家区、透明城市世界球与唯一地点牵引板、玩法场景四区；内轨 5 个玩法命令、外轨 4 个原世界入口独立拖动/多格吸附，`activeId` 为持久化状态源，拖动后的合成 click 会被一次性抑制；`registerRoute()` 保留为外轨兼容门面，`registerOrbit()` 为公开主 API；
- “最新消息”采用 Holo Veil 2：消息光带、论坛精选/分区/话题、直播媒体卡是三种独立 presentation；纵向模式轨与开放立绘在所有宽度保留，索引和详情复用同一个 `social.main`，已删除 `world-social-thread` 面板；超过五个 section 时提供真实“更多”入口，自定义 presentation 走通用 index/detail，不伪装成直播；
- 原“设置”收口为单一职责的“数据管理”，只保留“数据 / 资源”两个标签；包体导入、Mod 管理、模式配置和开发参数均不混入本应用；
- 数据工作台通过薄适配器管理世界书、角色卡、正则与预设；支持搜索、类型筛选、独立可视化记录/条目编辑、新增、排序、批量启停/标签/前后缀/删除、导出、二次确认删除及写后回读；
- 资源工作台管理 chat/global 的图片、音频、视频、字体、文本和二进制文件；使用紧凑冷感表格、三张概览卡、可展开详情和按需懒加载预览，支持分类/标签、文本重保存、批量操作、导出、删除、状态重扫及固定资源书同步；`tavo.file` 按方法分别探测，v117 `save/load/delete/url` 基础能力仍可独立工作；
- 独立主题应用：3 套主题、5 个差异显著的字体预设卡、6 种字体/动效类型、6 个内层语义槽、6 个可替换资源槽；字体只在首次选用时写入 Tavo 全局本地文件，再通过本地 URL 与 Skin `@font-face` 懒加载；
- 字体、图片、音频、视频与文本共用本地资源索引、首次落盘、会话 Promise 去重与本地 URL 解析，不让每个聊天页面重复请求远程资源；
- 新增固定 `Aster·资源书`：每个本地文件一个禁用触发的结构化条目，记录逻辑 ID、文件名、虚拟路径、作用域、MIME、SHA-256、引用位置、渲染清单与本地状态；
- 资源页打开/刷新时会对账 `file.list/exists`；外部缓存删除会标记“本地缺失”，管理器明确删除则同步清除索引与资源书条目；重命名、删除与内容别名写入固定变更清单，重扫不再复活旧名；同步修复空名、重复条目，并排除 ZIP/TPG/THM 与说明/回执文件；
- 本地资源以“作用域 + 实际 SHA-256”安全去重：仅删除已验证、Aster 管理且无引用的冗余文件，未知散列或被引用资源只标记不删除；同内容文件保留别名与来源关系；
- 唯一导入入口为 Aster Mod 整包导入器 1.4.0：一个 `aster.mod/v1` ZIP 可包含世界书、角色卡、正则、预设、主题、变量以及图片/音频/视频/字体/文本/二进制资源；同名世界书先汇入各旧版本独有条目，再让包内条目按标识符、UID 或条目名替换，整包回读成功后删除同名旧对象；其他同名对象同样更新唯一主版本并清理旧副本；包内及跨包多媒体经实际散列验证后复用本地文件；成功后删除临时 ZIP 并二次检查；增量包可显式请求去重遗留的同 ID Aster 模块，并在更新失败时按书回滚；
- 旧五书粘贴/队列导入插件已经从源码、测试和发布包移除；数据管理应用也不再提供第二套导入路径；
- 手机、仪表盘、设置、主题与世界通讯直接注册无通用标题壳布局；插件 HTML 只保留两个浮动入口，不再包裹产品面板；
- Runtime 0.9.1 插件显式声明官方 `file` 权限并刷新通用素材桥；界面密度在 input/change/pointer/touch/blur/key 终结事件后都写入并读回。
- 手机与仪表盘相互无跳转；设置/开发工具不进入沉浸式仪表盘。
- 小手机壳体修复与本轮素材化均已回存本地：手机壳继续由 Skin 绘制，System 不持有 CSS；Tavo 皮肤书当前 6/6 模块无偏移。旧手机同步报告保留为历史证据，当前 revision 以 `reports/five-books-alignment.md/json` 为准。
- 参考图素材范围已收口为跨世界通用 UI：60 个类型/功能图标、6 个异形控件遮罩、3 张抽象壁纸、4 张平铺纹理、装饰图集和三组可降级动画层，共 82 个运行时文件、83 个资源清单项。生产源/预览唯一存放于 `工作区/04_REFERENCE_ASSETS/Aster通用UI素材/`，运行时唯一存放于 `assets/ui/common/`；一次性载入 ZIP 已用后删除。角色、地点、玩法场景和直播封面继续共用占位，留给后续世界 Mod。
- 新版示意图、蓝图与合同唯一存放于 `design/orbit-holo-veil/`；12 个新运行素材唯一存放于 `assets/ui/orbit-holo/`，四项制作源与三张本轮核对证据分别唯一存放于 `design/orbit-holo-veil/production-sources/` 与 `design/orbit-holo-veil/reference-evidence/`，单独 source ZIP / Git clone 即可复验。其中开放玩家立绘为本轮新生成并保留真实 Alpha；原载入包中的 83 个既有重复文件没有再次吸收，已用载入包已删除。
- `reports/five-books-alignment.md/json` 记录 2026-08-20 的历史 Tavo 基线：核心 19、功能 5、图鉴 1、系统 5、皮肤 6，当时 36/36 模块回读一致，Runtime `io.aster.narrative.runtime@0.9.0` 已重启并启用。该报告不作为本轮 UI 改书后的当前在线证据，因此只留在源码历史中，不进入生产安装包。素材账本 1.0.0 的 12 个 Tavo 全局素材曾逐字节回读无差异，但 1.1.0 已替换开放立绘且尚未写入 Tavo，当前部署/回读状态为 `pending`。

9 个叙事应用已经有可打开、明确标注“后续”的真实路由骨架，但本版只把“设置”和“主题”计为完整应用；
背包、任务、项目/存档、叙事协议、记忆、搜索、大纲与多媒体数据层仍是后续批次。

## 分层合同

- Core：注册中心、类名、容器、槽位、能力、单例、蓝图合同与审计。
- Function：参数持久化、本地资源、资源账本、83 项通用 UI 素材桥与 12 项双轨/Holo Veil 素材桥；后续玩法/叙事能力从此层继续实现。
- Codex：当前只有迁移图鉴入口；RepositoryPort 尚未实现，也不会由设置适配器冒充。
- System：手机、仪表盘、设置、主题应用与路由，不拥有 CSS。
- Skin：全部产品 CSS、主题 token、语义偏好与资源槽声明。

UI 组合遵循“容器 / 样式 / 效果 / 功能”分离。内层偏好按全局 → 类型/语义槽 → 单例显式值解析；
宿主顶标题、输入区与浮动入口不绑定世界内层字体槽。

## 构建与验证

```bash
python3 build_books.py
python3 tools/build_mod_importer_fixture.py
python3 tools/build_runtime_asset_packages.py
node tests/verify-first-gate.js
node tests/verify-importer.js
node tests/verify-mod-importer.js
node tests/verify-ui-contracts.js
python3 tools/verify_common_ui_assets.py
python3 tools/verify_orbit_holo_assets.py
python3 package_release.py
```

完整发布脚本会先构建回归测试 fixture，但 fixture 不进入生产交付；随后构建 `io.aster.ui.common-assets@1.0.0` 与 `io.aster.ui.orbit-holo@1.1.0` 两个 `aster.mod/v1` 生产资源包。重组前的 `history-r117` / `audit-r188` 源目录已不在当前树中；发布脚本只校验并收录 `reports/v117-migration-ledger.*` 与 `reports/r188-blueprint-interface-audit.*`，不猜测旧路径、不改写保留证据。

当前自动结果以 `reports/*-test-results.json` 为准；旧五书导入器测试已经改为“确认退役且不会进入发布包”的反回归测试。
浏览器布局脚本 `tests/verify-browser-ui.js` 需要本机 Playwright Chromium；正式发布默认必须取得
`realBrowser: true` 的通过报告，不会把模拟 DOM 或跳过记录当成正式浏览器证据。本机确实没有可执行浏览器、
且只需生成不可作为发布证据的本地非正式构建时，必须显式执行
`ASTER_ALLOW_BROWSER_SKIP=1 python3 package_release.py`；脚本会打印“非正式构建”警告。

另有独立的真实 Tavo 证据：`reports/tavo-live-boundary-evidence.md` 与配套 JSON 来自 Tavo 1.1.5 / build 1015 的 MCP 和内嵌 DOM 探针。该证据确认当前竖屏 CSS screen 394×853、layout viewport 394×679、visual viewport 393.85×548.92，以及手机/仪表盘/数据管理的实际几何和局部溢出；它不等同于 Playwright 测试，也未覆盖横屏、键盘展开、分屏或人工视觉验收。

## 安装

1. 从版本化交付目录安装 `aster-runtime-0.9.1.tpg` 和 `aster-mod-importer-1.4.0.tpg`。
2. 通过 Tavo 原生世界书入口加载交付包内的五本 JSON，然后用侧边栏的完整 Mod 导入器分别导入 `Aster-common-ui-assets-1.0.0.zip` 与 `Aster-orbit-holo-assets-1.1.0.zip`。
3. 在小手机打开“数据管理”，确认“数据 / 资源”两个工作台的搜索、编辑、导出与删除回读。
4. 运行 `reports/ui-settings-acceptance.md` 的 Tavo 真机清单。

实现依据为官方 [TavoJS API](https://docs.tavoai.dev/cn/guides/javascript-api/) 与
[插件开发指南](https://docs.tavoai.dev/cn/guides/plugin-development/)。TavoJS 当前未公开外部 TPG
安装/卸载接口，因此独立“模块中心”只管理 Aster 书内模块启停，不伪造第三方插件管理按钮。
