# v117 → Aster 逐条迁移账

> 口径：只有源条目的完整用户能力已在 Aster 新契约下重建，且通过事件级回归，才标 `migrated_verified`。`partial` 不计完成。

- 五本引擎书源条目：147 条（144 模块 + 1 说明 + 2 资源清单）
- 源插件：2 个
- 跟踪行：149 行
- 已完整迁移并验证：2 行
- 部分迁移（不计完成）：29 行
- 待迁移：118 行

## 资产边界

| v117 交付文件 | 条目/提词数 | 字节 | SHA-256 | 当前口径 |
|---|---:|---:|---|---|
| Tavo_Vi_预设·叙事协议.txt | 22 | 59577 | `5ba3ba05387c08a1…` | pending |
| Vic·Mod·文豪野犬.txt | 111 | 247973 | `b1b50f4d78026bbc…` | pending |
| Vic·Mod·淫乱小镇.txt | 120 | 188674 | `f8e6e57f4434bec5…` | pending |
| Vic·叙事书-v10.1.0.json | 3 | 31354 | `062528e03334d8fb…` | pending |
| Vic·引擎.txt | 21 | 219763 | `cb78ffe10f9f4e7e…` | source_accounted |
| Vic·引擎·功能.txt | 21 | 745616 | `b01d94d59541f2d2…` | source_accounted |
| Vic·引擎·图鉴.txt | 34 | 461061 | `6debf1d607a0b08d…` | source_accounted |
| Vic·引擎·皮肤.txt | 17 | 142823 | `04a12933c8d6779a…` | source_accounted |
| Vic·引擎·系统.txt | 54 | 491448 | `02fb1c2871fcb8e8…` | source_accounted |

## Vic·引擎 (21)

| 源 ID | 名称 | v117 版本 | 状态 | Aster 对应 | 说明 |
|---|---|---:|---|---|---|
| `v117.entry.core.00-readme` | Vic·引擎 模块书说明 | v117 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.core.lib` | core·函数库 | 1.3.0 | **partial** | `aster.core.lib`, `aster.form.schema` | Registry/bus/store/CSS/text/DOM and the new Schema parser are live; v117 time-axis helpers and full diagnostic/UI helper surface remain pending. |
| `vic.core.registries` | core·注册中心 | 1.0.0 | **partial** | `aster.core.registries` | Registry-of-registries is live; v117 style/fn tree aggregation and resource placeholder resolution are not yet ported. |
| `vic.core.slots` | core·槽位注册中心 | 1.0.0 | **partial** | `aster.core.slots`, `aster.ui.contracts`, `aster.ui.capabilities`, `aster.ui.composer`, `aster.shell.mounter` | Hosts, semantic classes, containers, component slots, parameterized capabilities and three-level UI composition are live; the remaining v117 registered-definition replay surface is still pending. |
| `vic.panel.registry` | 面板·页注册中心 | 1.0.0 | **migrated_verified** | `aster.panel.registry` | Register/get/list/count/unregister and render validation are reimplemented; all registered panels are opened through dispatched manager events. |
| `vic.data.registry` | data·数据注册中心 | 1.0.1 | **partial** | `aster.collection.tools`, `aster.data.manager` | Core owns reusable tool, adapter and workbench registries; Data Manager registers five thin workbench adapters. v117 gameplay repositories remain pending. |
| `vic.data.routes-base` | data·内置导入路由 | 1.4.2 | **partial** | `aster.collection.tools`, `aster.data.manager` | Lorebook/character/regex/preset/file adapters expose explicit API-backed routes and verified readback; project/save repository v2 remains pending. |
| `vic.data.resources` | data·本地资源库 | 1.0.0 | **partial** | `aster.asset.library`, `aster.asset.ledger`, `aster.data.manager`, `aster.skin.contracts` | Tavo file list/save/load/url/export/delete, local state reconciliation, fixed resource-book synchronization and visual resource slots are live; trash recovery remains pending. |
| `vic.data.browser` | data·在线浏览修改 | 1.0.0 | **partial** | `aster.collection.tools`, `aster.data.manager` | Search/filter/sort/selection, visual editors, batch fields/affixes/tags, export, guarded delete and verified readback are registered Core tools and event-tested; gameplay repository views remain pending. |
| `vic.data.manifest` | 数据域·资源清单 | 1.0.0 | **partial** | `aster.skin.contracts` | Six named resource slots and parameterized wallpaper selection are registered; source manifest hashing, bindings and package resolution are pending. |
| `vic.action.manager` | 动作·设置 | 1.0.0 | **partial** | `aster.ui.composer`, `aster.collection.tools`, `aster.data.manager` | Registered commands, atomic tools and workbench actions are callable and composable; the full v117 action catalog and authority model remain pending. |
| `vic.shell.mounter` | 壳层挂载器 | 1.0.0 | **partial** | `aster.shell.mounter` | Both load orders, reconnect, timers, and the two requested controls are verified; arbitrary slot replay remains pending. |
| `vic.shell.overlay` | 壳层·面板宿主 | 1.1.0 | **migrated_verified** | `aster.shell.overlay`, `aster.skin.shell` | Body-mounted pointer-enabled stack, close/backdrop/Escape, bottom placement, width, onClose, depth and duplicate-id rerender are reimplemented and event-tested. |
| `vic.shell.panel` | 壳层·设置面板骨架 | 1.0.0 | **partial** | `aster.shell.panel` | Registry-driven manager is live and every panel opens; v117 tab strip and remembered current page remain pending. |
| `vic.panel.dev` | 面板·开发控制 | 1.0.0 | **partial** | `aster.panel.developer`, `aster.core.selftest` | Module/form/diagnostic panels, developer-only routing, persisted module toggles and live self-test are usable; copied diagnostic bundle and aggregated payload views remain pending. |
| `vic.panel.import` | 面板·数据导入 | 1.0.0 | **partial** | `io.aster.mod-importer` | Import was deliberately removed from Data Manager. The standalone system-picker Mod importer handles the complete aster.mod/v1 package with transactional rollback, idempotence and verified cleanup; legacy URL/free-form routes are retired. |
| `vic.panel.data` | 面板·数据管理 | 1.0.0 | **partial** | `aster.data.manager`, `aster.collection.tools` | World books, character cards, regex sets and presets can be searched, filtered, visually edited, batch-modified, exported and guarded-deleted; project/save domain data remains pending. |
| `vic.panel.resImport` | 面板·资源导入 | 1.0.0 | **partial** | `io.aster.mod-importer`, `aster.asset.library`, `aster.asset.ledger` | Resource import is isolated in the full Mod package importer; Data Manager only manages chat/global localized files and the fixed resource ledger. Mirror and trash recovery remain pending. |
| `vic.panel.resManage` | 面板·资源管理 | 1.0.0 | **partial** | `aster.data.manager`, `aster.asset.library`, `aster.asset.ledger`, `aster.skin.contracts` | Resource list/search/filter/preview/edit/rename/copy-URL/export/batch metadata/batch delete, local-state rescan and fixed resource-book repair are live; trash recovery remains pending. |
| `vic.core.selftest` | core·自检 | 1.0.0 | **partial** | `aster.core.selftest` | Twenty-capability architecture self-test is live, including blueprint census, Core tool/workbench registries, Data Manager and social shells; the full v117 gameplay/content suite follows later modules. |
| `vic.content.renderer` | 中央渲染器 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |

## Vic·引擎·功能 (21)

| 源 ID | 名称 | v117 版本 | 状态 | Aster 对应 | 说明 |
|---|---|---:|---|---|---|
| `vic.state.core` | state·全局状态注册中心 | 1.1.3 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.fields.core` | state·字段键注册中心 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.rules.core` | state·规则原语引擎 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.state.mode` | state·叙事模式 | 2.9.2 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.merger.core` | state·更新合并器 | 1.6.1 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.core` | snap·快照核 | 1.6.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.todo.aiwork` | todo·AI 工作层 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.time.core` | time·时间与历法 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.dice.core` | dice·随机与判定 | 1.0.0 | **pending** | — | The old dashboard die was deliberately removed from the immersive dashboard. Dice expressions, deterministic luck, pools and gameplay consumers are not migrated. |
| `vic.event.core` | event·事件调度器 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.inv.core` | inv·背包与装备 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.quest.core` | quest·任务引擎 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.econ.core` | econ·经济与合成 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.routine.core` | routine·结算管线 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.stat.core` | stat·数值体系 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skill.core` | skill·技能体系 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.growth.core` | growth·经验成长体系 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.init.core` | state·初始化生成轮 | 1.6.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.story.core` | story·故事层调度核 | 3.10.6 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.inject.core` | inject·标记区块注入核 | 1.17.1 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.gen.corpus` | 生成协议语料注册中心 | 3.3.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |

## Vic·引擎·图鉴 (34)

| 源 ID | 名称 | v117 版本 | 状态 | Aster 对应 | 说明 |
|---|---|---:|---|---|---|
| `vic.codex.types` | codex·图鉴类型注册中心 | 1.5.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.assets` | codex·多媒体注册中心 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.core` | codex·图鉴记录注册中心 | 1.7.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.src-book` | codex·静态源（世界资料书） | 1.3.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.src-memo` | codex·记忆源（记忆书） | 1.3.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards` | codex·样式面板渲染中心 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.tooltip` | codex·词条悬浮卡 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.decorate` | codex·正文词条装饰 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.panel` | codex·图鉴面板 | 1.2.1 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.chara-traits` | codex·角色条目互绑 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.world` | codex·卡片渲染器·世界 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.geo` | codex·卡片渲染器·地理 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.faction` | codex·卡片渲染器·势力 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.chara` | codex·卡片渲染器·角色 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.item` | codex·卡片渲染器·物品 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.power` | codex·卡片渲染器·能力 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.story` | codex·卡片渲染器·故事 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.rule` | codex·卡片渲染器·规则 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.cards.other` | codex·卡片渲染器·其他 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.timeline` | codex·记忆时间线视图 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.codex.gridmap` | codex·格点地图视图 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.memory.core` | memory·记忆注册中心 | 1.7.1 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.memlayer.core` | memlayer·记忆层档案 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.mem` | snap·供给端·记忆文本 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.world` | snap·供给端·世界文本 | 1.3.3 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.player` | snap·供给端·玩家面板 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.party` | snap·供给端·在场与社交 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.inv` | snap·供给端·背包装备货币 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.quest` | snap·供给端·任务成就 | 1.1.1 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.event` | snap·供给端·事件大事记 | 1.1.1 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.time` | snap·供给端·时间历法天象 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.scene` | snap·供给端·场景地理 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.skill` | snap·供给端·已学能力 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.snap.feed.rumor` | snap·供给端·流言个人近事 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |

## Vic·引擎·系统 (54)

| 源 ID | 名称 | v117 版本 | 状态 | Aster 对应 | 说明 |
|---|---|---:|---|---|---|
| `vic.core.theme` | core·主题与皮肤沉降 | 1.0.0 | **partial** | `aster.theme.service`, `aster.skin.tokens` | Aster theme tokens and global apply/readback are live; the complete source token/asset contract remains pending. |
| `vic.theme.packs` | 主题包·冷色科技 | 1.0.0 | **partial** | `aster.theme.service`, `aster.theme.app` | Three selectable Aster-native theme packs are live and persistent; source pack compatibility and all legacy specializations are intentionally absent. |
| `vic.skin.bgfx` | 底层·全局背景特效 | 1.0.0 | **partial** | `aster.theme.service`, `aster.skin.tokens` | Registered background-effect preference and Skin tokens are live; the complete source ambient underlay library remains pending. |
| `vic.skin.options` | 皮肤槽位·内置声明 | 1.0.0 | **partial** | `aster.params.core`, `aster.theme.service`, `aster.theme.app`, `aster.skin.tokens` | Standalone Theme, three token packs, semantic font/motion slots, density/compact/effects/opacity/accent, wallpaper resource selection and synchronous readback are live; remaining v117 slots are pending. |
| `vic.typo.pack` | 排版包·十一记号 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.content.base` | 内容内核·工具箱与区块解析器 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.code` | 标记·代码 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.title` | 标记·标题 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.event` | 标记·事件 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.message` | 标记·消息 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.mind` | 标记·内心 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.letter` | 标记·信笺 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.secret` | 标记·密档 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.terminal` | 标记·终端 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.broadcast` | 标记·播报 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.narration` | 标记·旁白 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.quote` | 标记·引文 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.flashback` | 标记·回忆 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.dream` | 标记·梦境 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.system` | 标记·系统 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.archive` | 标记·档案 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.poem` | 标记·诗歌 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.scan` | 标记·鉴定 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.timeline` | 标记·时间轴 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.scene` | 标记·场景 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.loot` | 标记·收获 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.lose` | 标记·失去 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.sticky` | 标记·便签 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.warn` | 标记·警告 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.footnote` | 标记·注脚 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.mark.dice` | 标记·骰子 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.guard` | 区块·净化引擎 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.head` | 区块·抬头（运行清单） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.de` | 区块·审计 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.viupdate` | 区块·落账 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.note` | 区块·待办（含待办核心） | 1.3.1 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.copy` | 区块·复制容器 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.ext` | 区块·扩展外壳 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.block.act` | 区块·选择栏 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.dm` | 扩展·弹幕 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.rumor` | 扩展·风闻 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.notice` | 扩展·公告 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.settle` | 扩展·结算区 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.echo` | 扩展·近日留言回读 | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.theater` | 扩展·小剧场 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.forum` | 扩展·论坛 | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.ext.source` | 扩展·源头读取 | 1.7.6 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.action.theme` | 动作·主题美化 | 1.0.0 | **partial** | `aster.theme.service`, `aster.theme.app` | Theme selection is a registered command with persistent parameters and singleton refresh; the full v117 theme action payload remains pending. |
| `vic.enhancer.fx` | 增强器·点击特效与桌宠 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.statusbar.ui` | ui·顶部状态栏（北斗七星） | 2.5.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.dash.ui` | ui·仪表盘（扇形轨道 HUD） | 2.9.5 | **partial** | `aster.dashboard.world`, `aster.skin.shell` | The hexagonal world entry, player strip, replaceable map/gameplay resources, four gameplay tabs and four real panel shortcuts are live; gameplay data, review and operation log remain pending. |
| `vic.enhancer.bgm` | 增强器·背景音乐 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.memo.keeper` | memo·记忆守门（手动确认落账） | 1.2.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.panel` | 主题面板 | 1.0.0 | **partial** | `aster.theme.app`, `aster.skin.preference-registry` | The independent Theme app exposes packs plus generated semantic-slot forms and inheritance sources; the remaining v117 skin panel specializations are pending. |

## Vic·引擎·皮肤 (17)

| 源 ID | 名称 | v117 版本 | 状态 | Aster 对应 | 说明 |
|---|---|---:|---|---|---|
| `vic.theme.default` | 默认主题 tokens | 1.0.0 | **partial** | `aster.skin.tokens`, `aster.theme.service`, `aster.ui.composer` | Aster owns whitelisted runtime theme tokens plus semantic composition contracts; the wider v117 asset and module-specific override contract is not yet fully represented. |
| `v117.entry.skin.14-reslist-冷色科技字体包` | 冷色科技字体包 | v117 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `v117.entry.skin.15-reslist-Live2D运行库` | Live2D运行库 | v117 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.codex-base` | 图鉴·基础（结构） | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.codex-style` | 图鉴·样式（视觉） | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.default-host` | 默认宿主皮肤 | 1.0.0 | **partial** | `aster.skin.shell` | Phone, dashboard, overlay and floating-entry visual CSS is centralized in Skin; the complete v117 host specialization set remains pending. |
| `vic.skin.underlay-ambient` | 底层·环境氛围 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.panel-forms` | 面板表单皮肤 | 1.0.0 | **partial** | `aster.skin.forms`, `aster.form.schema` | Schema controls, Data Manager workbenches, semantic preference editor and responsive states are styled; v117 folds and remaining specialized panels are pending. |
| `vic.skin.default-content` | 默认内容皮肤 | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-head` | 区块·抬头（皮肤） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-audit` | 区块·审计（皮肤） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-update` | 区块·落账（皮肤） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-body` | 区块·正文（皮肤） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-copy` | 区块·复制（皮肤） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-ext` | 区块·扩展（皮肤） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-act` | 区块·选择栏（皮肤） | 1.1.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |
| `vic.skin.block-todo` | 区块·待办（皮肤） | 1.0.0 | **pending** | — | No Aster parity claim in the 0.8 Data Manager/theme/resource gate. |

## 两个 v117 插件 (2)

| 源件 | v117 版本 | 状态 | Aster 对应 | 说明 |
|---|---:|---|---|---|
| Vic Engine plugin | 1.0.5 | **partial** | `io.aster.narrative.runtime` | Spec v2 exact-five-book runtime, sequential loader, lifecycle bridge, module enable map, shell and sidebar actions are live; the later gameplay snapshot/input surface is not counted as migrated yet. |
| Vic Importer plugin | 1.0.4 | **partial** | `io.aster.mod-importer` | Replaced by the standalone aster.mod/v1 system-picker importer: all package item types, embedded media, incremental lorebook merge, same-name update, transaction rollback, idempotence and source cleanup are verified. Legacy URL/free-form routes are retired. |

## 0.8 新基建（非 v117 对应条目的冒名迁移）

- `aster.form.schema`：六种输入类型 + section/info/action + 参数绑定。
- `aster.params.core`：类型化参数注册、chat/global 分域、持久化、重置与 UI 应用。
- `aster.catalog.bootstrap`：可点击的迁移图鉴入口；不代表 v117 图鉴系统已迁移。
- `aster.phone.core` / `aster.dashboard.world`：单状态手机 OS、右下世界仪表盘、玩法页与社交应用壳。
- `aster.collection.tools`：核心书中的原子工具、适配器与工作台注册中心；支持单工具、带回执调用和多工具管线组合。
- `aster.data.manager`：只有“数据 / 资源”两个注册式工作台；不包含导入、Mod 或模式配置，也不冒充未来 project/save repository。
- `aster.asset.library` / `aster.asset.ledger`：本地多媒体资源、状态对账与固定 `Aster·资源书` 的唯一实现。
- `aster.blueprint.contracts`：r188 83 模块与跨书接口的可审计合同登记；pending 不提供伪实现。

注：真机 Tavo 宿主验收仍未执行；本账不把 DOM 回归写成真机完成。
