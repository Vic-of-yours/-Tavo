# Aster 运行素材 r002

本目录是唯一的现行素材树。94 个视觉文件已按用途分类并改为短路径；文件字节未改动。
立绘、头像和人物站姿栅格图为 0。公开 packageId、itemId、语义键、CSS 变量及 SVG 内部 ID 均保持不变。

## 分类

- `background`：3 个
- `effect`：6 个
- `hud-icon`：5 个
- `icon-action`：8 个
- `icon-content`：19 个
- `icon-dev`：6 个
- `icon-nav`：6 个
- `icon-social`：6 个
- `icon-status`：7 个
- `icon-world`：8 个
- `map`：1 个
- `mask`：6 个
- `scene`：6 个
- `sprite`：3 个
- `texture`：4 个

`catalog.json` 逐项记录旧路径、新路径、用途、安装短名、字节数和 SHA-256；`SHA256SUMS.txt` 覆盖 94 个视觉文件及 catalog。
