(function () {
  'use strict';

  var PLUGIN_VERSION = '1.4.0';
  var MOD_SPEC = 'aster.mod/v1';
  var RECEIPT_SPEC = 'aster.mod.receipt/v1';
  var RECEIPT_NAME = 'aster-mod-last-receipt.json';
  var RECEIPT_KEY = 'aster.mod.import.lastReceiptPath';
  var RESOURCE_INDEX_KEY = 'aster.resource.index.v1';
  var RESOURCE_BOOK_NAME = 'Aster·资源书';
  var RESOURCE_RECORD_SPEC = 'aster.resource/v1';
  var RESOURCE_BOOK_SPEC = 'aster.resource.book/v1';
  var RESOURCE_ENTRY_PREFIX = 'aster-resource:';
  var RESOURCE_TOKEN = /\{\{aster\.resource:([a-z0-9._-]+)\}\}/g;
  var ASTER_MODULE_MARKER = '⟦aster·module⟧';
  var ASTER_CANONICAL_BOOKS = {
    'Aster·核心': true, 'Aster·功能': true, 'Aster·图鉴': true,
    'Aster·系统': true, 'Aster·皮肤': true
  };
  var ALLOWED_TYPES = ['resource', 'character', 'lorebook', 'preset', 'regex', 'theme', 'themePackage', 'variables'];
  var TYPE_ORDER = { resource: 10, character: 15, lorebook: 20, preset: 30, regex: 40, theme: 50, themePackage: 55, variables: 60 };
  var busy = false;
  var crcTable = null;

  var DEFAULT_LIMITS = {
    maxArchive: 64 * 1024 * 1024,
    maxEntries: 128,
    maxFile: 32 * 1024 * 1024,
    maxTotal: 256 * 1024 * 1024,
    maxRatio: 500
  };

  function tr(key, params) {
    try { return tavo.plugin.i18n.t(key, params || {}); }
    catch (error) { return key; }
  }

  function toast(key, params) {
    try { tavo.utils.toast(tr(key, params)); } catch (error) {}
  }

  function ModError(code, message, detail) {
    this.name = 'ModError';
    this.code = code;
    this.message = message;
    this.detail = detail || null;
    if (Error.captureStackTrace) Error.captureStackTrace(this, ModError);
  }
  ModError.prototype = Object.create(Error.prototype);
  ModError.prototype.constructor = ModError;

  function fail(code, message, detail) { throw new ModError(code, message, detail); }
  function messageOf(error) { return String(error && error.message || error || 'Unknown error'); }
  function own(object, key) { return Object.prototype.hasOwnProperty.call(object, key); }
  function isObject(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function idOf(value) { return value && typeof value === 'object' ? value.id : value; }
  function finiteInteger(value) { return Number.isInteger(value) && Number.isFinite(value); }
  function scopeOf(value, fallback) { return value === 'global' || value === 'chat' ? value : fallback; }
  function validId(value) { return typeof value === 'string' && /^[a-z0-9][a-z0-9._-]{0,79}$/.test(value); }
  function validSemver(value) { return typeof value === 'string' && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(value); }
  function validConflict(value) { return ['replace', 'rename', 'skip', 'error'].indexOf(value) >= 0; }

  function asterModuleMeta(entry) {
    var content = String(entry && entry.content || '');
    if (content.indexOf(ASTER_MODULE_MARKER) < 0) return null;
    var idMatch = content.match(/(?:^|\n)@id\s+(aster\.[a-z0-9._-]+)\s*(?:\n|$)/i);
    if (!idMatch) return null;
    var versionMatch = content.match(/(?:^|\n)@version\s+([^\s]+)\s*(?:\n|$)/i);
    return { id: idMatch[1], version: versionMatch ? versionMatch[1] : '0.0.0' };
  }

  function versionTuple(value) {
    var match = String(value || '').match(/^(\d+)\.(\d+)\.(\d+)/);
    return match ? [Number(match[1]), Number(match[2]), Number(match[3])] : [0, 0, 0];
  }

  function compareVersion(left, right) {
    var a = versionTuple(left), b = versionTuple(right);
    for (var index = 0; index < 3; index += 1) if (a[index] !== b[index]) return a[index] - b[index];
    return 0;
  }

  function safeJson(text, label) {
    try {
      return JSON.parse(text, function (key, value) {
        if (key === '__proto__' || key === 'prototype' || key === 'constructor') {
          fail('E_JSON_DANGEROUS_KEY', label + ': unsafe JSON key ' + key);
        }
        return value;
      });
    } catch (error) {
      if (error instanceof ModError) throw error;
      fail('E_JSON_PARSE', label + ': invalid UTF-8 JSON (' + messageOf(error) + ')');
    }
  }

  function decodeUtf8(bytes, label) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch (error) { fail('E_UTF8', label + ': invalid UTF-8'); }
  }

  function parseJsonBytes(bytes, label) { return safeJson(decodeUtf8(bytes, label), label); }

  function base64ToBytes(value) {
    if (typeof value !== 'string' || !value.length) fail('E_SOURCE_EMPTY', 'Selected ZIP is empty');
    var binary;
    try { binary = atob(value.replace(/\s+/g, '')); }
    catch (error) { fail('E_SOURCE_BASE64', 'Tavo returned invalid base64 for the selected ZIP'); }
    var bytes = new Uint8Array(binary.length);
    for (var index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return bytes;
  }

  function bytesToBase64(bytes) {
    var chunks = [];
    for (var offset = 0; offset < bytes.length; offset += 0x8000) {
      var slice = bytes.subarray(offset, Math.min(offset + 0x8000, bytes.length));
      var text = '';
      for (var index = 0; index < slice.length; index += 1) text += String.fromCharCode(slice[index]);
      chunks.push(text);
    }
    return btoa(chunks.join(''));
  }

  async function sha256(bytes) {
    if (typeof crypto === 'undefined' || !crypto.subtle || typeof crypto.subtle.digest !== 'function') {
      fail('E_CRYPTO_UNAVAILABLE', 'Web Crypto SHA-256 is unavailable in this Tavo WebView');
    }
    var digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
    var result = '';
    for (var index = 0; index < digest.length; index += 1) result += digest[index].toString(16).padStart(2, '0');
    return result;
  }

  function baseName(value) { return String(value || '').split('/').pop() || ''; }
  function cleanName(value, fallback) {
    var output = String(value || fallback || '').trim().replace(/[\u0000-\u001f]/g, '');
    return (output || fallback || 'resource').slice(0, 160);
  }
  function optionalName(value) { return String(value || '').trim().replace(/[\u0000-\u001f]/g, '').slice(0, 160); }
  function inferResourceKind(name, mime) {
    var value = (String(name || '') + ' ' + String(mime || '')).toLowerCase();
    if (/\.(woff2?|ttf|otf)\b|font/.test(value)) return 'font';
    if (/\.(png|jpe?g|webp|avif|gif|svg)\b|image/.test(value)) return 'image';
    if (/\.(mp3|ogg|wav|m4a|flac)\b|audio/.test(value)) return 'audio';
    if (/\.(mp4|webm|mov)\b|video/.test(value)) return 'video';
    if (/\.(json|css|js|md|txt|ya?ml|html?|ejs)\b|text|json/.test(value)) return 'text';
    return 'binary';
  }
  function inferMime(name) {
    var extension = (baseName(name).split('.').pop() || '').toLowerCase();
    return ({
      png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', avif: 'image/avif', gif: 'image/gif', svg: 'image/svg+xml',
      wav: 'audio/wav', mp3: 'audio/mpeg', ogg: 'audio/ogg', m4a: 'audio/mp4', flac: 'audio/flac',
      mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime',
      woff2: 'font/woff2', woff: 'font/woff', ttf: 'font/ttf', otf: 'font/otf',
      json: 'application/json', css: 'text/css', js: 'text/javascript', md: 'text/markdown', txt: 'text/plain', yaml: 'application/yaml', yml: 'application/yaml', html: 'text/html', htm: 'text/html', ejs: 'text/plain'
    })[extension] || 'application/octet-stream';
  }
  function fnv1a(value) {
    var hash = 0x811c9dc5;
    value = String(value || '');
    for (var index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return hash.toString(16).padStart(8, '0');
  }
  function resourceIdentity(row) {
    return String(row && row.assetId || '') || ((row && row.scope || 'global') + ':' + String(row && (row.storedName || baseName(row.path)) || ''));
  }
  function normalizeResourceRecord(row) {
    row = clone(row || {});
    var scope = scopeOf(row.scope, /^files\/chat\//.test(String(row.path || '')) ? 'chat' : 'global');
    var storedName = cleanName(row.storedName || baseName(row.path) || row.name, 'resource-' + fnv1a(JSON.stringify(row)) + '.bin');
    var path = String(row.path || ('files/' + scope + '/' + storedName));
    var assetId = optionalName(row.assetId);
    var identity = assetId || (scope + ':' + storedName);
    var now = new Date().toISOString();
    return Object.assign({}, row, {
      spec: RESOURCE_RECORD_SPEC,
      id: row.id || identity,
      assetId: assetId,
      name: cleanName(row.name || storedName, storedName),
      storedName: storedName,
      path: path,
      scope: scope,
      kind: row.kind || inferResourceKind(storedName, row.mime),
      mime: row.mime || inferMime(storedName),
      exists: row.exists !== false,
      localState: row.localState || (row.exists === false ? 'missing' : 'ready'),
      render: Object.assign({ localized: true, state: row.exists === false ? 'missing' : 'ready', path: path, lookupName: storedName }, row.render || {}),
      createdAt: row.createdAt || now,
      updatedAt: row.updatedAt || now,
      lastCheckedAt: row.lastCheckedAt || now
    });
  }
  function mergeResourceRows(existing, incoming) {
    var output = [], positions = Object.create(null), filePositions = Object.create(null);
    (existing || []).concat(incoming || []).forEach(function (source) {
      if (!source) return;
      var row = normalizeResourceRecord(source);
      var key = resourceIdentity(row), fileKey = row.scope + ':' + row.storedName;
      var position = own(positions, key) ? positions[key] : (own(filePositions, fileKey) ? filePositions[fileKey] : -1);
      if (position >= 0) {
        var merged = normalizeResourceRecord(Object.assign({}, output[position], row, {
          createdAt: output[position].createdAt || row.createdAt,
          tags: uniqueIds((output[position].tags || []).concat(row.tags || [])),
          references: uniqueIds((output[position].references || []).concat(row.references || []))
        }));
        output[position] = merged; positions[resourceIdentity(merged)] = position; filePositions[fileKey] = position;
      } else {
        positions[key] = output.length; filePositions[fileKey] = output.length; output.push(row);
      }
    });
    return output.sort(function (left, right) { return (left.scope + ':' + left.storedName).localeCompare(right.scope + ':' + right.storedName); });
  }
  function resourceEntry(row) {
    row = normalizeResourceRecord(row);
    var label = ({ image: '图片', audio: '音频', video: '视频', font: '字体', text: '文本', binary: '文件' })[row.kind] || '文件';
    return {
      identifier: RESOURCE_ENTRY_PREFIX + fnv1a(resourceIdentity(row)),
      name: '[' + label + '] ' + cleanName(row.name, row.storedName),
      content: JSON.stringify(row, null, 2), enabled: false,
      strategy: 'keyword', keywords: ['\u2b21aster-resource:' + fnv1a(resourceIdentity(row)) + '\u2b21'],
      secondaryKeywords: [], secondaryKeywordStrategy: 'none', scanDepth: 2,
      caseSensitive: false, matchWholeWord: true, injectionPosition: 'lorebookAfter', injectionDepth: 4,
      injectionRole: 'system', probability: 100, sticky: 0, cooldown: 0, delay: 0
    };
  }
  function resourceMetaEntry(rows) {
    var summary = rows.reduce(function (value, row) { value[row.localState] = (value[row.localState] || 0) + 1; return value; }, {});
    return {
      identifier: 'aster-resource-book-meta', name: 'Aster\u8d44\u6e90\u4e66\u7d22\u5f15',
      content: JSON.stringify({ spec: RESOURCE_BOOK_SPEC, version: 1, updatedAt: new Date().toISOString(), count: rows.length, states: summary }, null, 2),
      enabled: false, strategy: 'keyword', keywords: ['\u2b21aster-resource-book-meta\u2b21'], secondaryKeywords: [], secondaryKeywordStrategy: 'none',
      scanDepth: 2, caseSensitive: false, matchWholeWord: true, injectionPosition: 'lorebookAfter', injectionDepth: 4,
      injectionRole: 'system', probability: 100, sticky: 0, cooldown: 0, delay: 0
    };
  }
  function parseResourceEntry(entry) {
    if (!entry || String(entry.identifier || '').indexOf(RESOURCE_ENTRY_PREFIX) !== 0) return null;
    try {
      var value = safeJson(String(entry.content || ''), 'resource entry');
      return value && value.spec === RESOURCE_RECORD_SPEC ? normalizeResourceRecord(value) : null;
    } catch (ignored) { return null; }
  }
  function entryArray(value) {
    if (Array.isArray(value)) return clone(value);
    return Object.keys(value || {}).map(function (key) { return clone(value[key]); });
  }
  function entryIdentityKeys(entry, index) {
    var keys = [];
    var identifier = optionalName(entry && entry.identifier);
    if (identifier) keys.push('identifier:' + identifier);
    if (entry && entry.uid != null && String(entry.uid).trim()) keys.push('uid:' + String(entry.uid).trim());
    var name = optionalName(entry && (entry.name || entry.comment || entry.title));
    if (name) keys.push('name:' + name);
    if (!keys.length) keys.push('content:' + fnv1a(JSON.stringify(entry || {}) + ':' + index));
    return keys;
  }
  function entryIdentity(entry, index) {
    return entryIdentityKeys(entry, index)[0];
  }
  function normalizeLorebookEntry(entry, index) {
    var output = clone(entry || {}), identity = entryIdentity(output, index);
    if (!optionalName(output.identifier)) output.identifier = 'aster-entry-' + fnv1a(identity);
    if (!optionalName(output.name || output.comment)) output.name = output.identifier || ('\u6761\u76ee ' + (index + 1));
    return output;
  }
  function matchingEntryPositions(output, row, index) {
    var wanted = entryIdentityKeys(row, index), matches = [];
    output.forEach(function (candidate, candidateIndex) {
      var keys = entryIdentityKeys(candidate, candidateIndex);
      for (var keyIndex = 0; keyIndex < wanted.length; keyIndex += 1) {
        if (keys.indexOf(wanted[keyIndex]) < 0) continue;
        matches.push(candidateIndex); break;
      }
    });
    return matches;
  }
  function mergeLorebookEntries(existing, incoming) {
    var output = [];
    entryArray(existing).forEach(function (entry, index) {
      var row = normalizeLorebookEntry(entry, index);
      if (!matchingEntryPositions(output, row, index).length) output.push(row);
    });
    entryArray(incoming).forEach(function (entry, index) {
      var row = normalizeLorebookEntry(entry, index), matches = matchingEntryPositions(output, row, index);
      if (!matches.length) { output.push(row); return; }
      var target = matches[0];
      output = output.filter(function (_, position) { return position === target || matches.indexOf(position) < 0; });
      target = matches.reduce(function (value, position) { return position < target ? value - 1 : value; }, target);
      output[target] = row;
    });
    return output;
  }

  async function scanAsterModules() {
    var summaries = await tavo.lorebook.all();
    var current = null;
    try { current = await tavo.chat.current(); } catch (ignored) {}
    var active = Object.create(null);
    ((current && current.lorebooks) || []).forEach(function (row) { var id = idOf(row); if (id != null) active[String(id)] = true; });
    var books = [], groups = Object.create(null);
    for (var bookIndex = 0; bookIndex < (summaries || []).length; bookIndex += 1) {
      var summary = summaries[bookIndex], book = await tavo.lorebook.get(summary.id);
      if (!book) continue;
      var entries = entryArray(book.entries), record = { id: book.id, name: book.name, book: book, entries: entries };
      books.push(record);
      entries.forEach(function (entry, entryIndex) {
        var meta = asterModuleMeta(entry); if (!meta) return;
        if (!groups[meta.id]) groups[meta.id] = [];
        groups[meta.id].push({
          moduleId: meta.id, version: meta.version, bookId: book.id, bookName: book.name,
          entryIndex: entryIndex, active: !!active[String(book.id)], canonical: !!ASTER_CANONICAL_BOOKS[book.name]
        });
      });
    }
    var duplicateIds = Object.keys(groups).filter(function (id) { return groups[id].length > 1; }).sort();
    return {
      books: books, groups: groups, duplicateIds: duplicateIds,
      duplicateOccurrences: duplicateIds.reduce(function (total, id) { return total + groups[id].length - 1; }, 0)
    };
  }

  function chooseAsterModule(group, preferredBooks) {
    return group.slice().sort(function (left, right) {
      var preferredId = preferredBooks[left.bookName] != null ? String(preferredBooks[left.bookName]) : '';
      var leftPreferred = preferredId && String(left.bookId) === preferredId ? 1 : 0;
      var rightPreferredId = preferredBooks[right.bookName] != null ? String(preferredBooks[right.bookName]) : '';
      var rightPreferred = rightPreferredId && String(right.bookId) === rightPreferredId ? 1 : 0;
      if (leftPreferred !== rightPreferred) return rightPreferred - leftPreferred;
      var versionOrder = compareVersion(left.version, right.version);
      if (versionOrder) return -versionOrder;
      if (left.active !== right.active) return left.active ? -1 : 1;
      if (left.canonical !== right.canonical) return left.canonical ? -1 : 1;
      var leftNumber = Number(left.bookId), rightNumber = Number(right.bookId);
      if (Number.isFinite(leftNumber) && Number.isFinite(rightNumber) && leftNumber !== rightNumber) return leftNumber - rightNumber;
      var bookOrder = String(left.bookId).localeCompare(String(right.bookId));
      return bookOrder || left.entryIndex - right.entryIndex;
    })[0];
  }

  function getCrcTable() {
    if (crcTable) return crcTable;
    crcTable = new Uint32Array(256);
    for (var n = 0; n < 256; n += 1) {
      var value = n;
      for (var bit = 0; bit < 8; bit += 1) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
      crcTable[n] = value >>> 0;
    }
    return crcTable;
  }

  function crc32(bytes) {
    var table = getCrcTable();
    var crc = 0xffffffff;
    for (var index = 0; index < bytes.length; index += 1) crc = table[(crc ^ bytes[index]) & 0xff] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }

  function archivePath(value, label) {
    if (typeof value !== 'string' || !value || value.length > 240) fail('E_ZIP_PATH', label + ': invalid archive path');
    if (value !== value.normalize('NFC')) fail('E_ZIP_PATH_NORMALIZATION', label + ': path must use NFC Unicode');
    if (value.indexOf('\0') >= 0 || value.indexOf('\\') >= 0 || value[0] === '/' || /^[A-Za-z]:/.test(value)) {
      fail('E_ZIP_PATH', label + ': unsafe archive path ' + value);
    }
    var segments = value.split('/');
    if (segments.some(function (segment) { return !segment || segment === '.' || segment === '..'; })) {
      fail('E_ZIP_PATH', label + ': unsafe archive path ' + value);
    }
    return value;
  }

  function fileName(value, label) {
    if (typeof value !== 'string' || !value || value.length > 160 || /[\\/:]/.test(value) || value.indexOf('..') >= 0) {
      fail('E_TARGET_NAME', label + ': invalid Tavo file name');
    }
    return value;
  }

  async function inflateRaw(bytes, label) {
    if (typeof DecompressionStream !== 'function') fail('E_ZIP_DEFLATE_UNSUPPORTED', label + ': DecompressionStream is unavailable');
    try {
      var stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
      return new Uint8Array(await new Response(stream).arrayBuffer());
    } catch (error) {
      fail('E_ZIP_DEFLATE', label + ': deflate stream could not be decompressed (' + messageOf(error) + ')');
    }
  }

  async function parseZip(input, label, options) {
    var limits = Object.assign({}, DEFAULT_LIMITS, options || {});
    var bytes = input instanceof Uint8Array ? input : new Uint8Array(input || 0);
    if (bytes.length < 22) fail('E_ZIP_TRUNCATED', label + ': ZIP is too small');
    if (bytes.length > limits.maxArchive) fail('E_ZIP_ARCHIVE_LIMIT', label + ': ZIP exceeds archive limit');
    var view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    var minimum = Math.max(0, bytes.length - 22 - 0xffff);
    var eocd = -1;
    for (var cursor = bytes.length - 22; cursor >= minimum; cursor -= 1) {
      if (view.getUint32(cursor, true) === 0x06054b50) { eocd = cursor; break; }
    }
    if (eocd < 0) fail('E_ZIP_EOCD', label + ': end-of-central-directory record not found');
    var commentLength = view.getUint16(eocd + 20, true);
    if (eocd + 22 + commentLength !== bytes.length) fail('E_ZIP_TRAILING_DATA', label + ': trailing or truncated ZIP data');
    var disk = view.getUint16(eocd + 4, true);
    var centralDisk = view.getUint16(eocd + 6, true);
    var entriesOnDisk = view.getUint16(eocd + 8, true);
    var entryCount = view.getUint16(eocd + 10, true);
    var centralSize = view.getUint32(eocd + 12, true);
    var centralOffset = view.getUint32(eocd + 16, true);
    if (disk || centralDisk || entriesOnDisk !== entryCount) fail('E_ZIP_MULTIDISK', label + ': multi-disk ZIP is unsupported');
    if (entryCount === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff) fail('E_ZIP64', label + ': ZIP64 is unsupported');
    if (entryCount < 1 || entryCount > limits.maxEntries) fail('E_ZIP_ENTRY_LIMIT', label + ': invalid entry count ' + entryCount);
    if (centralOffset + centralSize !== eocd) fail('E_ZIP_CENTRAL_RANGE', label + ': invalid central directory range');

    var metadata = [];
    var names = new Set();
    var total = 0;
    cursor = centralOffset;
    for (var entryIndex = 0; entryIndex < entryCount; entryIndex += 1) {
      if (cursor + 46 > eocd || view.getUint32(cursor, true) !== 0x02014b50) fail('E_ZIP_CENTRAL', label + ': invalid central directory entry');
      var flags = view.getUint16(cursor + 8, true);
      var method = view.getUint16(cursor + 10, true);
      var expectedCrc = view.getUint32(cursor + 16, true);
      var compressedSize = view.getUint32(cursor + 20, true);
      var uncompressedSize = view.getUint32(cursor + 24, true);
      var nameLength = view.getUint16(cursor + 28, true);
      var extraLength = view.getUint16(cursor + 30, true);
      var entryCommentLength = view.getUint16(cursor + 32, true);
      var externalAttributes = view.getUint32(cursor + 38, true);
      var localOffset = view.getUint32(cursor + 42, true);
      var end = cursor + 46 + nameLength + extraLength + entryCommentLength;
      if (!nameLength || end > eocd) fail('E_ZIP_CENTRAL', label + ': truncated central directory entry');
      var name = archivePath(decodeUtf8(bytes.subarray(cursor + 46, cursor + 46 + nameLength), label + ' entry name'), label);
      if (names.has(name)) fail('E_ZIP_DUPLICATE', label + ': duplicate entry ' + name);
      names.add(name);
      if (flags & 1) fail('E_ZIP_ENCRYPTED', label + ': encrypted entry ' + name + ' is unsupported');
      if (method !== 0 && method !== 8) fail('E_ZIP_METHOD', label + ': unsupported compression method for ' + name);
      if (compressedSize === 0xffffffff || uncompressedSize === 0xffffffff || localOffset === 0xffffffff) fail('E_ZIP64', label + ': ZIP64 entry is unsupported');
      if (uncompressedSize > limits.maxFile) fail('E_ZIP_FILE_LIMIT', label + ': entry exceeds file limit: ' + name);
      total += uncompressedSize;
      if (total > limits.maxTotal) fail('E_ZIP_TOTAL_LIMIT', label + ': total uncompressed size exceeds limit');
      if (compressedSize > 0 && uncompressedSize > 1024 * 1024 && uncompressedSize / compressedSize > limits.maxRatio) {
        fail('E_ZIP_RATIO', label + ': suspicious compression ratio for ' + name);
      }
      var mode = (externalAttributes >>> 16) & 0xffff;
      if ((mode & 0xf000) === 0xa000) fail('E_ZIP_SYMLINK', label + ': symbolic link rejected: ' + name);
      if (localOffset + 30 > centralOffset || view.getUint32(localOffset, true) !== 0x04034b50) fail('E_ZIP_LOCAL', label + ': invalid local header for ' + name);
      var localNameLength = view.getUint16(localOffset + 26, true);
      var localExtraLength = view.getUint16(localOffset + 28, true);
      var localName = decodeUtf8(bytes.subarray(localOffset + 30, localOffset + 30 + localNameLength), label + ' local name');
      if (localName !== name) fail('E_ZIP_NAME_MISMATCH', label + ': central/local name mismatch for ' + name);
      var dataOffset = localOffset + 30 + localNameLength + localExtraLength;
      if (dataOffset + compressedSize > centralOffset) fail('E_ZIP_DATA_RANGE', label + ': invalid data range for ' + name);
      metadata.push({ name: name, method: method, crc: expectedCrc, compressedSize: compressedSize, uncompressedSize: uncompressedSize, dataOffset: dataOffset });
      cursor = end;
    }
    if (cursor !== eocd) fail('E_ZIP_CENTRAL_SIZE', label + ': central directory size mismatch');

    var files = new Map();
    for (var metaIndex = 0; metaIndex < metadata.length; metaIndex += 1) {
      var meta = metadata[metaIndex];
      var compressed = bytes.subarray(meta.dataOffset, meta.dataOffset + meta.compressedSize);
      var content = meta.method === 0 ? new Uint8Array(compressed) : await inflateRaw(compressed, label + '/' + meta.name);
      if (content.length !== meta.uncompressedSize) fail('E_ZIP_SIZE', label + ': uncompressed size mismatch for ' + meta.name);
      if (crc32(content) !== meta.crc) fail('E_ZIP_CRC', label + ': CRC mismatch for ' + meta.name);
      files.set(meta.name, content);
    }
    return files;
  }

  function payloadName(type, value) {
    if (type === 'character' || type === 'lorebook' || type === 'preset' || type === 'regex' || type === 'theme') return String(value && value.name || '');
    return '';
  }

  function entriesCount(type, value) {
    if (type !== 'lorebook' && type !== 'preset' && type !== 'regex') return null;
    var entries = value && value.entries;
    if (Array.isArray(entries)) return entries.length;
    if (entries && typeof entries === 'object') return Object.keys(entries).length;
    return 0;
  }

  function sameJsonValue(left, right) {
    if (left === right) return true;
    if (Array.isArray(left) || Array.isArray(right)) {
      if (!Array.isArray(left) || !Array.isArray(right) || left.length !== right.length) return false;
      for (var arrayIndex = 0; arrayIndex < left.length; arrayIndex += 1) {
        if (!sameJsonValue(left[arrayIndex], right[arrayIndex])) return false;
      }
      return true;
    }
    if (isObject(left) || isObject(right)) {
      if (!isObject(left) || !isObject(right)) return false;
      var leftKeys = Object.keys(left);
      var rightKeys = Object.keys(right);
      if (leftKeys.length !== rightKeys.length) return false;
      for (var keyIndex = 0; keyIndex < leftKeys.length; keyIndex += 1) {
        var key = leftKeys[keyIndex];
        if (!own(right, key) || !sameJsonValue(left[key], right[key])) return false;
      }
      return true;
    }
    return false;
  }

  function presetEntryKey(entry) {
    if (entry && typeof entry.identifier === 'string' && entry.identifier.trim()) return 'identifier:' + entry.identifier;
    if (entry && typeof entry.name === 'string' && entry.name.trim()) return 'name:' + entry.name;
    return '';
  }

  function verifyPresetReadback(expected, actual, label) {
    var expectedEntries = Array.isArray(expected && expected.entries) ? expected.entries : [];
    var actualEntries = Array.isArray(actual && actual.entries) ? actual.entries : [];
    if (actualEntries.length < expectedEntries.length) fail('E_READBACK_PRESET_COUNT', label + ': explicit preset entries were lost during write');

    var matchedIndexes = new Set();
    var stableFields = ['identifier', 'name', 'content', 'enabled', 'active', 'type', 'role', 'injectionPosition', 'injectionDepth'];
    for (var expectedIndex = 0; expectedIndex < expectedEntries.length; expectedIndex += 1) {
      var expectedEntry = expectedEntries[expectedIndex];
      var key = presetEntryKey(expectedEntry);
      if (!key) fail('E_PRESET_ENTRY_KEY', label + ': preset entry ' + expectedIndex + ' needs identifier or name');
      var matchIndex = -1;
      for (var actualIndex = 0; actualIndex < actualEntries.length; actualIndex += 1) {
        if (!matchedIndexes.has(actualIndex) && presetEntryKey(actualEntries[actualIndex]) === key) {
          matchIndex = actualIndex;
          break;
        }
      }
      if (matchIndex < 0) fail('E_READBACK_PRESET_ENTRY', label + ': explicit preset entry missing after write (' + key + ')');
      matchedIndexes.add(matchIndex);
      var actualEntry = actualEntries[matchIndex];
      for (var fieldIndex = 0; fieldIndex < stableFields.length; fieldIndex += 1) {
        var field = stableFields[fieldIndex];
        if (own(expectedEntry, field) && !sameJsonValue(expectedEntry[field], actualEntry[field])) {
          fail('E_READBACK_PRESET_FIELD', label + ': preset entry field changed during write (' + key + '.' + field + ')');
        }
      }
    }

    if (own(expected, 'basicPrompts')) {
      if (!isObject(actual && actual.basicPrompts)) fail('E_READBACK_PRESET_PROMPTS', label + ': basicPrompts missing after write');
      var promptKeys = Object.keys(expected.basicPrompts);
      for (var promptIndex = 0; promptIndex < promptKeys.length; promptIndex += 1) {
        var promptKey = promptKeys[promptIndex];
        if (!own(actual.basicPrompts, promptKey) || !sameJsonValue(expected.basicPrompts[promptKey], actual.basicPrompts[promptKey])) {
          fail('E_READBACK_PRESET_PROMPT', label + ': basicPrompts changed during write (' + promptKey + ')');
        }
      }
    }
  }

  function verifyCharacterReadback(expected, actual, label) {
    var stableFields = [
      'name', 'description', 'personality', 'scenario', 'firstMes', 'first_mes', 'mesExample', 'mes_example',
      'creatorNotes', 'creator_notes', 'systemPrompt', 'system_prompt', 'postHistoryInstructions',
      'post_history_instructions', 'tags'
    ];
    stableFields.forEach(function (field) {
      if (own(expected, field) && !sameJsonValue(expected[field], actual && actual[field])) {
        fail('E_READBACK_CHARACTER_FIELD', label + ': character field changed during write (' + field + ')');
      }
    });
  }

  function assertEntity(type, value, label) {
    if (!isObject(value)) fail('E_ITEM_SHAPE', label + ': expected JSON object');
    var name = payloadName(type, value);
    if (!name) fail('E_ITEM_NAME', label + ': missing name');
    if (type === 'lorebook' && !(Array.isArray(value.entries) || isObject(value.entries))) fail('E_LOREBOOK_ENTRIES', label + ': entries must be an array or object');
    if ((type === 'preset' || type === 'regex') && !Array.isArray(value.entries)) fail('E_ITEM_ENTRIES', label + ': entries must be an array');
    if (type === 'preset' && own(value, 'basicPrompts') && !isObject(value.basicPrompts)) fail('E_PRESET_BASIC', label + ': basicPrompts must be an object');
    if (type === 'preset') {
      var presetKeys = new Set();
      value.entries.forEach(function (entry, index) {
        if (!isObject(entry)) fail('E_PRESET_ENTRY_SHAPE', label + ': preset entry ' + index + ' must be an object');
        var key = presetEntryKey(entry);
        if (!key) fail('E_PRESET_ENTRY_KEY', label + ': preset entry ' + index + ' needs identifier or name');
        if (presetKeys.has(key)) fail('E_PRESET_ENTRY_DUPLICATE', label + ': duplicate preset entry key ' + key);
        presetKeys.add(key);
      });
    }
    return name;
  }

  function collectResourceRefs(value, into) {
    if (typeof value === 'string') {
      value.replace(RESOURCE_TOKEN, function (_, id) { into.add(id); return _; });
      RESOURCE_TOKEN.lastIndex = 0;
      return;
    }
    if (Array.isArray(value)) { value.forEach(function (row) { collectResourceRefs(row, into); }); return; }
    if (isObject(value)) Object.keys(value).forEach(function (key) { collectResourceRefs(value[key], into); });
  }

  function replaceResourceRefs(value, results) {
    if (typeof value === 'string') {
      return value.replace(RESOURCE_TOKEN, function (_, id) {
        var target = results.get(id);
        if (!target || !target.path) fail('E_RESOURCE_REFERENCE', 'Unresolved resource reference: ' + id);
        return target.path;
      });
    }
    if (Array.isArray(value)) return value.map(function (row) { return replaceResourceRefs(row, results); });
    if (isObject(value)) {
      var object = {};
      Object.keys(value).forEach(function (key) { object[key] = replaceResourceRefs(value[key], results); });
      return object;
    }
    return value;
  }

  function themePayloadOf(envelope) {
    if (isObject(envelope && envelope.data) && typeof envelope.data.name === 'string') return envelope.data;
    if (isObject(envelope && envelope.theme) && typeof envelope.theme.name === 'string') return envelope.theme;
    if (isObject(envelope && envelope.payload) && typeof envelope.payload.name === 'string') return envelope.payload;
    return envelope;
  }

  function isNativeThemeEnvelope(envelope, payload) {
    return payload !== envelope || typeof envelope.spec === 'string' || typeof envelope.specification === 'string';
  }

  function portableThemeAssetName(item, asset, index) {
    var base = asset.split('/').pop().replace(/[^0-9A-Za-z._-]+/g, '-').replace(/\.\.+/g, '-');
    if (!base) base = 'asset.bin';
    if (base.length > 56) base = base.slice(base.length - 56);
    return fileName('aster-theme-' + item.id + '-' + index + '-' + base, item.id + ' theme asset');
  }

  function replaceThemeAssetRefs(value, assetPaths) {
    if (typeof value === 'string') {
      var normalized = value.indexOf('./') === 0 ? value.slice(2) : value;
      return assetPaths.get(value) || assetPaths.get(normalized) || value;
    }
    if (Array.isArray(value)) return value.map(function (row) { return replaceThemeAssetRefs(row, assetPaths); });
    if (isObject(value)) {
      var object = {};
      Object.keys(value).forEach(function (key) { object[key] = replaceThemeAssetRefs(value[key], assetPaths); });
      return object;
    }
    return value;
  }

  function validateManifest(manifest) {
    if (!isObject(manifest)) fail('E_MANIFEST_SHAPE', 'aster-mod.json must be an object');
    if (manifest.spec !== MOD_SPEC) fail('E_MANIFEST_SPEC', 'Unsupported Mod spec: ' + String(manifest.spec || '(missing)'));
    if (!validId(manifest.id)) fail('E_MANIFEST_ID', 'Invalid package id');
    if (typeof manifest.name !== 'string' || !manifest.name.trim()) fail('E_MANIFEST_NAME', 'Package name is required');
    if (!validSemver(manifest.version)) fail('E_MANIFEST_VERSION', 'Package version must be SemVer');
    if (!Array.isArray(manifest.items) || !manifest.items.length || manifest.items.length > 96) fail('E_MANIFEST_ITEMS', 'Package must contain 1-96 items');
    var defaultConflict = manifest.defaultConflict || 'replace';
    if (!validConflict(defaultConflict)) fail('E_MANIFEST_CONFLICT', 'Invalid defaultConflict');
    if (manifest.repair != null) {
      if (!isObject(manifest.repair)) fail('E_MANIFEST_REPAIR', 'repair must be an object');
      Object.keys(manifest.repair).forEach(function (key) { if (key !== 'asterModules') fail('E_MANIFEST_REPAIR', 'Unknown repair mode: ' + key); });
      if (manifest.repair.asterModules !== 'deduplicate') fail('E_MANIFEST_REPAIR', 'repair.asterModules must be deduplicate');
    }
    var ids = new Set();
    var paths = new Set();
    manifest.items.forEach(function (item, index) {
      var label = 'items[' + index + ']';
      if (!isObject(item) || !validId(item.id)) fail('E_ITEM_ID', label + ': invalid id');
      if (ids.has(item.id)) fail('E_ITEM_DUPLICATE_ID', label + ': duplicate id ' + item.id);
      ids.add(item.id);
      if (ALLOWED_TYPES.indexOf(item.type) < 0) fail('E_ITEM_TYPE', label + ': unsupported type ' + String(item.type));
      var safePath = archivePath(item.path, label);
      if (safePath === 'aster-mod.json') fail('E_ITEM_PATH', label + ': manifest cannot be an item payload');
      if (paths.has(safePath)) fail('E_ITEM_DUPLICATE_PATH', label + ': duplicate payload path ' + safePath);
      paths.add(safePath);
      if (typeof item.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(item.sha256)) fail('E_ITEM_HASH', label + ': sha256 is required');
      var conflict = item.conflict || defaultConflict;
      if (!validConflict(conflict)) fail('E_ITEM_CONFLICT', label + ': invalid conflict policy');
    });
    return { defaultConflict: defaultConflict, ids: ids };
  }

  async function preparePackage(bytes, source) {
    var archive = await parseZip(bytes, source.name || 'Aster Mod ZIP');
    if (!archive.has('aster-mod.json')) fail('E_MANIFEST_MISSING', 'ZIP root must contain aster-mod.json');
    var manifest = parseJsonBytes(archive.get('aster-mod.json'), 'aster-mod.json');
    var manifestInfo = validateManifest(manifest);
    var prepared = [];
    var resourceIds = new Set();
    manifest.items.forEach(function (item) { if (item.type === 'resource') resourceIds.add(item.id); });

    for (var index = 0; index < manifest.items.length; index += 1) {
      var item = clone(manifest.items[index]);
      var label = item.id;
      item.packageId = manifest.id;
      item.packageVersion = manifest.version;
      var content = archive.get(item.path);
      if (!content) fail('E_ITEM_MISSING', label + ': payload not found: ' + item.path);
      var actualHash = await sha256(content);
      if (actualHash !== item.sha256) fail('E_ITEM_HASH_MISMATCH', label + ': SHA-256 mismatch');
      item.conflict = item.conflict || manifestInfo.defaultConflict;
      item.bytes = content;
      item.data = null;
      item.name = typeof item.name === 'string' ? item.name : '';
      item.scope = scopeOf(item.scope, item.type === 'resource' ? 'global' : 'chat');

      if (item.type === 'resource') {
        item.targetName = fileName(item.targetName || item.path.split('/').pop(), label);
      } else if (item.type === 'themePackage') {
        if (!/\.thm$/i.test(item.path)) fail('E_THEME_EXTENSION', label + ': themePackage path must end in .thm');
        var themeArchive = await parseZip(content, label + '.thm', { maxArchive: 64 * 1024 * 1024, maxEntries: 16, maxTotal: 256 * 1024 * 1024 });
        if (!themeArchive.has('theme.json')) fail('E_THEME_MANIFEST', label + ': .thm must contain theme.json');
        var themeEnvelope = parseJsonBytes(themeArchive.get('theme.json'), label + '/theme.json');
        var themeData = themePayloadOf(themeEnvelope);
        if (!isObject(themeEnvelope) || !isObject(themeData) || typeof themeData.name !== 'string' || !themeData.name) fail('E_THEME_NAME', label + ': theme.json requires a named ChatTheme payload');
        if (item.name && item.name !== themeData.name) fail('E_THEME_NAME_MISMATCH', label + ': manifest and theme.json names differ');
        item.name = themeData.name;
        item.themeData = themeData;
        item.themeFormat = isNativeThemeEnvelope(themeEnvelope, themeData) ? 'native' : 'portable';
        item.themeAssets = [];
        themeArchive.forEach(function (assetBytes, assetPath) {
          if (assetPath !== 'theme.json') item.themeAssets.push({ name: assetPath, bytes: assetBytes });
        });
        item.targetName = fileName(item.targetName || ('aster-mod-' + item.id + '.thm'), label);
      } else {
        item.data = parseJsonBytes(content, item.path);
        if (item.type === 'variables') {
          if (!isObject(item.data) || !isObject(item.data.values)) fail('E_VARIABLES_SHAPE', label + ': variables payload requires values object');
          var variableKeys = Object.keys(item.data.values);
          if (!variableKeys.length || variableKeys.length > 200) fail('E_VARIABLES_COUNT', label + ': variables payload must contain 1-200 keys');
          variableKeys.forEach(function (key) {
            if (!key || key.length > 160 || key === '__proto__' || key === 'constructor' || key === 'prototype') fail('E_VARIABLE_KEY', label + ': unsafe variable key');
          });
          item.scope = scopeOf(item.data.scope, item.scope);
        } else {
          var dataName = assertEntity(item.type, item.data, label);
          if (item.name && item.name !== dataName) fail('E_ITEM_NAME_MISMATCH', label + ': manifest and payload names differ');
          item.name = dataName;
        }
      }

      var referencePayload = item.data || (item.type === 'themePackage' && item.themeFormat === 'portable' ? item.themeData : null);
      if (referencePayload) {
        var refs = new Set();
        collectResourceRefs(referencePayload, refs);
        refs.forEach(function (id) { if (!resourceIds.has(id)) fail('E_RESOURCE_REFERENCE', label + ': unknown resource reference ' + id); });
        item.resourceRefs = Array.from(refs);
      }
      prepared.push(item);
    }

    if (manifest.activate != null) {
      if (!isObject(manifest.activate) || !isObject(manifest.activate.chat)) fail('E_ACTIVATE_SHAPE', 'activate.chat must be an object');
      var activation = manifest.activate.chat;
      if (activation.mode && activation.mode !== 'merge' && activation.mode !== 'replace') fail('E_ACTIVATE_MODE', 'activate.chat.mode must be merge or replace');
      ['lorebooks', 'regexes'].forEach(function (field) {
        if (activation[field] == null) return;
        if (!Array.isArray(activation[field])) fail('E_ACTIVATE_LIST', 'activate.chat.' + field + ' must be an array');
        activation[field].forEach(function (id) { if (!manifestInfo.ids.has(id)) fail('E_ACTIVATE_REFERENCE', 'Unknown activation item: ' + id); });
      });
      ['preset', 'theme'].forEach(function (field) {
        if (activation[field] != null && !manifestInfo.ids.has(activation[field])) fail('E_ACTIVATE_REFERENCE', 'Unknown activation item: ' + activation[field]);
      });
      var byId = new Map(prepared.map(function (item) { return [item.id, item]; }));
      (activation.lorebooks || []).forEach(function (id) { if (byId.get(id).type !== 'lorebook') fail('E_ACTIVATE_TYPE', id + ' is not a lorebook'); });
      (activation.regexes || []).forEach(function (id) { if (byId.get(id).type !== 'regex') fail('E_ACTIVATE_TYPE', id + ' is not a regex'); });
      if (activation.preset && byId.get(activation.preset).type !== 'preset') fail('E_ACTIVATE_TYPE', activation.preset + ' is not a preset');
      if (activation.theme && ['theme', 'themePackage'].indexOf(byId.get(activation.theme).type) < 0) fail('E_ACTIVATE_TYPE', activation.theme + ' is not a theme');
    }

    return {
      source: source,
      sourceSha256: await sha256(bytes),
      manifest: manifest,
      items: prepared,
      archiveEntries: archive.size
    };
  }

  async function findExactMatches(api, name) {
    var found = await api.find(name, { match: 'exact' });
    var matches = [], seen = Object.create(null);
    for (var index = 0; index < (found || []).length; index += 1) {
      var id = idOf(found[index]);
      if (id == null || seen[String(id)]) continue;
      seen[String(id)] = true;
      var full = await api.get(id);
      if (full && full.name === name) matches.push(full);
    }
    return matches;
  }

  async function findExact(api, name) {
    var matches = await findExactMatches(api, name);
    return matches.length ? matches[0] : null;
  }

  function boundEntityIds(type, current) {
    current = current || {};
    if (type === 'lorebook') return idsFrom(current.lorebooks);
    if (type === 'regex') return idsFrom(current.regexes);
    if (type === 'character') {
      var characterIds = idsFrom(current.characters);
      if (idOf(current.character) != null) characterIds.push(idOf(current.character));
      return uniqueIds(characterIds);
    }
    if (type === 'preset') return idOf(current.preset) == null ? [] : [idOf(current.preset)];
    if (type === 'theme' || type === 'themePackage') return idOf(current.theme) == null ? [] : [idOf(current.theme)];
    return [];
  }

  function chooseExactMatch(type, matches, current) {
    var bound = boundEntityIds(type, current).map(String);
    for (var index = 0; index < bound.length; index += 1) {
      var active = matches.find(function (row) { return String(idOf(row)) === bound[index]; });
      if (active) return active;
    }
    return matches.length ? matches[0] : null;
  }

  async function uniqueEntityName(api, base) {
    if (!await findExact(api, base)) return base;
    for (var index = 2; index <= 999; index += 1) {
      var candidate = base + ' (' + index + ')';
      if (!await findExact(api, candidate)) return candidate;
    }
    fail('E_RENAME_EXHAUSTED', 'Could not allocate a unique name for ' + base);
  }

  function apiFor(type) {
    if (type === 'character') return tavo.character;
    if (type === 'lorebook') return tavo.lorebook;
    if (type === 'preset') return tavo.preset;
    if (type === 'regex') return tavo.regex;
    if (type === 'theme' || type === 'themePackage') return tavo.theme;
    return null;
  }

  async function uniqueFileName(base, scope) {
    if (!await tavo.file.exists(base, { scope: scope })) return base;
    var dot = base.lastIndexOf('.');
    var stem = dot > 0 ? base.slice(0, dot) : base;
    var extension = dot > 0 ? base.slice(dot) : '';
    for (var index = 2; index <= 999; index += 1) {
      var candidate = stem + ' (' + index + ')' + extension;
      if (!await tavo.file.exists(candidate, { scope: scope })) return candidate;
    }
    fail('E_RENAME_EXHAUSTED', 'Could not allocate a unique file name for ' + base);
  }

  async function buildPlan(prepared) {
    var planItems = [];
    var current = null;
    try { current = await tavo.chat.current(); } catch (ignored) {}
    var sorted = prepared.items.slice().sort(function (left, right) {
      var order = TYPE_ORDER[left.type] - TYPE_ORDER[right.type];
      return order || left.id.localeCompare(right.id);
    });
    for (var index = 0; index < sorted.length; index += 1) {
      var item = sorted[index];
      var row = Object.assign({}, item, { action: 'create', existing: null });
      if (item.type === 'resource') {
        var exists = await tavo.file.exists(item.targetName, { scope: item.scope });
        row.existing = exists ? { name: item.targetName } : null;
        if (exists && item.conflict === 'error') fail('E_CONFLICT', item.id + ': file already exists: ' + item.targetName);
        if (exists && item.conflict === 'skip') row.action = 'skip';
        else if (exists && item.conflict === 'rename') { row.targetName = await uniqueFileName(item.targetName, item.scope); row.action = 'create'; }
        else row.action = exists ? 'replace' : 'create';
      } else if (item.type === 'variables') {
        row.action = 'set';
      } else {
        var api = apiFor(item.type);
        var exactMatches = await findExactMatches(api, item.name);
        var existing = chooseExactMatch(item.type, exactMatches, current);
        row.existing = existing;
        row.exactMatches = exactMatches;
        row.staleExactMatches = existing ? exactMatches.filter(function (match) { return String(idOf(match)) !== String(idOf(existing)); }) : [];
        if (existing && item.conflict === 'error') fail('E_CONFLICT', item.id + ': entity already exists: ' + item.name);
        if (existing && item.conflict === 'skip') row.action = 'skip';
        else if (existing && item.conflict === 'rename') {
          if (item.type === 'themePackage' && item.themeFormat === 'native') fail('E_THEME_RENAME', item.id + ': native themePackage rename must be chosen in Tavo import dialog');
          row.name = await uniqueEntityName(api, item.name);
          row.action = 'create';
        } else if (item.type === 'themePackage') row.action = existing ? 'replace' : 'import';
        else row.action = existing ? 'replace' : 'create';
      }
      planItems.push(row);
    }
    var summary = { items: planItems.length, creates: 0, updates: 0, skips: 0, sets: 0, repairs: 0, repairModuleIds: 0, staleExactNames: 0 };
    planItems.forEach(function (item) {
      if (item.action === 'skip') summary.skips += 1;
      else if (item.action === 'replace') summary.updates += 1;
      else if (item.action === 'set') summary.sets += 1;
      else summary.creates += 1;
      if (item.action === 'replace') summary.staleExactNames += (item.staleExactMatches || []).length;
    });
    var asterRepair = null;
    if (prepared.manifest.repair && prepared.manifest.repair.asterModules === 'deduplicate') {
      asterRepair = await scanAsterModules();
      summary.repairs = asterRepair.duplicateOccurrences;
      summary.repairModuleIds = asterRepair.duplicateIds.length;
    }
    return { prepared: prepared, items: planItems, summary: summary, asterRepair: asterRepair };
  }

  function configBoolean(key, fallback) {
    try {
      var value = tavo.plugin.config.get(key);
      return typeof value === 'boolean' ? value : fallback;
    } catch (error) { return fallback; }
  }

  async function confirmPlan(plan) {
    if (!configBoolean('confirmBeforeCommit', true)) return true;
    var response = await tavo.utils.ask({
      question: tr('runtime.confirmQuestion', {
        name: plan.prepared.manifest.name,
        version: plan.prepared.manifest.version,
        items: plan.summary.items,
        creates: plan.summary.creates,
        updates: plan.summary.updates,
        skips: plan.summary.skips,
        staleExactNames: plan.summary.staleExactNames,
        repairs: plan.summary.repairs,
        repairModuleIds: plan.summary.repairModuleIds
      }),
      options: [
        { value: 'import', label: tr('runtime.confirmImport') },
        { value: 'cancel', label: tr('runtime.confirmCancel') }
      ],
      allowOther: false,
      defaultValue: 'import'
    });
    return !!response && response.status === 'answered' && response.answer === 'import';
  }

  function equalJson(left, right) { return JSON.stringify(left) === JSON.stringify(right); }
  function idsFrom(value) { return (value || []).map(idOf).filter(function (id) { return id != null; }); }
  function uniqueIds(value) { return value.filter(function (id, index) { return value.indexOf(id) === index; }); }

  function recordForResource(item, path, storedName, overrides) {
    var now = new Date().toISOString();
    return normalizeResourceRecord(Object.assign({
      assetId: item.packageId + ':' + item.id,
      manifestItemId: item.id,
      packageId: item.packageId,
      packageVersion: item.packageVersion,
      name: item.name || storedName,
      storedName: storedName,
      path: path,
      scope: item.scope,
      kind: inferResourceKind(storedName, item.mime),
      mime: item.mime || inferMime(storedName),
      sha256: item.sha256,
      size: item.bytes && item.bytes.length,
      source: 'mod-package',
      exists: true,
      localState: 'ready',
      render: { localized: true, state: 'ready', path: path, lookupName: storedName, verifiedSha256: item.sha256 },
      createdAt: now,
      updatedAt: now,
      lastCheckedAt: now,
      references: []
    }, overrides || {}));
  }

  async function verifiedCanonicalResource(item, results, additionalRows) {
    var candidates = [];
    results.forEach(function (result) {
      if (result && result.resource) candidates.push(result.resource);
      if (result && Array.isArray(result.resources)) candidates = candidates.concat(result.resources);
    });
    candidates = candidates.concat(additionalRows || []);
    var indexed = tavo.get(RESOURCE_INDEX_KEY, item.scope);
    if (Array.isArray(indexed)) candidates = candidates.concat(indexed);
    candidates = mergeResourceRows([], candidates).filter(function (candidate) {
      return candidate.scope === item.scope && candidate.sha256 && candidate.sha256 === item.sha256 && candidate.localState !== 'missing';
    });
    for (var index = 0; index < candidates.length; index += 1) {
      var candidate = normalizeResourceRecord(candidates[index]), loaded = null;
      try { loaded = await tavo.file.load(candidate.path, { encoding: 'base64' }); }
      catch (pathError) {
        try { loaded = await tavo.file.load(candidate.storedName, { scope: candidate.scope, encoding: 'base64' }); }
        catch (nameError) { loaded = null; }
      }
      if (loaded == null) continue;
      try {
        if (await sha256(base64ToBytes(loaded)) === item.sha256) return candidate;
      } catch (hashError) {}
    }
    return null;
  }

  function aliasResourceRecord(item, canonical) {
    var aliasId = item.packageId + ':' + item.id;
    return normalizeResourceRecord(Object.assign({}, canonical, {
      aliases: uniqueIds((canonical.aliases || []).concat([item.targetName, aliasId])),
      packageItems: uniqueIds((canonical.packageItems || []).concat([aliasId])),
      source: canonical.source || 'mod-package-deduplicated',
      deduplicated: true,
      updatedAt: new Date().toISOString()
    }));
  }

  async function commitResource(item, results, journal, operations) {
    if (item.action === 'skip') {
      var skippedPath = tavo.file.url(item.targetName, item.scope);
      results.set(item.id, { path: skippedPath, name: item.targetName, skipped: true, resource: recordForResource(item, skippedPath, item.targetName, { source: 'mod-package-skip' }) });
      operations.push({ itemId: item.id, type: item.type, action: 'skip', target: skippedPath, verified: true });
      return;
    }
    var canonical = await verifiedCanonicalResource(item, results);
    if (canonical) {
      var aliasRecord = aliasResourceRecord(item, canonical);
      results.set(item.id, { path: aliasRecord.path, name: aliasRecord.storedName, deduplicated: true, resource: aliasRecord });
      operations.push({ itemId: item.id, type: item.type, action: 'deduplicate', target: aliasRecord.path, canonicalAssetId: aliasRecord.assetId || '', sha256: item.sha256, verified: true });
      return;
    }
    var existed = await tavo.file.exists(item.targetName, { scope: item.scope });
    var backup = existed ? await tavo.file.load(item.targetName, { scope: item.scope, encoding: 'base64' }) : null;
    var savedPath = await tavo.file.save(item.targetName, bytesToBase64(item.bytes), { scope: item.scope, encoding: 'base64' });
    journal.push(async function () {
      if (existed) await tavo.file.save(item.targetName, backup, { scope: item.scope, encoding: 'base64' });
      else await tavo.file.delete(savedPath);
    });
    if (!await tavo.file.exists(savedPath)) fail('E_READBACK_FILE', item.id + ': file write did not persist');
    var readback = base64ToBytes(await tavo.file.load(savedPath, { encoding: 'base64' }));
    if (await sha256(readback) !== item.sha256) fail('E_READBACK_HASH', item.id + ': file readback hash mismatch');
    results.set(item.id, { path: savedPath, name: item.targetName, resource: recordForResource(item, savedPath, item.targetName) });
    operations.push({ itemId: item.id, type: item.type, action: item.action, target: savedPath, verified: true });
  }

  async function commitEntity(item, results, journal, operations) {
    var api = apiFor(item.type);
    if (item.action === 'skip') {
      results.set(item.id, { id: item.existing.id, name: item.existing.name, skipped: true });
      operations.push({ itemId: item.id, type: item.type, action: 'skip', target: item.existing.name, id: item.existing.id, verified: true });
      return;
    }
    var payload = replaceResourceRefs(clone(item.data), results);
    if (item.type === 'lorebook' && item.action === 'replace') {
      var exactBooks = (item.exactMatches || []).filter(function (book) {
        return String(idOf(book)) !== String(idOf(item.existing));
      }).concat([item.existing]);
      var mergedEntries = [];
      exactBooks.forEach(function (book) {
        mergedEntries = mergeLorebookEntries(mergedEntries, book && book.entries);
      });
      payload = Object.assign({}, clone(item.existing), payload, { entries: mergeLorebookEntries(mergedEntries, payload.entries) });
    }
    delete payload.id;
    payload.name = item.name;
    var entityId;
    if (item.action === 'replace') {
      var backup = clone(item.existing);
      var updateResult;
      if (item.type === 'theme') {
        updateResult = await api.update(item.existing.id, payload);
        journal.push(async function () { var restore = clone(backup); delete restore.id; await api.update(item.existing.id, restore); });
      } else {
        payload.id = item.existing.id;
        updateResult = await api.update(payload);
        journal.push(async function () { await api.update(backup); });
      }
      if (updateResult === null) fail('E_WRITE_CANCELLED', item.id + ': Tavo write was cancelled');
      entityId = idOf(updateResult);
      if (entityId == null) entityId = item.existing.id;
    } else {
      entityId = idOf(await api.create(payload));
      journal.push(async function () { await api.delete(entityId); });
    }
    if (entityId == null) fail('E_WRITE_CANCELLED', item.id + ': Tavo write was cancelled');
    var readback = await api.get(entityId);
    if (!readback || readback.name !== payload.name) fail('E_READBACK_ENTITY', item.id + ': entity readback failed');
    var expectedCount = entriesCount(item.type, payload);
    var actualCount = entriesCount(item.type, readback);
    if (item.type === 'preset') verifyPresetReadback(payload, readback, item.id);
    else if (item.type === 'character') verifyCharacterReadback(payload, readback, item.id);
    else if (expectedCount != null && actualCount !== expectedCount) fail('E_READBACK_COUNT', item.id + ': entry count changed during write');
    results.set(item.id, { id: entityId, name: readback.name });
    operations.push({ itemId: item.id, type: item.type, action: item.action, target: readback.name, id: entityId, entries: actualCount, entriesExpected: expectedCount, entriesActual: actualCount, verified: true });
  }

  async function commitThemePackage(item, results, journal, cleanup, operations) {
    if (item.action === 'skip') {
      results.set(item.id, { id: item.existing.id, name: item.existing.name, skipped: true });
      operations.push({ itemId: item.id, type: item.type, action: 'skip', target: item.existing.name, id: item.existing.id, verified: true });
      return;
    }
    if (item.themeFormat === 'portable') {
      var assetPaths = new Map();
      var assetRecords = [];
      for (var assetIndex = 0; assetIndex < item.themeAssets.length; assetIndex += 1) {
        var asset = item.themeAssets[assetIndex];
        var assetTarget = portableThemeAssetName(item, asset.name, assetIndex);
        var assetHash = await sha256(asset.bytes);
        var assetItem = Object.assign({}, item, {
          id: item.id + '.asset.' + assetIndex,
          name: baseName(asset.name), targetName: assetTarget, scope: 'global', sha256: assetHash, bytes: asset.bytes
        });
        var assetCanonical = await verifiedCanonicalResource(assetItem, results, assetRecords);
        if (assetCanonical) {
          var reusedRecord = aliasResourceRecord(assetItem, assetCanonical);
          assetPaths.set(asset.name, reusedRecord.path);
          assetRecords.push(reusedRecord);
          continue;
        }
        var assetExisted = await tavo.file.exists(assetTarget, { scope: 'global' });
        var assetBackup = assetExisted ? await tavo.file.load(assetTarget, { scope: 'global', encoding: 'base64' }) : null;
        var assetPath = await tavo.file.save(assetTarget, bytesToBase64(asset.bytes), { scope: 'global', encoding: 'base64' });
        (function (target, savedPath, existed, backup) {
          journal.push(async function () {
            if (existed) await tavo.file.save(target, backup, { scope: 'global', encoding: 'base64' });
            else await tavo.file.delete(savedPath);
          });
        })(assetTarget, assetPath, assetExisted, assetBackup);
        var assetReadback = base64ToBytes(await tavo.file.load(assetPath, { encoding: 'base64' }));
        if (await sha256(assetReadback) !== assetHash) fail('E_READBACK_THEME_ASSET', item.id + ': embedded theme asset hash mismatch (' + asset.name + ')');
        assetPaths.set(asset.name, assetPath);
        assetRecords.push(recordForResource(assetItem, assetPath, assetTarget, { source: 'mod-theme-asset', references: [item.id], themeAsset: asset.name }));
      }

      var payload = replaceThemeAssetRefs(clone(item.themeData), assetPaths);
      payload = replaceResourceRefs(payload, results);
      delete payload.id;
      payload.name = item.name;
      var portableId;
      if (item.action === 'replace') {
        var portableBackup = clone(item.existing);
        var portableUpdate = await tavo.theme.update(item.existing.id, payload);
        journal.push(async function () { var restore = clone(portableBackup); delete restore.id; await tavo.theme.update(item.existing.id, restore); });
        if (portableUpdate === null) fail('E_WRITE_CANCELLED', item.id + ': portable theme update was cancelled');
        portableId = idOf(portableUpdate);
        if (portableId == null) portableId = item.existing.id;
      } else {
        portableId = idOf(await tavo.theme.create(payload));
        journal.push(async function () { await tavo.theme.delete(portableId); });
      }
      if (portableId == null) fail('E_WRITE_CANCELLED', item.id + ': portable theme write was cancelled');
      var portableReadback = await tavo.theme.get(portableId);
      if (!portableReadback || portableReadback.name !== payload.name) fail('E_READBACK_THEME', item.id + ': portable theme readback failed');
      results.set(item.id, { id: portableId, name: portableReadback.name, resources: assetRecords });
      operations.push({ itemId: item.id, type: item.type, action: item.action, format: 'portable', transport: item.action === 'replace' ? 'tavo.theme.update' : 'tavo.theme.create', target: portableReadback.name, id: portableId, assets: item.themeAssets.length, verified: true });
      return;
    }
    var tempName = fileName(item.targetName, item.id);
    var tempPath = await tavo.file.save(tempName, bytesToBase64(item.bytes), { scope: 'chat', encoding: 'base64' });
    cleanup.push(async function () { await tavo.file.delete(tempPath); });
    var backupPath = null;
    if (item.existing) {
      var exported = await tavo.theme.export(item.existing.id);
      backupPath = exported && exported.path;
      if (backupPath) cleanup.push(async function () { await tavo.file.delete(backupPath); });
    }
    var importResult = await tavo.theme.import(tempPath);
    if (importResult === null) fail('E_WRITE_CANCELLED', item.id + ': theme import was cancelled');
    var entityId = idOf(importResult);
    if (entityId == null) {
      var importedTheme = await findExact(tavo.theme, item.name);
      entityId = importedTheme && importedTheme.id;
    }
    if (entityId == null) fail('E_READBACK_THEME', item.id + ': theme import returned no ID and could not be found by name');
    journal.push(async function () {
      if (!item.existing || entityId !== item.existing.id) await tavo.theme.delete(entityId);
      else if (backupPath) await tavo.theme.import(backupPath);
    });
    var readback = await tavo.theme.get(entityId);
    if (!readback) fail('E_READBACK_THEME', item.id + ': imported theme could not be read back');
    results.set(item.id, { id: entityId, name: readback.name || item.name });
    operations.push({ itemId: item.id, type: item.type, action: item.action, format: 'native', transport: 'tavo.theme.import', target: readback.name || item.name, id: entityId, verified: true });
  }

  async function commitVariables(item, results, journal, operations) {
    var values = replaceResourceRefs(clone(item.data.values), results);
    var previous = [];
    Object.keys(values).forEach(function (key) {
      var oldValue = tavo.get(key, item.scope);
      previous.push({ key: key, present: oldValue !== null && oldValue !== undefined, value: clone(oldValue) });
      tavo.set(key, values[key], item.scope);
    });
    journal.push(async function () {
      previous.forEach(function (row) {
        if (row.present) tavo.set(row.key, row.value, item.scope);
        else tavo.unset(row.key, item.scope);
      });
    });
    Object.keys(values).forEach(function (key) {
      if (!equalJson(tavo.get(key, item.scope), values[key])) fail('E_READBACK_VARIABLE', item.id + ': variable readback failed for ' + key);
    });
    results.set(item.id, { keys: Object.keys(values), scope: item.scope });
    operations.push({ itemId: item.id, type: item.type, action: 'set', target: item.scope, keys: Object.keys(values).length, verified: true });
  }

  function resourcesFromPlan(plan, results) {
    var rows = [];
    plan.items.forEach(function (item) {
      var result = results.get(item.id) || {};
      if (result.resource) rows.push(result.resource);
      if (Array.isArray(result.resources)) rows = rows.concat(result.resources);
    });
    plan.items.forEach(function (consumer) {
      (consumer.resourceRefs || []).forEach(function (resourceItemId) {
        var target = results.get(resourceItemId);
        if (!target || !target.resource) return;
        target.resource.references = uniqueIds((target.resource.references || []).concat(consumer.id));
      });
    });
    return mergeResourceRows([], rows);
  }

  async function commitResourceCatalog(plan, results, journal, operations) {
    var imported = resourcesFromPlan(plan, results);
    if (!imported.length) return;
    var rowsByScope = { chat: [], global: [] };
    imported.forEach(function (row) { rowsByScope[row.scope].push(row); });
    var allRows = [];
    ['chat', 'global'].forEach(function (scope) {
      var before = tavo.get(RESOURCE_INDEX_KEY, scope);
      var present = before !== null && before !== undefined;
      var existing = Array.isArray(before) ? before : [];
      var merged = mergeResourceRows(existing, rowsByScope[scope]);
      tavo.set(RESOURCE_INDEX_KEY, merged, scope);
      if (!equalJson(tavo.get(RESOURCE_INDEX_KEY, scope), merged)) fail('E_READBACK_RESOURCE_INDEX', 'Resource index readback failed for ' + scope);
      journal.push(async function () {
        if (present) tavo.set(RESOURCE_INDEX_KEY, before, scope);
        else tavo.unset(RESOURCE_INDEX_KEY, scope);
      });
      allRows = allRows.concat(merged);
    });
    allRows = mergeResourceRows([], allRows);

    var current = null;
    try { current = await tavo.chat.current(); } catch (ignored) {}
    var exactBooks = await findExactMatches(tavo.lorebook, RESOURCE_BOOK_NAME);
    var existingBook = chooseExactMatch('lorebook', exactBooks, current);
    var beforeBook = clone(existingBook);
    var orderedBooks = exactBooks.filter(function (book) {
      return !existingBook || String(idOf(book)) !== String(idOf(existingBook));
    });
    if (existingBook) orderedBooks.push(existingBook);
    var existingEntries = [];
    orderedBooks.forEach(function (book) {
      existingEntries = mergeLorebookEntries(existingEntries, book && book.entries);
    });
    var ledgerRows = existingEntries.map(parseResourceEntry).filter(Boolean);
    var consolidated = mergeResourceRows(ledgerRows, allRows);
    var retained = existingEntries.filter(function (entry) {
      return String(entry && entry.identifier || '').indexOf(RESOURCE_ENTRY_PREFIX) !== 0 && entry.identifier !== 'aster-resource-book-meta';
    });
    var nextEntries = retained.concat([resourceMetaEntry(consolidated)]).concat(consolidated.map(resourceEntry));
    var bookId;
    if (existingBook) {
      var nextBook = Object.assign({}, existingBook, { id: existingBook.id, name: RESOURCE_BOOK_NAME, entries: nextEntries });
      var updateResult = await tavo.lorebook.update(nextBook);
      if (updateResult === null) fail('E_WRITE_CANCELLED', 'Resource book update was cancelled');
      bookId = existingBook.id;
      journal.push(async function () { await tavo.lorebook.update(beforeBook); });
    } else {
      bookId = idOf(await tavo.lorebook.create({ name: RESOURCE_BOOK_NAME, entries: nextEntries }));
      if (bookId == null) fail('E_WRITE_CANCELLED', 'Resource book creation was cancelled');
      journal.push(async function () { await tavo.lorebook.delete(bookId); });
    }
    var readback = await tavo.lorebook.get(bookId);
    var readbackEntries = entryArray(readback && readback.entries);
    var readbackRows = readbackEntries.map(parseResourceEntry).filter(Boolean);
    if (!readback || readback.name !== RESOURCE_BOOK_NAME || readbackRows.length !== consolidated.length) {
      fail('E_READBACK_RESOURCE_BOOK', 'Resource book readback failed');
    }
    results.set('$resource-book', { id: bookId, name: RESOURCE_BOOK_NAME });
    operations.push({
      itemId: '$resource-book', type: 'resourceBook', action: existingBook ? 'merge' : 'create',
      target: RESOURCE_BOOK_NAME, id: bookId, resources: consolidated.length,
      addedOrUpdated: imported.length, repairedEntries: Math.max(0, ledgerRows.length - consolidated.length),
      sameNameVersions: exactBooks.length, verified: true
    });
  }

  function resolveResultIds(ids, results, label) {
    return (ids || []).map(function (itemId) {
      var result = results.get(itemId);
      if (!result || result.id == null) fail('E_ACTIVATE_RESULT', label + ': no imported ID for ' + itemId);
      return result.id;
    });
  }

  async function commitActivation(manifest, results, journal, operations) {
    if (!manifest.activate || !manifest.activate.chat) return;
    if (!configBoolean('activateCurrentChat', true)) {
      operations.push({ itemId: '$activate', type: 'activation', action: 'skip', target: 'current chat', verified: true });
      return;
    }
    var activation = manifest.activate.chat;
    var before = await tavo.chat.current();
    if (!before) fail('E_CHAT_MISSING', 'No current chat is available for activation');
    var patch = {};
    var mode = activation.mode || 'merge';
    if (activation.lorebooks) {
      var lorebookIds = resolveResultIds(activation.lorebooks, results, 'lorebooks');
      patch.lorebooks = mode === 'replace' ? lorebookIds : uniqueIds(idsFrom(before.lorebooks).concat(lorebookIds));
    }
    if (activation.regexes) {
      var regexIds = resolveResultIds(activation.regexes, results, 'regexes');
      patch.regexes = mode === 'replace' ? regexIds : uniqueIds(idsFrom(before.regexes).concat(regexIds));
    }
    if (activation.preset) patch.preset = results.get(activation.preset).id;
    if (activation.theme) patch.theme = results.get(activation.theme).id;
    await tavo.chat.update(patch);
    journal.push(async function () {
      await tavo.chat.update({
        lorebooks: idsFrom(before.lorebooks),
        regexes: idsFrom(before.regexes),
        preset: idOf(before.preset),
        theme: idOf(before.theme)
      });
    });
    var after = await tavo.chat.current();
    if (patch.lorebooks && !equalJson(idsFrom(after.lorebooks), patch.lorebooks)) fail('E_READBACK_ACTIVATION', 'Lorebook activation readback failed');
    if (patch.regexes && !equalJson(idsFrom(after.regexes), patch.regexes)) fail('E_READBACK_ACTIVATION', 'Regex activation readback failed');
    if (own(patch, 'preset') && idOf(after.preset) !== patch.preset) fail('E_READBACK_ACTIVATION', 'Preset activation readback failed');
    if (own(patch, 'theme') && idOf(after.theme) !== patch.theme) fail('E_READBACK_ACTIVATION', 'Theme activation readback failed');
    operations.push({ itemId: '$activate', type: 'activation', action: mode, target: 'current chat', verified: true });
  }

  function cleanupEntityType(type) {
    if (type === 'themePackage') return 'theme';
    if (type === 'resourceBook') return 'lorebook';
    return type;
  }

  function cleanupRecordKey(type, id) {
    return cleanupEntityType(type) + ':' + String(id);
  }

  async function collectExactNameCleanupRecords(plan, results) {
    var records = [], seen = Object.create(null);
    async function append(itemId, type, name, canonicalId) {
      type = cleanupEntityType(type);
      var api = apiFor(type);
      if (!api || canonicalId == null) return;
      var canonical = await api.get(canonicalId);
      if (!canonical) throw new Error(itemId + ': canonical exact-name entity disappeared before cleanup');
      var exactName = canonical.name || name;
      var matches = await findExactMatches(api, exactName);
      matches.forEach(function (match) {
        var staleId = idOf(match);
        if (staleId == null || String(staleId) === String(canonicalId)) return;
        var key = cleanupRecordKey(type, staleId);
        if (seen[key]) return;
        seen[key] = true;
        records.push({
          itemId: itemId, type: type, name: exactName, api: api,
          canonicalId: canonicalId, canonical: clone(canonical), staleId: staleId
        });
      });
    }

    for (var index = 0; index < plan.items.length; index += 1) {
      var item = plan.items[index];
      if (item.action !== 'replace') continue;
      var result = results.get(item.id);
      if (result && result.id != null) await append(item.id, item.type, result.name || item.name, result.id);
    }
    var resourceBook = results.get('$resource-book');
    if (resourceBook && resourceBook.id != null) {
      await append('$resource-book', 'resourceBook', RESOURCE_BOOK_NAME, resourceBook.id);
    }
    return records;
  }

  function rewrittenIds(value, replacements) {
    return uniqueIds(idsFrom(value).map(function (id) {
      return replacements.has(String(id)) ? replacements.get(String(id)) : id;
    }));
  }

  function bindingContains(record, current) {
    var stale = String(record.staleId);
    if (record.type === 'lorebook') return idsFrom(current.lorebooks).map(String).indexOf(stale) >= 0;
    if (record.type === 'regex') return idsFrom(current.regexes).map(String).indexOf(stale) >= 0;
    if (record.type === 'preset') return idOf(current.preset) != null && String(idOf(current.preset)) === stale;
    if (record.type === 'theme') return idOf(current.theme) != null && String(idOf(current.theme)) === stale;
    if (record.type === 'character') return boundEntityIds('character', current).map(String).indexOf(stale) >= 0;
    return false;
  }

  async function repairExactNameBindings(records) {
    var protectedKeys = new Set(), boundRecords = [];
    var report = { needed: false, updated: false, verified: true, fields: [] };
    var current;
    try { current = await tavo.chat.current(); }
    catch (error) {
      records.forEach(function (record) { protectedKeys.add(cleanupRecordKey(record.type, record.staleId)); });
      report.verified = false; report.error = 'Current chat could not be read: ' + messageOf(error);
      return { protectedKeys: protectedKeys, report: report };
    }
    if (!current) {
      records.forEach(function (record) { protectedKeys.add(cleanupRecordKey(record.type, record.staleId)); });
      report.verified = false; report.error = 'Current chat is unavailable';
      return { protectedKeys: protectedKeys, report: report };
    }

    records.forEach(function (record) {
      if (bindingContains(record, current)) boundRecords.push(record);
    });
    if (!boundRecords.length) return { protectedKeys: protectedKeys, report: report };
    report.needed = true;

    var byType = { lorebook: new Map(), regex: new Map(), preset: new Map(), theme: new Map() };
    boundRecords.forEach(function (record) {
      if (byType[record.type]) byType[record.type].set(String(record.staleId), record.canonicalId);
      else protectedKeys.add(cleanupRecordKey(record.type, record.staleId));
    });
    var patch = {};
    var nextLorebooks = rewrittenIds(current.lorebooks, byType.lorebook);
    var nextRegexes = rewrittenIds(current.regexes, byType.regex);
    if (!equalJson(idsFrom(current.lorebooks), nextLorebooks)) { patch.lorebooks = nextLorebooks; report.fields.push('lorebooks'); }
    if (!equalJson(idsFrom(current.regexes), nextRegexes)) { patch.regexes = nextRegexes; report.fields.push('regexes'); }
    var currentPreset = idOf(current.preset);
    var currentTheme = idOf(current.theme);
    if (currentPreset != null && byType.preset.has(String(currentPreset))) { patch.preset = byType.preset.get(String(currentPreset)); report.fields.push('preset'); }
    if (currentTheme != null && byType.theme.has(String(currentTheme))) { patch.theme = byType.theme.get(String(currentTheme)); report.fields.push('theme'); }

    if (!Object.keys(patch).length) {
      if (protectedKeys.size) {
        report.verified = false;
        report.error = 'An active entity binding cannot be rewritten through tavo.chat.update';
      }
      return { protectedKeys: protectedKeys, report: report };
    }
    try {
      var updated = await tavo.chat.update(patch);
      if (updated === null) throw new Error('Tavo cancelled current-chat binding repair');
      var after = await tavo.chat.current();
      if (patch.lorebooks && !equalJson(idsFrom(after.lorebooks), patch.lorebooks)) throw new Error('lorebook binding readback mismatch');
      if (patch.regexes && !equalJson(idsFrom(after.regexes), patch.regexes)) throw new Error('regex binding readback mismatch');
      if (own(patch, 'preset') && String(idOf(after.preset)) !== String(patch.preset)) throw new Error('preset binding readback mismatch');
      if (own(patch, 'theme') && String(idOf(after.theme)) !== String(patch.theme)) throw new Error('theme binding readback mismatch');
      report.updated = true;
    } catch (error) {
      boundRecords.forEach(function (record) { protectedKeys.add(cleanupRecordKey(record.type, record.staleId)); });
      report.verified = false; report.error = messageOf(error);
    }
    return { protectedKeys: protectedKeys, report: report };
  }

  function entityMatchesCanonical(type, canonical, readback) {
    if (!readback || readback.name !== canonical.name) return false;
    if (type === 'lorebook' || type === 'regex') return equalJson(entryArray(readback.entries), entryArray(canonical.entries));
    if (type === 'preset') {
      try { verifyPresetReadback(canonical, readback, '$same-name-cleanup'); return true; }
      catch (ignored) { return false; }
    }
    if (type === 'character') {
      try { verifyCharacterReadback(canonical, readback, '$same-name-cleanup'); return true; }
      catch (ignored) { return false; }
    }
    function contains(expected, actual) {
      if (Array.isArray(expected)) return Array.isArray(actual) && equalJson(expected, actual);
      if (!isObject(expected)) return equalJson(expected, actual);
      if (!isObject(actual)) return false;
      return Object.keys(expected).every(function (key) { return contains(expected[key], actual[key]); });
    }
    var expected = clone(canonical), actual = clone(readback);
    delete expected.id; delete actual.id;
    return contains(expected, actual);
  }

  async function overwriteStaleWithCanonical(record) {
    var payload = clone(record.canonical), updated;
    if (record.type === 'theme') {
      delete payload.id;
      updated = await record.api.update(record.staleId, payload);
    } else {
      payload.id = record.staleId;
      updated = await record.api.update(payload);
    }
    if (updated === null) throw new Error('Tavo cancelled fallback overwrite');
    var readback = await record.api.get(record.staleId);
    if (!entityMatchesCanonical(record.type, record.canonical, readback)) throw new Error('fallback overwrite readback mismatch');
  }

  async function cleanupExactNameEntities(plan, results, operations) {
    var records;
    try { records = await collectExactNameCleanupRecords(plan, results); }
    catch (error) {
      var failedScan = {
        itemId: '$same-name-cleanup', type: 'cleanup', action: 'scan-failed', target: 'exact-name entities',
        candidates: 0, deleted: 0, retainedCurrent: 0, failures: [{ stage: 'scan', error: messageOf(error) }], verified: false
      };
      operations.push(failedScan);
      return failedScan;
    }
    if (!records.length) return null;

    var binding = await repairExactNameBindings(records);
    var failures = [], deleted = 0, retainedCurrent = 0;
    if (!binding.report.verified) failures.push({ stage: 'bindings', error: binding.report.error || 'binding repair failed' });
    for (var index = 0; index < records.length; index += 1) {
      var record = records[index];
      var key = cleanupRecordKey(record.type, record.staleId);
      if (binding.protectedKeys.has(key)) {
        try { await overwriteStaleWithCanonical(record); retainedCurrent += 1; }
        catch (protectedError) {
          failures.push({ stage: 'protected-overwrite', itemId: record.itemId, type: record.type, id: record.staleId, error: messageOf(protectedError) });
        }
        continue;
      }
      try {
        await record.api.delete(record.staleId);
        if (await record.api.get(record.staleId)) throw new Error('old exact-name version still exists after delete');
        deleted += 1;
      } catch (deleteError) {
        try {
          await overwriteStaleWithCanonical(record);
          retainedCurrent += 1;
          failures.push({ stage: 'delete', itemId: record.itemId, type: record.type, id: record.staleId, error: messageOf(deleteError), fallback: 'overwritten-with-current-version' });
        } catch (fallbackError) {
          failures.push({ stage: 'delete-and-overwrite', itemId: record.itemId, type: record.type, id: record.staleId, error: messageOf(deleteError), fallbackError: messageOf(fallbackError) });
        }
      }
    }

    var operation = {
      itemId: '$same-name-cleanup', type: 'cleanup',
      action: failures.length ? 'replace-old-versions-with-warnings' : 'delete-old-versions',
      target: 'exact-name entities', candidates: records.length, deleted: deleted,
      retainedCurrent: retainedCurrent, bindings: binding.report, failures: failures,
      verified: failures.length === 0 && retainedCurrent === 0 && deleted === records.length
    };
    operations.push(operation);
    return operation;
  }

  async function commitAsterModuleRepair(plan, results, journal, operations) {
    if (!plan.prepared.manifest.repair || plan.prepared.manifest.repair.asterModules !== 'deduplicate') return;
    var preferredBooks = Object.create(null);
    plan.items.forEach(function (item) {
      if (item.type !== 'lorebook') return;
      var result = results.get(item.id);
      if (result && result.id != null) preferredBooks[item.name] = result.id;
    });
    var scan = await scanAsterModules(), removals = Object.create(null), removed = 0;
    scan.duplicateIds.forEach(function (moduleId) {
      var group = scan.groups[moduleId], keep = chooseAsterModule(group, preferredBooks);
      group.forEach(function (occurrence) {
        if (occurrence.bookId === keep.bookId && occurrence.entryIndex === keep.entryIndex) return;
        var key = String(occurrence.bookId);
        if (!removals[key]) removals[key] = Object.create(null);
        removals[key][occurrence.entryIndex] = moduleId; removed += 1;
      });
    });
    var touched = [];
    for (var index = 0; index < scan.books.length; index += 1) {
      var record = scan.books[index], drop = removals[String(record.id)];
      if (!drop) continue;
      var backup = clone(record.book);
      var nextEntries = record.entries.filter(function (entry, entryIndex) { return !own(drop, entryIndex); });
      var payload = Object.assign({}, record.book, { id: record.id, name: record.name, entries: nextEntries });
      var updated = await tavo.lorebook.update(payload);
      if (updated === null) fail('E_WRITE_CANCELLED', 'Aster module repair was cancelled for ' + record.name);
      (function (saved) { journal.push(async function () { await tavo.lorebook.update(saved); }); }(backup));
      var readback = await tavo.lorebook.get(record.id), actualEntries = entryArray(readback && readback.entries);
      if (!readback || readback.name !== record.name || actualEntries.length !== nextEntries.length) {
        fail('E_READBACK_ASTER_REPAIR', 'Aster module repair readback failed for ' + record.name);
      }
      touched.push({ id: record.id, name: record.name, removed: Object.keys(drop).length });
    }
    var verified = await scanAsterModules();
    if (verified.duplicateIds.length) fail('E_READBACK_ASTER_DUPLICATE', 'Duplicate Aster modules remain after repair', { moduleIds: verified.duplicateIds });
    operations.push({
      itemId: '$aster-module-repair', type: 'repair', action: removed ? 'deduplicate' : 'verify-unique',
      target: 'Aster module registry', duplicateIds: scan.duplicateIds, removed: removed, books: touched,
      preflightDuplicates: plan.summary.repairs || 0, verified: true
    });
  }

  async function rollback(journal) {
    var results = [];
    for (var index = journal.length - 1; index >= 0; index -= 1) {
      try { await journal[index](); results.push({ index: index, ok: true }); }
      catch (error) { results.push({ index: index, ok: false, error: messageOf(error) }); }
    }
    return results;
  }

  async function cleanupAll(cleanup) {
    var errors = [];
    for (var index = cleanup.length - 1; index >= 0; index -= 1) {
      try { await cleanup[index](); }
      catch (error) { errors.push(messageOf(error)); }
    }
    return errors;
  }

  async function executePlan(plan, receipt) {
    var results = new Map();
    var journal = [];
    var cleanup = [];
    receipt.operations = [];
    try {
      for (var index = 0; index < plan.items.length; index += 1) {
        var item = plan.items[index];
        if (item.type === 'resource') await commitResource(item, results, journal, receipt.operations);
        else if (item.type === 'themePackage') await commitThemePackage(item, results, journal, cleanup, receipt.operations);
        else if (item.type === 'variables') await commitVariables(item, results, journal, receipt.operations);
        else await commitEntity(item, results, journal, receipt.operations);
      }
      await commitAsterModuleRepair(plan, results, journal, receipt.operations);
      await commitResourceCatalog(plan, results, journal, receipt.operations);
      await commitActivation(plan.prepared.manifest, results, journal, receipt.operations);
      var exactNameCleanup = await cleanupExactNameEntities(plan, results, receipt.operations);
      if (exactNameCleanup && !exactNameCleanup.verified) {
        receipt.warnings = (receipt.warnings || []).concat([{
          code: 'W_EXACT_NAME_CLEANUP',
          message: 'One or more old exact-name versions could not be deleted; current content was retained where possible.',
          detail: clone(exactNameCleanup)
        }]);
      }
      receipt.status = 'success';
      receipt.rollback = [];
    } catch (error) {
      receipt.status = 'failed';
      receipt.error = { code: error && error.code || 'E_IMPORT', message: messageOf(error), detail: error && error.detail || null };
      receipt.rollback = await rollback(journal);
    } finally {
      receipt.cleanupErrors = await cleanupAll(cleanup);
    }
    return receipt;
  }

  async function persistReceipt(receipt) {
    receipt.finishedAt = new Date().toISOString();
    try {
      var path = await tavo.file.save(RECEIPT_NAME, JSON.stringify(receipt, null, 2), { scope: 'global', encoding: 'utf8' });
      tavo.set(RECEIPT_KEY, path, 'global');
      return path;
    } catch (error) {
      receipt.receiptPersistenceError = messageOf(error);
      return null;
    }
  }

  function baseReceipt(source) {
    return {
      spec: RECEIPT_SPEC,
      pluginVersion: PLUGIN_VERSION,
      startedAt: new Date().toISOString(),
      status: 'preflight',
      source: source ? {
        name: source.originalName || source.name,
        storedName: source.name,
        path: source.path,
        size: source.size,
        mimeType: source.mimeType
      } : null,
      operations: [],
      rollback: []
    };
  }

  async function deleteSelectedSource(selected) {
    var report = { requested: true, status: 'retained', path: selected && selected.path || '', name: selected && selected.name || '', attempts: [] };
    if (!selected) return report;
    async function exists() {
      if (selected.path && await tavo.file.exists(selected.path)) return true;
      if (selected.name && await tavo.file.exists(selected.name, { scope: 'chat' })) return true;
      return false;
    }
    try {
      if (selected.path) {
        await tavo.file.delete(selected.path);
        report.attempts.push('virtual-path');
      }
      if (await exists() && selected.name) {
        await tavo.file.delete(selected.name, { scope: 'chat' });
        report.attempts.push('name+chat-scope');
      }
      report.status = await exists() ? 'failed' : 'deleted';
      if (report.status === 'failed') report.error = 'Source ZIP still exists after delete and readback';
    } catch (error) {
      report.status = 'failed'; report.error = messageOf(error);
      try {
        if (selected.name) {
          await tavo.file.delete(selected.name, { scope: 'chat' });
          report.attempts.push('name+chat-scope-after-error');
          if (!await exists()) { report.status = 'deleted'; delete report.error; }
        }
      } catch (fallbackError) { report.fallbackError = messageOf(fallbackError); }
    }
    return report;
  }

  async function runImport() {
    if (busy) { toast('runtime.busy'); return null; }
    busy = true;
    var selected = null;
    var receipt = null;
    try {
      toast('runtime.selecting');
      var chosen = await tavo.file.import({ multiple: false, scope: 'chat', extensions: ['zip'], conflict: 'rename' });
      if (!chosen || !chosen.length) { toast('runtime.cancelled'); return null; }
      selected = chosen[0];
      receipt = baseReceipt(selected);
      if (!finiteInteger(selected.size) || selected.size < 1 || selected.size > DEFAULT_LIMITS.maxArchive) fail('E_SOURCE_SIZE', 'Selected ZIP size is invalid or exceeds 64 MiB');
      toast('runtime.preflighting');
      var base64 = await tavo.file.load(selected.path, { encoding: 'base64' });
      if (typeof base64 !== 'string') fail('E_SOURCE_READ', 'Tavo could not read the selected ZIP as base64');
      var bytes = base64ToBytes(base64);
      if (bytes.length !== selected.size) fail('E_SOURCE_SIZE_MISMATCH', 'Selected ZIP byte count changed after import');
      var prepared = await preparePackage(bytes, selected);
      var plan = await buildPlan(prepared);
      receipt.source.sha256 = prepared.sourceSha256;
      receipt.package = {
        id: prepared.manifest.id,
        name: prepared.manifest.name,
        version: prepared.manifest.version,
        archiveEntries: prepared.archiveEntries,
        items: prepared.items.length
      };
      receipt.preflight = clone(plan.summary);
      if (!await confirmPlan(plan)) {
        receipt.status = 'cancelled';
        await persistReceipt(receipt);
        toast('runtime.cancelled');
        return receipt;
      }
      toast('runtime.committing', { count: plan.items.length });
      await executePlan(plan, receipt);
      if (receipt.status === 'success') {
        if (configBoolean('deleteSourceAfterSuccess', true)) {
          receipt.sourceCleanup = await deleteSelectedSource(selected);
          if (receipt.sourceCleanup.status !== 'deleted') receipt.sourceCleanupError = receipt.sourceCleanup.error || 'Source ZIP cleanup failed';
        } else receipt.sourceCleanup = { requested: false, status: 'retained', path: selected.path, name: selected.name };
        await persistReceipt(receipt);
        toast('runtime.success', { name: prepared.manifest.name, count: receipt.operations.length });
      } else {
        await persistReceipt(receipt);
        toast('runtime.failed', { message: receipt.error.message });
      }
      return receipt;
    } catch (error) {
      receipt = receipt || baseReceipt(selected);
      receipt.status = 'failed';
      receipt.error = { code: error && error.code || 'E_IMPORT', message: messageOf(error), detail: error && error.detail || null };
      await persistReceipt(receipt);
      toast('runtime.failed', { message: receipt.error.message });
      return receipt;
    } finally { busy = false; }
  }

  async function exportLastReceipt() {
    try {
      var path = tavo.get(RECEIPT_KEY, 'global') || ('files/global/' + RECEIPT_NAME);
      if (!await tavo.file.exists(path)) { toast('runtime.noReceipt'); return false; }
      await tavo.file.export(path);
      toast('runtime.receiptExported');
      return true;
    } catch (error) {
      toast('runtime.failed', { message: messageOf(error) });
      return false;
    }
  }

  tavo.plugin.onSidebarAction('import-mod-package', runImport);
  tavo.plugin.onSidebarAction('export-last-receipt', exportLastReceipt);
})();
