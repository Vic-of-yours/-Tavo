#!/usr/bin/env python3
"""Build Aster's five Tavo lorebooks from module source files."""

from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src-modules"
OUT = ROOT / "out"

BOOKS = {
    "core": "Aster·核心",
    "func": "Aster·功能",
    "codex": "Aster·图鉴",
    "system": "Aster·系统",
    "skin": "Aster·皮肤",
}

START = "⟦aster·module⟧"
END = "⟦/aster·module⟧"
HEADER_RE = re.compile(r"^@(\w+)\s+(.+)$", re.MULTILINE)


def module_meta(text: str, source: Path) -> dict[str, str]:
    if text.count(START) != 1 or text.count(END) != 1:
        raise ValueError(f"{source}: module fence must appear exactly once")
    if text.index(START) > text.index(END):
        raise ValueError(f"{source}: closing fence precedes opening fence")
    body = text.split(START, 1)[1].split(END, 1)[0]
    head = body.split("\n--- ", 1)[0]
    meta = {k: v.strip() for k, v in HEADER_RE.findall(head)}
    for key in ("id", "name", "type", "version", "order"):
        if not meta.get(key):
            raise ValueError(f"{source}: missing @{key}")
    if not meta["id"].startswith("aster."):
        raise ValueError(f"{source}: module id must start with aster.")
    return meta


def entry(uid: int, source: Path, text: str, meta: dict[str, str]) -> dict:
    name = f"[模块]{meta['name']}"
    return {
        "disable": False,
        "use_regex": False,
        "constant": False,
        "vectorized": False,
        "position": 1,
        "depth": 4,
        "role": 0,
        "key": ["⬡aster·module⬡"],
        "keysecondary": [],
        "selective": False,
        "selectiveLogic": 0,
        "caseSensitive": False,
        "matchWholeWords": True,
        "scanDepth": 2,
        "useGroupScoring": False,
        "excludeRecursion": False,
        "preventRecursion": False,
        "delayUntilRecursion": False,
        "useProbability": True,
        "probability": 100,
        "sticky": 0,
        "cooldown": 0,
        "delay": 0,
        "group": "",
        "groupOverride": False,
        "groupWeight": 100,
        "uid": uid,
        "identifier": meta["id"],
        "name": name,
        "comment": name,
        "display_index": uid,
        "order": int(float(meta["order"])),
        "content": text,
        "extensions": {"asterSource": str(source.relative_to(ROOT))},
    }


def build() -> list[dict]:
    OUT.mkdir(parents=True, exist_ok=True)
    seen: dict[str, Path] = {}
    inventory: list[dict] = []

    for domain, book_name in BOOKS.items():
        rows = []
        for source in sorted((SRC / domain).glob("*.txt")):
            text = source.read_text(encoding="utf-8").strip() + "\n"
            if any(token in text for token in ("⟦vic·module⟧", "window.Vic", "W.Vic", "vic.enabled.modules")):
                raise ValueError(f"{source}: legacy runtime token leaked into Aster source")
            meta = module_meta(text, source)
            if meta["id"] in seen:
                raise ValueError(f"duplicate id {meta['id']}: {seen[meta['id']]} and {source}")
            seen[meta["id"]] = source
            rows.append((int(float(meta["order"])), source, text, meta))

        rows.sort(key=lambda row: (row[0], row[3]["id"]))
        entries = {}
        for uid, (_, source, text, meta) in enumerate(rows):
            entries[str(uid)] = entry(uid, source, text, meta)
            inventory.append({
                "book": book_name,
                "domain": domain,
                "source": str(source.relative_to(ROOT)),
                "id": meta["id"],
                "name": meta["name"],
                "type": meta["type"],
                "version": meta["version"],
                "order": int(float(meta["order"])),
                "bytes": len(text.encode("utf-8")),
            })

        book = {
            "tavo_spec": "lorebook_v3",
            "tavo_spec_version": "3.0",
            "name": book_name,
            "entries": entries,
        }
        target = OUT / f"{book_name}.json"
        target.write_text(json.dumps(book, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"{target.name}: {len(entries)} entries")

    (OUT / "aster-module-inventory.json").write_text(
        json.dumps(inventory, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return inventory


if __name__ == "__main__":
    build()
