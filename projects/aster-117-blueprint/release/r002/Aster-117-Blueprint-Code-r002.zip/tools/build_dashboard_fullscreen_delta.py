#!/usr/bin/env python3
"""Build the importable Aster fullscreen world-dashboard delta."""

from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BOOK_OUT = ROOT / "out"
OUT = Path(os.environ.get("ASTER_DELTA_OUTPUT_DIR", BOOK_OUT)).resolve()
VERSION = "1.1.0"
PACKAGE_ID = "io.aster.ui.world-dashboard-fullscreen"
NAME = f"Aster-world-dashboard-fullscreen-delta-{VERSION}.zip"
STAMP = (2026, 1, 1, 0, 0, 0)
BOOK_CHANGES = (
    ("core-dashboard-contracts", "核心", ("aster.ui.contracts",), "content/lorebooks/core-dashboard-contracts.json"),
    ("function-resource-ledger", "功能", ("aster.asset.ledger",), "content/lorebooks/function-resource-ledger.json"),
    ("system-world-dashboard", "系统", ("aster.dashboard.world",), "content/lorebooks/system-world-dashboard.json"),
    ("skin-world-dashboard", "皮肤", ("aster.skin.shell",), "content/lorebooks/skin-world-dashboard.json"),
)


def encoded(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def changed_entries(suffix: str, identifiers: tuple[str, ...]) -> dict[str, object]:
    book = json.loads((BOOK_OUT / f"Aster·{suffix}.json").read_text(encoding="utf-8"))
    rows = book.get("entries", {})
    values = list(rows.values()) if isinstance(rows, dict) else list(rows)
    matches = [row for row in values if isinstance(row, dict) and row.get("identifier") in identifiers]
    found = {str(row.get("identifier")) for row in matches}
    missing = sorted(set(identifiers) - found)
    if missing or len(matches) != len(identifiers):
        raise RuntimeError(f"{suffix}: missing or duplicate changed modules: {missing or identifiers}")
    matches.sort(key=lambda row: identifiers.index(str(row.get("identifier"))))
    return {
        "tavo_spec": book.get("tavo_spec", "lorebook_v3"),
        "tavo_spec_version": book.get("tavo_spec_version", "3.0"),
        "name": book["name"],
        "entries": {str(index): row for index, row in enumerate(matches)},
    }


def write_zip(target: Path, files: dict[str, bytes]) -> None:
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(files):
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, files[name])


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    files: dict[str, bytes] = {}
    items: list[dict[str, object]] = []
    for item_id, suffix, identifiers, payload_path in BOOK_CHANGES:
        payload = changed_entries(suffix, identifiers)
        content = encoded(payload)
        files[payload_path] = content
        items.append({
            "id": item_id,
            "type": "lorebook",
            "path": payload_path,
            "sha256": hashlib.sha256(content).hexdigest(),
            "name": payload["name"],
            "conflict": "replace",
        })
    manifest = {
        "spec": "aster.mod/v1",
        "id": PACKAGE_ID,
        "name": "Aster 全屏世界仪表盘 3.1 与资源只读探测修复",
        "version": VERSION,
        "defaultConflict": "replace",
        "repair": {"asterModules": "deduplicate"},
        "items": items,
    }
    files["aster-mod.json"] = encoded(manifest)
    target = OUT / NAME
    write_zip(target, files)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    (OUT / f"Aster-world-dashboard-fullscreen-delta-{VERSION}-SHA256.txt").write_text(
        f"{digest}  {target.name}\n", encoding="utf-8"
    )
    print(target)
    print(f"sha256={digest}")
    print(f"items={len(items)} modules={sum(len(row[2]) for row in BOOK_CHANGES)}")


if __name__ == "__main__":
    main()
