#!/usr/bin/env python3
"""Build the 172-row Aster blueprint ledger from the canonical v117 archive."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import zipfile
from collections import Counter
from pathlib import Path


EXPECTED_V117_SHA256 = "7cf04ac30f641a70656eff9ecd43e854e45b87ac35de742681e06f7f5064e631"
RETIRED = {"retired-inert", "retired-explicit"}


def sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def canonical_sha(value: object) -> str:
    return sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))


def read_source_rows(archive_path: Path) -> dict[str, list[dict]]:
    content = archive_path.read_bytes()
    if sha256(content) != EXPECTED_V117_SHA256:
        raise RuntimeError("canonical v117 archive hash mismatch")
    with zipfile.ZipFile(io.BytesIO(content)) as outer:
        with zipfile.ZipFile(io.BytesIO(outer.read("archives/deliverables.zip"))) as delivery:
            result: dict[str, list[dict]] = {}
            for name in delivery.namelist():
                if not name.startswith("books/") or name.endswith("/"):
                    continue
                try:
                    value = json.loads(delivery.read(name))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                book_name = value.get("name")
                if book_name in {"Vic·引擎", "Vic·引擎·功能", "Vic·引擎·图鉴", "Vic·引擎·系统", "Vic·引擎·皮肤"}:
                    entries = value.get("entries") or {}
                    result[book_name] = list(entries.values()) if isinstance(entries, dict) else list(entries)
                elif isinstance(book_name, str) and book_name.startswith("Vic·叙事书"):
                    entries = value.get("entries") or {}
                    result["Vic·叙事书"] = list(entries.values()) if isinstance(entries, dict) else list(entries)
                elif isinstance(value.get("prompts"), list) and len(value["prompts"]) == 22:
                    result["Tavo_Vi_预设·叙事协议"] = list(value["prompts"])
    expected = {
        "Vic·引擎": 21,
        "Vic·引擎·功能": 21,
        "Vic·引擎·图鉴": 34,
        "Vic·引擎·系统": 54,
        "Vic·引擎·皮肤": 17,
        "Vic·叙事书": 3,
        "Tavo_Vi_预设·叙事协议": 22,
    }
    if {key: len(value) for key, value in result.items()} != expected:
        raise RuntimeError(f"unexpected seven-book census: { {key: len(value) for key, value in result.items()} }")
    return result


def aster_targets(targets: list[str]) -> list[str]:
    output = []
    for target in targets:
        if target == "vic.system.repository-apps":
            replacements = ["aster.system.project-save-apps", "aster.system.data-manager"]
        else:
            replacements = ["aster." + target.removeprefix("vic.")]
        for replacement in replacements:
            if replacement not in output:
                output.append(replacement)
    return output


def build(v117: Path, continuity_ledger: Path) -> dict:
    source_rows = read_source_rows(v117)
    continuity = json.loads(continuity_ledger.read_text(encoding="utf-8"))
    if continuity.get("policy", {}).get("totalRows") != 172 or len(continuity.get("rows") or []) != 172:
        raise RuntimeError("continuity ledger is not the required 172-row source")
    rows = []
    for source in continuity["rows"]:
        entry = source_rows[source["sourceBook"]][int(source["sourceIndex"]) - 1]
        disposition = source["status"]
        targets = aster_targets(source.get("targets") or [])
        if disposition not in RETIRED and not targets:
            raise RuntimeError(f"unmapped source row: {source['sourceBook']}#{source['sourceIndex']}")
        content = str(entry.get("content") or "")
        row = {
            "sourceBook": source["sourceBook"],
            "sourceIndex": source["sourceIndex"],
            "sourceId": source["sourceId"],
            "sourceName": entry.get("name") or entry.get("comment") or source["sourceId"],
            "sourceEntrySha256": canonical_sha(entry),
            "sourceContentSha256": sha256(content.encode("utf-8")),
            "legacyDisposition": disposition,
            "asterStatus": "retired-verified" if disposition in RETIRED else "blueprint-mapped",
            "targets": targets,
            "reason": source["reason"],
            "continuityEvidence": source.get("evidence") or [],
            "requiredAsterEvidence": [
                "target-module-implementation",
                "dependency-contract",
                "behavior-probe",
                "migration-readback"
            ] if disposition not in RETIRED else ["retirement-policy-test"],
        }
        rows.append(row)

    keys = [(row["sourceBook"], row["sourceIndex"], row["sourceId"]) for row in rows]
    if len(keys) != len(set(keys)):
        raise RuntimeError("duplicate source key in Aster ledger")
    status_counts = Counter(row["asterStatus"] for row in rows)
    disposition_counts = Counter(row["legacyDisposition"] for row in rows)
    return {
        "schema": "aster.migration.r117-seven-book/v1",
        "generatedFrom": {"archive": v117.name, "sha256": EXPECTED_V117_SHA256},
        "policy": {
            "sourceBooks": 7,
            "engineEntries": 147,
            "narrativeEntries": 3,
            "presetPrompts": 22,
            "totalRows": 172,
            "pluginTracksSeparate": ["io.aster.narrative.runtime", "io.aster.mod-importer"],
            "forbiddenStatus": ["missing", "unmapped", "assumed", "partial-counted-as-complete"],
        },
        "counts": {
            "source": {key: len(value) for key, value in source_rows.items()},
            "legacyDisposition": dict(sorted(disposition_counts.items())),
            "asterStatus": dict(sorted(status_counts.items())),
            "implementedVerified": 0,
        },
        "rows": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v117", type=Path, required=True)
    parser.add_argument("--continuity-ledger", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    value = build(args.v117, args.continuity_ledger)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(value["rows"]), "counts": value["counts"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
