#!/usr/bin/env python3
"""Build the importable Aster 0.8.2 repair delta and an optional local source trace."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BOOK_OUT = ROOT / "out"
OUT = Path(os.environ.get("ASTER_DELTA_OUTPUT_DIR", BOOK_OUT)).resolve()
VERSION = "0.8.2"
STAMP = (2026, 1, 1, 0, 0, 0)
DELTA_NAME = f"Aster-data-workbench-trash-delta-{VERSION}.zip"
SOURCE_NAME = f"Aster-workspace-source-{VERSION}.zip"
CHANGES = (
    ("function-ledger", "功能", "aster.asset.ledger", "content/lorebooks/function-ledger.json"),
    ("system-data-manager", "系统", "aster.data.manager", "content/lorebooks/system-data-manager.json"),
    ("skin-data-workbench", "皮肤", "aster.skin.app-components", "content/lorebooks/skin-data-workbench.json"),
)


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def write_zip(target: Path, files: dict[str, bytes]) -> None:
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(files):
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, files[name])


def changed_entry(suffix: str, identifier: str) -> tuple[dict[str, object], dict[str, object]]:
    book = json.loads((BOOK_OUT / f"Aster·{suffix}.json").read_text(encoding="utf-8"))
    rows = book.get("entries", {})
    values = rows.values() if isinstance(rows, dict) else rows
    matches = [row for row in values if isinstance(row, dict) and row.get("identifier") == identifier]
    if len(matches) != 1:
        raise RuntimeError(f"expected one {identifier} entry in Aster·{suffix}, got {len(matches)}")
    payload = {
        "tavo_spec": book.get("tavo_spec", "lorebook_v3"),
        "tavo_spec_version": book.get("tavo_spec_version", "3.0"),
        "name": book["name"],
        "entries": {"0": matches[0]},
    }
    return book, payload


def build_delta() -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    files: dict[str, bytes] = {}
    items: list[dict[str, object]] = []
    for item_id, suffix, identifier, payload_path in CHANGES:
        _, payload = changed_entry(suffix, identifier)
        content = json_bytes(payload)
        files[payload_path] = content
        items.append({
            "id": item_id,
            "type": "lorebook",
            "path": payload_path,
            "sha256": hashlib.sha256(content).hexdigest(),
            "name": payload["name"],
            "conflict": "replace",
        })
    manifest = {
        "spec": "aster.mod/v1",
        "id": "io.aster.patch.data-workbench-trash",
        "name": "Aster 数据工作台与资源回收站增量更新",
        "version": VERSION,
        "defaultConflict": "replace",
        "repair": {"asterModules": "deduplicate"},
        "items": items,
    }
    files["aster-mod.json"] = json_bytes(manifest)
    target = OUT / DELTA_NAME
    write_zip(target, files)
    checksum = OUT / f"Aster-data-workbench-trash-delta-{VERSION}-SHA256.txt"
    checksum.write_text(f"{hashlib.sha256(target.read_bytes()).hexdigest()}  {target.name}\n", encoding="utf-8")
    return target


def build_source_trace(delta: Path) -> Path:
    roots = [
        ROOT / "src-modules", ROOT / "plugin-runtime", ROOT / "plugin-mod-importer",
        ROOT / "assets", ROOT / "design", ROOT / "docs",
        ROOT / "tests", ROOT / "tools", ROOT / "reports",
    ]
    files = [ROOT / "README.md", ROOT / "build_books.py", ROOT / "package_release.py"]
    for base in roots:
        files.extend(path for path in base.rglob("*") if path.is_file() and "__pycache__" not in path.parts)
    files.extend(path for path in BOOK_OUT.glob("*.json"))
    files.append(delta)
    target = OUT / SOURCE_NAME
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(set(path for path in files if path.exists())):
            if path == delta and path.parent != BOOK_OUT:
                # Preserve the canonical archive layout even if the sandbox's
                # temporary directory happens to live below ROOT.
                archive_name = f"out/{path.name}"
            else:
                try:
                    archive_name = path.relative_to(ROOT).as_posix()
                except ValueError:
                    # Test builds deliberately place the delta outside ROOT so
                    # historical artifacts under out/ remain byte-for-byte intact.
                    archive_name = f"out/{path.name}"
            info = zipfile.ZipInfo(archive_name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    return target


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", action="store_true", help="also build the local full source trace")
    args = parser.parse_args()
    delta = build_delta()
    print(delta)
    if args.snapshot:
        print(build_source_trace(delta))


if __name__ == "__main__":
    main()
