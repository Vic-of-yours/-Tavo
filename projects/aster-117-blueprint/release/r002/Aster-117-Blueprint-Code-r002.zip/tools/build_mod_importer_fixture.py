#!/usr/bin/env python3
"""Build the standalone Aster Mod importer and a deterministic all-format fixture."""

from __future__ import annotations

import hashlib
import io
import json
import math
import subprocess
import struct
import tempfile
import wave
import zipfile
import zlib
from pathlib import Path

from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "out"
PLUGIN = ROOT / "plugin-mod-importer"
PLUGIN_VERSION = "1.4.0"
FIXTURE_VERSION = "1.1.0"
STAMP = (2026, 1, 1, 0, 0, 0)


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def zip_bytes(files: dict[str, bytes], compression: int = zipfile.ZIP_DEFLATED) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=compression, compresslevel=9) as archive:
        for name in sorted(files):
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = compression
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, files[name])
    return output.getvalue()


def write_zip(path: Path, files: dict[str, bytes]) -> None:
    path.write_bytes(zip_bytes(files))


def make_png(width: int = 16, height: int = 16) -> bytes:
    def chunk(kind: bytes, payload: bytes) -> bytes:
        return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)

    rows = []
    for y in range(height):
        row = bytearray([0])
        for x in range(width):
            row.extend((22 + x * 5, 190 + y * 3, 235, 255))
        rows.append(bytes(row))
    signature = b"\x89PNG\r\n\x1a\n"
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return signature + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b"")


def make_wav() -> bytes:
    output = io.BytesIO()
    sample_rate = 8000
    frames = 800
    with wave.open(output, "wb") as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(sample_rate)
        samples = bytearray()
        for index in range(frames):
            envelope = 1.0 - index / frames
            sample = int(math.sin(2 * math.pi * 660 * index / sample_rate) * 9000 * envelope)
            samples.extend(struct.pack("<h", sample))
        audio.writeframes(bytes(samples))
    return output.getvalue()


def make_mp4() -> bytes:
    """Create a tiny real H.264 MP4 so video routing is tested with playable bytes."""
    with tempfile.TemporaryDirectory(prefix="aster-fixture-video-") as directory:
        target = Path(directory) / "fixture.mp4"
        subprocess.run(
            [
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                "-f", "lavfi", "-i", "color=c=0x07141d:s=32x32:r=4:d=0.5",
                "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "veryslow", "-crf", "28", "-movflags", "+faststart",
                "-map_metadata", "-1", "-fflags", "+bitexact", "-flags:v", "+bitexact",
                str(target),
            ],
            check=True,
        )
        return target.read_bytes()


def rectangle_glyph(width: int = 460, height: int = 620):
    pen = TTGlyphPen(None)
    pen.moveTo((70, 0))
    pen.lineTo((70, height))
    pen.lineTo((width, height))
    pen.lineTo((width, 0))
    pen.closePath()
    return pen.glyph()


def empty_glyph():
    return TTGlyphPen(None).glyph()


def make_ttf() -> bytes:
    glyph_order = [".notdef", "space", "A", "s", "t", "e", "r", "zero", "one"]
    cmap = {32: "space", 65: "A", 115: "s", 116: "t", 101: "e", 114: "r", 48: "zero", 49: "one"}
    glyphs = {name: (empty_glyph() if name == "space" else rectangle_glyph()) for name in glyph_order}
    metrics = {name: (600, 50) for name in glyph_order}
    builder = FontBuilder(1000, isTTF=True)
    builder.setupGlyphOrder(glyph_order)
    builder.setupCharacterMap(cmap)
    builder.setupGlyf(glyphs)
    builder.setupHorizontalMetrics(metrics)
    builder.setupHorizontalHeader(ascent=800, descent=-200)
    builder.setupNameTable({
        "familyName": "Aster Fixture",
        "styleName": "Regular",
        "uniqueFontIdentifier": "AsterFixture-Regular-1.0",
        "fullName": "Aster Fixture Regular",
        "psName": "AsterFixture-Regular",
        "version": "Version 1.0",
    })
    builder.setupOS2(sTypoAscender=800, sTypoDescender=-200, usWinAscent=800, usWinDescent=200)
    builder.setupPost()
    builder.setupMaxp()
    builder.font.recalcTimestamp = False
    builder.font["head"].created = 3849984000
    builder.font["head"].modified = 3849984000
    output = io.BytesIO()
    builder.font.save(output)
    return output.getvalue()


def fixture_book(source: Path, suffix: str) -> tuple[str, bytes]:
    value = json.loads(source.read_text(encoding="utf-8"))
    name = f"[Fixture] Aster·{suffix}"
    value["name"] = name
    entries = value.get("entries", {})
    rows = entries.values() if isinstance(entries, dict) else entries
    for row in rows:
        if isinstance(row, dict):
            row["disable"] = True
            row["enabled"] = False
    return name, json_bytes(value)


def build_fixture_payloads() -> tuple[dict[str, bytes], list[dict[str, object]]]:
    payloads: dict[str, bytes] = {}
    items: list[dict[str, object]] = []

    def add(item_id: str, item_type: str, path: str, content: bytes, **fields: object) -> None:
        payloads[path] = content
        item: dict[str, object] = {
            "id": item_id,
            "type": item_type,
            "path": path,
            "sha256": hashlib.sha256(content).hexdigest(),
        }
        item.update(fields)
        items.append(item)

    resources = {
        "resource-png": ("assets/fixture-wallpaper.png", "aster-fixture-wallpaper.png", make_png(), "global"),
        "resource-svg": (
            "assets/fixture-map.svg",
            "aster-fixture-map.svg",
            b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180"><rect width="320" height="180" fill="#020b12"/><path d="M20 150 C90 20 210 170 300 30" fill="none" stroke="#62e7ff" stroke-width="4"/><circle cx="160" cy="90" r="16" fill="#c98cff"/></svg>\n',
            "global",
        ),
        "resource-wav": ("assets/fixture-click.wav", "aster-fixture-click.wav", make_wav(), "global"),
        "resource-mp4": ("assets/fixture-loop.mp4", "aster-fixture-loop.mp4", make_mp4(), "global"),
        "resource-font": ("assets/fixture-ui.ttf", "aster-fixture-ui.ttf", make_ttf(), "global"),
        "resource-css": (
            "assets/fixture-skin.css",
            "aster-fixture-skin.css",
            b'@font-face{font-family:"Aster Fixture";src:url("files/global/aster-fixture-ui.ttf") format("truetype");font-display:swap}\n.aster-fixture{font-family:"Aster Fixture",sans-serif}\n',
            "global",
        ),
        "resource-json": (
            "assets/fixture-atlas.json",
            "aster-fixture-atlas.json",
            json_bytes({"spec": "aster.fixture.atlas/v1", "frames": {"star": [0, 0, 16, 16]}}),
            "global",
        ),
        "resource-text": (
            "assets/fixture-dialogue.txt",
            "aster-fixture-dialogue.txt",
            "Aster 完整格式验证文本：图片、音频、视频、字体与文本均已本地化。\n".encode("utf-8"),
            "chat",
        ),
        "resource-ejs": (
            "templates/fixture.ejs",
            "aster-fixture-template.ejs",
            b'<% if (typeof user !== "undefined") { %><%= user %><% } %>\n',
            "global",
        ),
    }
    for item_id, (path, target, content, scope) in resources.items():
        add(item_id, "resource", path, content, targetName=target, scope=scope, conflict="replace")

    book_ids: list[str] = []
    for slug, suffix in (("core", "核心"), ("function", "功能"), ("codex", "图鉴"), ("system", "系统"), ("skin", "皮肤")):
        name, content = fixture_book(OUT / f"Aster·{suffix}.json", suffix)
        item_id = f"book-{slug}"
        book_ids.append(item_id)
        add(item_id, "lorebook", f"content/lorebooks/{slug}.json", content, name=name, conflict="replace")

    narrative = {
        "name": "[Fixture] Aster·叙事书",
        "entries": [
            {
                "identifier": "fixture-local-resource",
                "name": "本地资源占位符回写验证",
                "content": "本条目保持禁用，仅验证本地路径替换：<img src=\"{{aster.resource:resource-png}}\">",
                "enabled": False,
                "strategy": "constant",
                "injectionPosition": "lorebookBefore",
                "injectionRole": "system",
                "probability": 100,
            }
        ],
    }
    book_ids.append("book-narrative")
    add("book-narrative", "lorebook", "content/lorebooks/narrative.json", json_bytes(narrative), name=narrative["name"], conflict="replace")

    preset = {
        "name": "[Fixture] Aster 完整预设",
        "basicPrompts": {
            "chatStart": "[Aster Fixture Chat]",
            "continueNudge": "[继续上一条消息，不重复原文。]",
            "lorebook": "{0}",
        },
        "entries": [
            {"identifier": "main", "name": "Main Prompt", "content": "Aster fixture preset.", "enabled": True, "active": True, "type": "builtin", "role": "system", "injectionPosition": "relative"},
            {"identifier": "worldInfoBefore", "name": "Lorebook Before", "enabled": True, "active": True, "type": "marker"},
            {"identifier": "chatHistory", "name": "Chat History", "enabled": True, "active": True, "type": "marker"},
        ],
    }
    add("preset-story", "preset", "content/presets/story.json", json_bytes(preset), name=preset["name"], conflict="replace")

    regex = {
        "name": "[Fixture] Aster UI 正则",
        "entries": [
            {
                "name": "Fixture status",
                "findRegex": "/<fixture-status>(.*?)<\\/fixture-status>/gis",
                "replaceString": "<aside class=\"aster-fixture\">$1</aside>",
                "trimStrings": [],
                "placements": ["char"],
                "timing": "display",
                "substitution": "none",
                "minDepth": None,
                "maxDepth": None,
                "enabled": True,
            }
        ],
    }
    add("regex-ui", "regex", "content/regex/ui.json", json_bytes(regex), name=regex["name"], conflict="replace")

    character = {
        "name": "[Fixture] 星轨旅人",
        "description": "Aster 完整包角色卡回读验证。",
        "personality": "冷静、敏锐",
        "scenario": "终端外圈·北区",
        "firstMes": "终端已连接。",
        "mesExample": "<START>\n{{char}}：欢迎回来。",
        "creatorNotes": "由完整 Mod fixture 创建。",
        "systemPrompt": "保持角色设定与世界状态一致。",
        "postHistoryInstructions": "优先延续当前场景。",
        "tags": ["aster", "fixture"],
    }
    add("character-player", "character", "content/characters/player.json", json_bytes(character), name=character["name"], conflict="replace")

    theme = {
        "name": "[Fixture] Aster 本地主题",
        "background": {"image": "{{aster.resource:resource-png}}", "opacity": 0.72, "useAvatar": False, "color": "#FF020B12"},
        "userBubble": {"color": "#CC0A1B26", "blur": 8, "radius": 12, "alignment": "right"},
        "characterBubble": {"color": "#CC07141D", "blur": 8, "radius": 12, "alignment": "left"},
        "userBubbleFont": {"textStyle": {"fontFamily": "Aster Fixture", "fontSize": 16, "fontWeight": 500, "color": "#FFE8F7FF"}},
        "characterBubbleFont": {"textStyle": {"fontFamily": "Aster Fixture", "fontSize": 16, "fontWeight": 500, "color": "#FFE8F7FF"}},
        "console": {"color": "#CC031018", "blur": 16, "radius": 14, "sendColor": "#FF62E7FF", "fontSize": 16, "fontWeight": 500, "fontColor": "#FFE8F7FF", "placeholderColor": "#FF7893A3"},
    }
    add("theme-native", "theme", "content/themes/native-theme.json", json_bytes(theme), name=theme["name"], conflict="replace")

    thm_theme = {
        "name": "[Fixture] Aster THM 主题",
        "background": {"image": "background.svg", "opacity": 0.68, "useAvatar": False, "color": "#FF01070D"},
        "userBubble": {"color": "#CC101827", "blur": 10, "radius": 10, "alignment": "right"},
        "characterBubble": {"color": "#CC07131E", "blur": 10, "radius": 10, "alignment": "left"},
        "console": {"color": "#CC020A10", "blur": 18, "radius": 12, "sendColor": "#FFC98CFF", "fontColor": "#FFEAF8FF"},
    }
    thm = zip_bytes({"theme.json": json_bytes(thm_theme), "background.svg": resources["resource-svg"][2]})
    add("theme-package", "themePackage", "content/themes/fixture.thm", thm, name=thm_theme["name"], targetName="aster-fixture-theme.thm", conflict="skip")

    variables = {
        "scope": "chat",
        "values": {
            "aster.fixture.ready": True,
            "aster.fixture.version": FIXTURE_VERSION,
            "aster.fixture.wallpaper": "{{aster.resource:resource-png}}",
            "aster.fixture.formats": ["json", "thm", "png", "svg", "wav", "mp4", "ttf", "css", "txt", "ejs"],
        },
    }
    add("variables-runtime", "variables", "content/variables/runtime.json", json_bytes(variables), scope="chat", conflict="replace")

    return payloads, items


def build_fixture() -> Path:
    payloads, items = build_fixture_payloads()
    manifest = {
        "spec": "aster.mod/v1",
        "id": "io.aster.fixture.complete",
        "name": "Aster 完整格式验证包",
        "version": FIXTURE_VERSION,
        "defaultConflict": "replace",
        "items": items,
        "activate": {
            "chat": {
                "mode": "merge",
                "lorebooks": ["book-core", "book-function", "book-codex", "book-system", "book-skin", "book-narrative"],
                "regexes": ["regex-ui"],
                "preset": "preset-story",
                "theme": "theme-native",
            }
        },
    }
    payloads["aster-mod.json"] = json_bytes(manifest)
    target = OUT / f"Aster-complete-mod-fixture-{FIXTURE_VERSION}.zip"
    write_zip(target, payloads)
    return target


def build_plugin() -> Path:
    files = {
        path.relative_to(PLUGIN).as_posix(): path.read_bytes()
        for path in PLUGIN.rglob("*")
        if path.is_file()
    }
    target = OUT / f"aster-mod-importer-{PLUGIN_VERSION}.tpg"
    write_zip(target, files)
    return target


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fixture = build_fixture()
    plugin = build_plugin()
    checksums = OUT / f"Aster-mod-importer-{PLUGIN_VERSION}-SHA256SUMS.txt"
    checksums.write_text(
        "".join(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n" for path in (plugin, fixture)),
        encoding="utf-8",
    )
    print(plugin)
    print(fixture)
    print(checksums)


if __name__ == "__main__":
    main()
