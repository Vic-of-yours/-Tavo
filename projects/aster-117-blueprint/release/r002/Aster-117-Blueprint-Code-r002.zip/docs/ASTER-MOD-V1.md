# Aster Mod Package v1

`aster.mod/v1` is a deterministic ZIP envelope for importing a complete Tavo
content bundle through one system-file selection. It is an Aster package
format, not an undocumented Tavo API.

## Package layout

The ZIP root must contain `aster-mod.json`. Payloads may live in nested
directories, use forward slashes, and must be UTF-8 where the item type is
JSON. ZIP64, encryption, symbolic links, duplicate names, absolute paths,
backslashes and `..` paths are rejected.

```text
aster-mod.json
content/lorebooks/Aster-core.json
content/characters/Aster-player.json
content/presets/Aster-story.json
content/regex/Aster-ui.json
content/themes/Aster-night.json
content/themes/Aster-night.thm
content/variables/runtime.json
assets/background.svg
assets/click.wav
assets/intro.mp4
assets/ui.ttf
```

## Manifest

```json
{
  "spec": "aster.mod/v1",
  "id": "io.aster.example",
  "name": "Aster Example Mod",
  "version": "1.0.0",
  "defaultConflict": "replace",
  "repair": {
    "asterModules": "deduplicate"
  },
  "items": [
    {
      "id": "book-core",
      "type": "lorebook",
      "path": "content/lorebooks/Aster-core.json",
      "name": "Aster·核心",
      "sha256": "<64 lowercase hex characters>"
    },
    {
      "id": "resource-background",
      "type": "resource",
      "path": "assets/background.svg",
      "targetName": "aster-background.svg",
      "scope": "global",
      "sha256": "<64 lowercase hex characters>"
    }
  ],
  "activate": {
    "chat": {
      "mode": "merge",
      "lorebooks": ["book-core"],
      "regexes": ["regex-ui"],
      "preset": "preset-story",
      "theme": "theme-night"
    }
  }
}
```

Required root fields are `spec`, `id`, `name`, `version` and `items`. Item IDs
are package-local stable identifiers. Every payload has a mandatory SHA-256
digest. Supported conflict policies are `replace`, `rename`, `skip` and
`error`. `repair` is optional and intentionally narrow: the only accepted
mode is `asterModules: "deduplicate"`. It removes older duplicate
`⟦aster·module⟧` entries by module ID after normal item writes, preserves all
non-module entries and book containers, verifies the result, and participates
in the same compensating rollback journal.

## Item types

| Type | Payload | Native Tavo operation |
|---|---|---|
| `lorebook` | Tavo-native world-book JSON | `tavo.lorebook.create/update` |
| `character` | Tavo-native character-card JSON | `tavo.character.create/update` |
| `preset` | Tavo-native preset JSON | `tavo.preset.create/update` |
| `regex` | Tavo-native regex-group JSON | `tavo.regex.create/update` |
| `theme` | Tavo-native theme JSON | `tavo.theme.create/update` |
| `themePackage` | `.thm` ZIP containing `theme.json` | native Tavo export envelopes use `tavo.theme.import`; a raw named ChatTheme uses `tavo.theme.create/update` and localizes embedded assets |
| `variables` | `{ "scope": "chat|global", "values": {...} }` | `tavo.set` per key |
| `resource` | image/audio/video/font/text/binary bytes | `tavo.file.save(..., { encoding: "base64" })` |

`regex` and `themePackage` may still show Tavo's own confirmation/conflict
dialogue. The importer does not bypass native safety prompts.

## Local resource references

Any string inside a JSON payload may reference a resource item:

```text
{{aster.resource:resource-background}}
```

Resources are committed first. The importer replaces the token with the exact
`files/chat/...` or `files/global/...` path returned by Tavo before writing the
dependent JSON payload. No network URL is required. Importer 1.4.0 also upserts
each ordinary resource and each embedded portable-theme asset into the
chat/global `aster.resource.index.v1` index and the fixed non-triggering
`Aster·资源书`. Each entry records its logical ID, stored filename, virtual path,
scope, MIME/kind, SHA-256, references, localization render state, and timestamps.

## Incremental lorebook updates

`replace` on an exact-name lorebook is implemented as an entry-level merge:
`identifier`, `uid`, and display name are all stable matching keys. Unique
entries from superseded exact-name books are merged into the selected canonical
book first; the currently bound/canonical copy wins among old versions, then
matching package entries replace it, new package entries append, and unrelated
existing/manual entries remain. Tavo currently exposes a whole-book
`lorebook.update` call rather than an entry mutation endpoint, so the importer
performs the merge after `get` and submits one verified `update` payload. The
fixed resource book uses the same exact-name rule and repairs empty names and
duplicate resource identities before writeback. Once all writes, activation,
and readbacks succeed, exact-name old objects are removed by ID and read back as
absent; current-chat bindings are rewritten to the canonical ID before deletion.

## Transaction model

Tavo's system picker copies the selected ZIP atomically, but the public API
does not expose a cross-type database transaction. The importer therefore:

1. reads and validates every archive entry;
2. verifies ZIP CRC-32 and each manifest SHA-256;
3. validates all item schemas, references, conflicts and activation IDs;
4. asks once for confirmation (configurable);
5. writes resources, books, character cards, presets, regexes, themes and variables in dependency
   order;
6. reads each result back before continuing;
7. activates imported IDs on the current chat;
8. rewrites stale current-chat bindings and deletes superseded exact-name objects;
9. runs compensating rollback in reverse order if an earlier transactional operation fails;
10. saves a machine-readable receipt at
   `files/global/aster-mod-last-receipt.json`.

After a successful transaction, the selected ZIP copy is deleted by virtual
path, checked with `file.exists`, and retried by final filename plus chat scope
when necessary. The cleanup result is then persisted into the receipt; a
failed import intentionally retains its source ZIP for diagnosis.

An installed importer plugin is still required once. The documented Tavo API
does not provide an API for one plugin to silently install another `.tpg`.
