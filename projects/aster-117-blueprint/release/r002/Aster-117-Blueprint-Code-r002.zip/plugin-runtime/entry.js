(function () {
  'use strict';
  var VERSION = '0.9.0';
  var MIN_VERSION_NUMBER = 930;
  var BOOKS = ['Aster·核心', 'Aster·功能', 'Aster·图鉴', 'Aster·系统', 'Aster·皮肤'];
  var START = '⟦aster·module⟧';
  var END = '⟦/aster·module⟧';
  var W = window.top || window;
  var DOC = W.document;
  var Aster = null;
  var scanning = null;
  var bootState = { booted: false, scanning: false, at: null, books: [], index: [], errors: [], version: VERSION };

  function config(key, fallback) {
    try { var value = tavo.plugin.config.get(key); return value == null ? fallback : value; }
    catch (error) { return fallback; }
  }
  function debug() { if (config('debug', false)) try { console.log.apply(console, ['[Aster]'].concat([].slice.call(arguments))); } catch (error) {} }
  function report() { try { console.error.apply(console, ['[Aster]'].concat([].slice.call(arguments))); } catch (error) {} }
  function toast(text) { try { tavo.utils.toast(text); } catch (error) {} }
  function tr(key, fallback, vars) {
    var value = fallback;
    try { value = tavo.plugin.i18n.t(key, vars || {}); } catch (error) {}
    Object.keys(vars || {}).forEach(function (name) { value = String(value).replace('{' + name + '}', vars[name]); });
    return value;
  }
  function emitWindow(name, detail) { try { W.dispatchEvent(new CustomEvent(name, { detail: detail })); } catch (error) {} }
  function readStore(key, fallback) { try { var value = tavo.get(key, 'global'); return value == null ? fallback : value; } catch (error) { return fallback; } }
  function writeStore(key, value) { try { tavo.set(key, value, 'global'); return true; } catch (error) { return false; } }

  function parseSections(rest) {
    var sections = {}, re = /\n--- (meta|code|css|doc)\s*\n/g, match, last = null, start = 0;
    while ((match = re.exec(rest))) {
      if (last) sections[last] = rest.slice(start, match.index);
      last = match[1]; start = match.index + match[0].length;
    }
    if (last) sections[last] = rest.slice(start);
    return sections;
  }
  function parseModules(text, book) {
    text = String(text || '');
    var output = [], cursor = 0;
    while (true) {
      var open = text.indexOf(START, cursor);
      if (open < 0) break;
      var close = text.indexOf(END, open + START.length);
      if (close < 0) throw new Error(book + ': unclosed Aster module fence');
      var block = text.slice(open + START.length, close);
      cursor = close + END.length;
      var sectionAt = block.search(/\n--- (?:meta|code|css|doc)\s*\n/);
      var headerText = sectionAt < 0 ? block : block.slice(0, sectionAt);
      var rest = sectionAt < 0 ? '' : block.slice(sectionAt);
      var head = {};
      headerText.split('\n').forEach(function (line) {
        var row = /^\s*@(\w+)\s*(.*)$/.exec(line);
        if (row) head[row[1]] = row[2].trim();
      });
      if (!head.id || !/^aster\./.test(head.id)) throw new Error(book + ': invalid module id');
      var sections = parseSections(rest);
      output.push({
        id: head.id, name: head.name || head.id, type: head.type || 'fn.misc', version: head.version || '0.0.0',
        order: Number(head.order || 100) || 0, deps: head.deps ? head.deps.split(/[\s,]+/).filter(Boolean) : [],
        enabled: head.enabled !== 'false', meta: sections.meta || '', code: sections.code || '', css: sections.css || '', doc: sections.doc || '', book: book
      });
    }
    return output;
  }
  function sortModules(modules) {
    var byId = Object.create(null), visiting = Object.create(null), visited = Object.create(null), output = [];
    modules.forEach(function (module) {
      if (byId[module.id]) throw new Error('duplicate Aster module id: ' + module.id);
      byId[module.id] = module;
    });
    function visit(module, chain) {
      if (visited[module.id]) return;
      if (visiting[module.id]) throw new Error('circular dependency: ' + chain.concat(module.id).join(' -> '));
      visiting[module.id] = true;
      module.deps.forEach(function (id) {
        if (!byId[id]) throw new Error(module.id + ': missing dependency ' + id);
        visit(byId[id], chain.concat(module.id));
      });
      visiting[module.id] = false; visited[module.id] = true; output.push(module);
    }
    modules.slice().sort(function (a, b) { return a.order - b.order || a.id.localeCompare(b.id); }).forEach(function (module) { visit(module, []); });
    return output;
  }
  function enabled(module) {
    var map = readStore('aster.module.enabled', {}) || {};
    var id = typeof module === 'string' ? module : module && module.id;
    if (!id) return false;
    var defaultEnabled = !module || typeof module === 'string' || module.enabled == null ? true : !!module.enabled;
    return map[id] == null ? defaultEnabled : !!map[id];
  }
  function injectStyle(id, css) {
    if (!css || !css.trim()) return;
    var styleId = 'aster-runtime-style-' + id.replace(/[^a-zA-Z0-9_-]/g, '-');
    var node = DOC.getElementById(styleId);
    if (!node) { node = DOC.createElement('style'); node.id = styleId; (DOC.head || DOC.documentElement).appendChild(node); }
    node.textContent = css;
  }
  async function dispatch(module) {
    if (module.css.trim()) injectStyle(module.id, module.css);
    if (module.type.split('.')[0] === 'style') {
      if (Aster.styles && Aster.styles.register) Aster.styles.register(module.id, { label: module.name, css: module.css, version: module.version, book: module.book, order: module.order });
      return;
    }
    if (module.code.trim()) {
      var execute = new Function('Aster', 'tavo', 'log', 'DOC', 'return (async function () {\n' + module.code + '\n}).call(this);');
      await execute(Aster, tavo, debug, DOC);
    }
  }
  function freshRuntime() {
    var previous = W.Aster;
    try { if (previous && previous.overlay && previous.overlay.closeAll) previous.overlay.closeAll(); } catch (error) {}
    Aster = W.Aster = { version: VERSION, boot: Boot, hooks: null, lib: null };
    return Aster;
  }
  async function discover() {
    var all = await tavo.lorebook.all();
    var byName = Object.create(null);
    (all || []).forEach(function (book) { if (book && BOOKS.indexOf(book.name) >= 0) byName[book.name] = book; });
    var targets = BOOKS.filter(function (name) { return byName[name]; }).map(function (name) { return byName[name]; });
    var modules = [];
    for (var i = 0; i < targets.length; i += 1) {
      var book = await tavo.lorebook.get(targets[i].id);
      var entries = book && book.entries || [];
      if (!Array.isArray(entries)) entries = Object.keys(entries).map(function (key) { return entries[key]; });
      entries.forEach(function (entry) {
        if (!entry || entry.enabled === false || entry.disable === true) return;
        parseModules(entry.content || '', targets[i].name).forEach(function (module) { modules.push(module); });
      });
    }
    return { targets: targets, modules: modules };
  }
  async function runScan(reason) {
    bootState.scanning = true; bootState.errors = []; bootState.booted = false;
    toast(tr('runtime.scanning', 'Aster 正在扫描五书…'));
    freshRuntime();
    try {
      var found = await discover();
      bootState.books = found.targets.map(function (book) { return book.name; });
      if (!found.modules.length) throw new Error(tr('runtime.empty', '未找到 Aster 模块'));
      var sorted = sortModules(found.modules), index = [];
      for (var i = 0; i < sorted.length; i += 1) {
        var module = sorted[i];
        var row = { id: module.id, name: module.name, type: module.type, version: module.version, order: module.order, book: module.book, status: 'pending' };
        if (!enabled(module)) { row.status = 'disabled'; index.push(row); continue; }
        try { await dispatch(module); row.status = 'loaded'; }
        catch (error) {
          row.status = 'failed'; row.error = error && error.message || String(error);
          bootState.errors.push({ id: module.id, message: row.error });
          report('module failed', module.id, error);
        }
        index.push(row);
      }
      bootState.index = index; bootState.at = new Date().toISOString(); bootState.booted = bootState.errors.length === 0; bootState.scanning = false;
      writeStore('aster.module.index', index);
      writeStore('aster.boot.index', { at: bootState.at, books: bootState.books, count: index.length, errors: bootState.errors });
      try { if (Aster.shell && Aster.shell.reconnect) Aster.shell.reconnect(); } catch (error) {}
      if (Aster.hooks && Aster.hooks.emit) Aster.hooks.emit('aster:ready', { index: index, books: bootState.books, errors: bootState.errors, reason: reason || 'boot' });
      emitWindow('aster-ready', { index: index, books: bootState.books, errors: bootState.errors });
      if (bootState.errors.length) toast(tr('runtime.failed', 'Aster 启动失败：{message}', { message: bootState.errors.length + ' module(s)' }));
      else toast(tr('runtime.ready', 'Aster 已就绪：{count} 个模块', { count: index.length }));
      return index;
    } catch (error) {
      bootState.scanning = false; bootState.booted = false;
      bootState.errors.push({ id: 'boot', message: error && error.message || String(error) });
      report('boot failed', error);
      toast(tr('runtime.failed', 'Aster 启动失败：{message}', { message: error && error.message || error }));
      throw error;
    }
  }
  function scan(reason) {
    if (scanning) return scanning;
    scanning = runScan(reason).finally(function () { scanning = null; });
    return scanning;
  }
  var Boot = {
    wake: function () { return scan('wake'); },
    rescan: function () { return scan('rescan'); },
    index: function () { return bootState.index.slice(); },
    state: function () { return { booted: bootState.booted, scanning: bootState.scanning, at: bootState.at, books: bootState.books.slice(), errors: bootState.errors.slice(), version: VERSION, commonAssets: Aster && Aster.commonAssets ? Aster.commonAssets.records().length : 0 }; },
    refreshAssets: function () { return Aster && Aster.commonAssets ? Aster.commonAssets.hydrate() : Promise.resolve([]); },
    isEnabled: enabled,
    setModuleEnabled: function (id, on) { var map = readStore('aster.module.enabled', {}) || {}; map[id] = !!on; writeStore('aster.module.enabled', map); return !!on; }
  };

  function bridge(type, windowName) {
    return function (event) {
      try { if (Aster && Aster.hooks) Aster.hooks.emit(type, event); } catch (error) { report('hook bridge', type, error); }
      if (windowName) emitWindow(windowName, event);
    };
  }
  function bridgeAsync(type) {
    return function (event) { return Aster && Aster.hooks && Aster.hooks.emitAsync ? Aster.hooks.emitAsync(type, event) : Promise.resolve(); };
  }
  try {
    tavo.plugin.on('chat:opened', function (event) { return scan('chat-opened').then(function () { bridge('aster:chat-opened', 'aster-chat-opened')(event); }); });
    tavo.plugin.on('chat:closed', bridge('aster:chat-closed'));
    tavo.plugin.on('chat:updated', bridge('aster:chat-updated'));
    tavo.plugin.on('message:added', bridge('aster:message-added', 'aster-message-added'));
    tavo.plugin.on('message:updated', bridge('aster:message-updated'));
    tavo.plugin.on('message:deleted', bridge('aster:message-deleted'));
    tavo.plugin.on('generation:prepare', bridgeAsync('aster:generation-prepare'));
    tavo.plugin.on('generation:success', bridgeAsync('aster:generation-success'));
    tavo.plugin.on('generation:error', bridge('aster:generation-error'));
    tavo.plugin.on('generation:cancelled', bridge('aster:generation-cancelled'));
    tavo.plugin.on('input:beforeSend', bridgeAsync('aster:input-beforeSend'));
    tavo.plugin.on('input:afterSend', bridge('aster:input-afterSend'));
    tavo.plugin.onSidebarAction('aster-manager', function () {
      if (Aster && Aster.shell && Aster.shell.openManager) Aster.shell.openManager();
      else emitWindow('aster-open-manager');
    });
    tavo.plugin.onSidebarAction('aster-rescan', function () { return scan('sidebar'); });
  } catch (error) { report('plugin hook registration failed', error); }
  W.addEventListener('aster-import-complete', function () { scan('import-complete'); });

  Promise.resolve().then(async function () {
    try {
      if (tavo.app && typeof tavo.app.versionNumber === 'function') {
        var current = await tavo.app.versionNumber();
        if (Number(current) < MIN_VERSION_NUMBER) throw new Error('Tavo >= 0.93.0 required');
      }
      await scan('startup');
    } catch (error) { report('startup', error); }
  });
})();
