'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
function filesUnder(root) {
  return fs.readdirSync(root, { withFileTypes: true }).flatMap((entry) => {
    const target = path.join(root, entry.name);
    return entry.isDirectory() ? filesUnder(target) : [target];
  });
}

const sourceFiles = filesUnder(path.join(ROOT, 'src-modules'));
const pluginFiles = filesUnder(path.join(ROOT, 'plugin-runtime'));
const sourceText = sourceFiles.map((file) => fs.readFileSync(file, 'utf8')).join('\n');
const allText = sourceText + '\n' + pluginFiles.map((file) => fs.readFileSync(file, 'utf8')).join('\n');
const contract = fs.readFileSync(path.join(ROOT, 'src-modules/core/05-ui-contracts.txt'), 'utf8');
const tokenSkin = fs.readFileSync(path.join(ROOT, 'src-modules/skin/10-tokens.txt'), 'utf8');
const shellSkin = fs.readFileSync(path.join(ROOT, 'src-modules/skin/18-shell-style.txt'), 'utf8');

const cssClasses = [...new Set([...allText.matchAll(/\.(aster-[a-z0-9-]+)/g)].map((match) => match[1]))].sort();
const registered = [...new Set([...contract.matchAll(/'(aster-[a-z0-9-]+)'/g)].map((match) => match[1]))].sort();
const missing = cssClasses.filter((name) => !registered.includes(name));
assert.deepStrictEqual(missing, [], 'every Aster CSS class must be registered by Core: ' + missing.join(', '));

const privateClassAssignments = [...sourceText.matchAll(/class(?:Name)?\s*[:=]\s*['"](aster-[a-z0-9-]+)/g)].map((match) => match[1]);
assert.deepStrictEqual(privateClassAssignments, [], 'feature modules must consume semantic class IDs, not private class strings');

const composer = fs.readFileSync(path.join(ROOT, 'src-modules/core/09-composer.txt'), 'utf8');
for (const registry of ['componentTypes', 'styleRecipes', 'effectPresets', 'commands', 'blueprints']) {
  assert.ok(composer.includes('Aster.' + registry + ' = ' + registry), registry + ' is exposed as a Core registry');
}
assert.ok(/global defaults, then component-type defaults, then explicit instance/.test(composer), 'composer documents the inheritance order');
assert.ok(/--aster-phone-case-width:\s*7px/.test(tokenSkin) && /--aster-phone-case-edge:/.test(tokenSkin), 'phone case dimensions and theme-derived edge are Skin tokens');
assert.ok(/\.aster-phone-frame::before\s*\{[^}]*var\(--aster-phone-case-width\)[^}]*var\(--aster-phone-case-surface\)/s.test(shellSkin), 'phone frame owns a non-layout-shrinking case layer');
assert.ok(/\.aster-phone-status::before\s*\{[^}]*width:\s*27px[^}]*height:\s*2px/s.test(shellSkin), 'phone case exposes the earpiece detail');

const result = { ok: true, checks: 11, cssClasses: cssClasses.length, registeredClasses: registered.length, missingClasses: missing.length, privateFeatureClasses: privateClassAssignments.length };
fs.writeFileSync(path.join(ROOT, 'reports/ui-contract-test-results.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
