'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
let checks = 0;
function check(value, message) { assert.ok(value, message); checks += 1; }
function equal(actual, expected, message) { assert.strictEqual(actual, expected, message); checks += 1; }

function main() {
  const legacy = path.join(ROOT, 'plugin-importer');
  const releaseSource = fs.readFileSync(path.join(ROOT, 'tools/build_blueprint_packages.py'), 'utf8');
  const readme = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
  const manager = fs.readFileSync(path.join(ROOT, 'src-modules/system/730-data-manager.txt'), 'utf8');
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'plugin-mod-importer/manifest.json'), 'utf8'));
  const importer = fs.readFileSync(path.join(ROOT, 'plugin-mod-importer/entry.js'), 'utf8');

  check(!fs.existsSync(legacy), 'legacy five-book importer source tree is removed');
  check(!/plugin-importer|aster-importer-/.test(releaseSource), 'release package contains no legacy importer');
  check(!/aster-importer-|导入 Aster 五书/.test(readme), 'installation guide contains no legacy importer path');
  check(!/data-aster-manager-import|importNative\(|importManifest\(/.test(manager), 'Data Manager contains no package or file import route');
  equal(manifest.id, 'io.aster.mod-importer', 'one standalone complete-package importer remains');
  equal(manifest.version, '1.4.0', 'complete-package importer version is current');
  check(/file\.import/.test(importer) && /aster\.mod\/v1/.test(importer), 'complete-package importer uses the system picker and validates the package spec');

  const result = { ok: true, checks, legacyImporterRemoved: true, activeImporter: manifest.id, version: manifest.version };
  fs.writeFileSync(path.join(ROOT, 'reports/importer-test-results.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
}

try { main(); } catch (error) { console.error(error.stack || error); process.exitCode = 1; }
