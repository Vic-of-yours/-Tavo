'use strict';

class FakeEvent {
  constructor(type, init = {}) {
    this.type = type;
    this.bubbles = init.bubbles !== false;
    this.cancelable = init.cancelable !== false;
    this.defaultPrevented = false;
    this.propagationStopped = false;
    Object.assign(this, init);
  }
  preventDefault() { if (this.cancelable) this.defaultPrevented = true; }
  stopPropagation() { this.propagationStopped = true; }
}

class FakeCustomEvent extends FakeEvent {
  constructor(type, init = {}) { super(type, init); this.detail = init.detail; }
}

class FakeEventTarget {
  constructor() { this._listeners = Object.create(null); }
  addEventListener(type, handler) {
    if (typeof handler !== 'function') return;
    (this._listeners[type] || (this._listeners[type] = [])).push(handler);
  }
  removeEventListener(type, handler) {
    this._listeners[type] = (this._listeners[type] || []).filter((row) => row !== handler);
  }
  dispatchEvent(event) {
    if (!(event instanceof FakeEvent)) event = new FakeEvent(event.type || String(event), event);
    if (!event.target) event.target = this;
    event.currentTarget = this;
    for (const handler of (this._listeners[event.type] || []).slice()) handler.call(this, event);
    if (event.bubbles && !event.propagationStopped && this.parentNode && this.parentNode.dispatchEvent) {
      this.parentNode.dispatchEvent(event);
    }
    return !event.defaultPrevented;
  }
}

class FakeClassList {
  constructor(node) { this.node = node; }
  _set() { return new Set(String(this.node.className || '').split(/\s+/).filter(Boolean)); }
  _write(set) { this.node.className = Array.from(set).join(' '); }
  add(...names) { const set = this._set(); names.forEach((name) => set.add(name)); this._write(set); }
  remove(...names) { const set = this._set(); names.forEach((name) => set.delete(name)); this._write(set); }
  contains(name) { return this._set().has(name); }
  toggle(name, force) {
    const set = this._set();
    const on = force == null ? !set.has(name) : !!force;
    if (on) set.add(name); else set.delete(name);
    this._write(set); return on;
  }
}

function selectorParts(selector) {
  selector = selector.trim();
  const attr = /\[([^=\]]+)(?:=["']?([^\]"']*)["']?)?\]/.exec(selector);
  const base = selector.replace(/\[[^\]]+\]/g, '');
  const id = /#([\w-]+)/.exec(base);
  const cls = /\.([\w-]+)/.exec(base);
  const tag = /^([a-zA-Z][\w-]*)/.exec(base);
  return { tag: tag && tag[1].toUpperCase(), id: id && id[1], cls: cls && cls[1], attr: attr && attr[1], value: attr && attr[2] };
}

function matches(node, selector) {
  if (!node || node.nodeType !== 1) return false;
  const part = selectorParts(selector);
  if (part.tag && node.tagName !== part.tag) return false;
  if (part.id && node.id !== part.id) return false;
  if (part.cls && !node.classList.contains(part.cls)) return false;
  if (part.attr) {
    if (!node.hasAttribute(part.attr)) return false;
    if (part.value != null && node.getAttribute(part.attr) !== part.value) return false;
  }
  return !!(part.tag || part.id || part.cls || part.attr);
}

class FakeElement extends FakeEventTarget {
  constructor(tagName, ownerDocument) {
    super();
    this.nodeType = 1;
    this.tagName = String(tagName).toUpperCase();
    this.ownerDocument = ownerDocument;
    this.parentNode = null;
    this.childNodes = [];
    this.style = {};
    this.attributes = Object.create(null);
    this.className = '';
    this.classList = new FakeClassList(this);
    this._text = '';
    this._innerHTML = '';
    this._value = undefined;
    this.checked = false;
    this.selected = false;
    this.disabled = false;
  }
  get children() { return this.childNodes.filter((node) => node.nodeType === 1); }
  get firstChild() { return this.childNodes[0] || null; }
  get id() { return this.attributes.id || ''; }
  set id(value) { this.attributes.id = String(value); }
  get textContent() {
    if (this.childNodes.length) return this.childNodes.map((node) => node.textContent || '').join('');
    return this._text;
  }
  set textContent(value) { this.childNodes = []; this._innerHTML = ''; this._text = value == null ? '' : String(value); }
  get innerHTML() { return this._innerHTML || this.textContent; }
  set innerHTML(value) { this.childNodes = []; this._text = ''; this._innerHTML = value == null ? '' : String(value); }
  get value() {
    if (this._value !== undefined) return this._value;
    if (this.tagName === 'SELECT') {
      const option = this.children.find((row) => row.selected) || this.children[0];
      return option ? option.getAttribute('value') || option.textContent : '';
    }
    return '';
  }
  set value(value) { this._value = value == null ? '' : String(value); }
  get offsetWidth() {
    if (this.id === 'aster-shell-dashboard') return 68;
    if (this.id === 'aster-shell-phone') return 58;
    return Number.parseFloat(this.style.width) || 100;
  }
  get offsetHeight() {
    if (this.id === 'aster-shell-dashboard') return 76;
    if (this.id === 'aster-shell-phone') return 58;
    return Number.parseFloat(this.style.height) || 42;
  }
  appendChild(node) {
    if (!node) throw new Error('appendChild requires a node');
    if (node.parentNode) node.parentNode.removeChild(node);
    this.childNodes.push(node); node.parentNode = this; return node;
  }
  removeChild(node) {
    const index = this.childNodes.indexOf(node);
    if (index < 0) throw new Error('node is not a child');
    this.childNodes.splice(index, 1); node.parentNode = null; return node;
  }
  remove() { if (this.parentNode) this.parentNode.removeChild(this); }
  setAttribute(name, value) {
    name = String(name);
    this.attributes[name] = value == null ? '' : String(value);
    if (name === 'class') this.className = this.attributes[name];
    if (name === 'value') this._value = this.attributes[name];
    if (name === 'disabled') this.disabled = true;
  }
  getAttribute(name) { return Object.prototype.hasOwnProperty.call(this.attributes, name) ? this.attributes[name] : null; }
  hasAttribute(name) { return Object.prototype.hasOwnProperty.call(this.attributes, name); }
  removeAttribute(name) { delete this.attributes[name]; }
  querySelectorAll(selector) {
    const output = [];
    function visit(node) {
      for (const child of node.childNodes || []) {
        if (matches(child, selector)) output.push(child);
        visit(child);
      }
    }
    visit(this); return output;
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  matches(selector) { return matches(this, selector); }
  click() {
    if (this.disabled) return;
    this.dispatchEvent(new FakeEvent('click', { bubbles: true, cancelable: true }));
  }
  focus() { this.ownerDocument.activeElement = this; }
  setPointerCapture() {}
  releasePointerCapture() {}
  getBoundingClientRect() {
    const win = this.ownerDocument.defaultView;
    const width = this.offsetWidth, height = this.offsetHeight;
    let left = Number.parseFloat(this.style.left);
    let top = Number.parseFloat(this.style.top);
    if (!Number.isFinite(left)) left = this.id === 'aster-shell-dashboard' ? (win.innerWidth - width - 18) : (win.innerWidth - width - 16);
    if (!Number.isFinite(top)) top = this.id === 'aster-shell-dashboard' ? (win.innerHeight - height - 108) : 86;
    return { left, top, right: left + width, bottom: top + height, width, height, x: left, y: top };
  }
}

class FakeDocument extends FakeEventTarget {
  constructor() {
    super();
    this.nodeType = 9;
    this.parentNode = null;
    this.documentElement = new FakeElement('html', this);
    this.head = new FakeElement('head', this);
    this.body = new FakeElement('body', this);
    this.documentElement.appendChild(this.head);
    this.documentElement.appendChild(this.body);
    this.activeElement = null;
    this.defaultView = null;
  }
  createElement(tag) { return new FakeElement(tag, this); }
  getElementById(id) {
    if (this.documentElement.id === id) return this.documentElement;
    return this.documentElement.querySelector('#' + id);
  }
  querySelectorAll(selector) {
    const output = [];
    if (matches(this.documentElement, selector)) output.push(this.documentElement);
    return output.concat(this.documentElement.querySelectorAll(selector));
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
}

class FakeWindow extends FakeEventTarget {
  constructor(width = 390, height = 844) {
    super();
    this.innerWidth = width; this.innerHeight = height;
    this.document = new FakeDocument(); this.document.defaultView = this;
    this.window = this; this.self = this; this.top = this;
  }
}

function createDOM(width, height) {
  const window = new FakeWindow(width, height);
  return { window, document: window.document, Event: FakeEvent, CustomEvent: FakeCustomEvent, Element: FakeElement };
}

module.exports = { createDOM, FakeEvent, FakeCustomEvent };
