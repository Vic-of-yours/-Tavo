'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { createTavo, makeContext, runFile, runFragment, waitFor, loadBooks, FakeEvent } = require('./harness');

const ROOT = path.resolve(__dirname, '..');
let checks = 0;
function check(value, message) { assert.ok(value, message); checks += 1; }
function equal(actual, expected, message) { assert.strictEqual(actual, expected, message); checks += 1; }
function findByText(nodes, text) { return Array.from(nodes || []).find((node) => node.textContent === text); }
function ancestorWithAttribute(node, attribute) {
  while (node) {
    if (node.getAttribute && node.getAttribute(attribute) != null) return node;
    node = node.parentNode;
  }
  return null;
}
function activateOrbitEntry(env, id, activated) {
  const button = env.document.querySelector('[data-orbit-entry="' + id + '"]');
  check(button, 'orbit entry exists before activation: ' + id);
  button.click();
  if (!activated()) {
    const ring = ancestorWithAttribute(button, 'data-orbit-ring');
    check(ring, 'orbit entry belongs to a keyboard-operable ring: ' + id);
    ring.dispatchEvent(new FakeEvent('keydown', { key: 'Enter', bubbles: true }));
  }
  check(activated(), 'orbit entry activates after focus plus Enter when needed: ' + id);
}
function socialEntryIds(nodes) {
  return Array.from(nodes || []).map((node) => {
    const entry = ancestorWithAttribute(node, 'data-aster-social-item');
    return entry && entry.getAttribute('data-aster-social-item');
  }).filter(Boolean);
}
function cssRuleBody(source, needles) {
  const rule = /([^{}]+)\{([^{}]*)\}/g;
  let match;
  while ((match = rule.exec(source))) {
    if (needles.every((needle) => match[1].includes(needle))) return match[2];
  }
  return '';
}
function cssPixel(body, property) {
  const match = body.match(new RegExp('(?:min-)?' + property + '\\s*:\\s*([0-9.]+)px'));
  return match ? Number(match[1]) : NaN;
}

async function boot(shellFirst, mutateTavo) {
  const books = loadBooks(ROOT);
  const mock = createTavo(books);
  if (mutateTavo) mutateTavo(mock.tavo);
  const dom = makeContext(mock.tavo, 390, 844);
  if (shellFirst) runFragment(dom.context, path.join(ROOT, 'plugin-runtime/ui/shell.html'));
  runFile(dom.context, path.join(ROOT, 'plugin-runtime/entry.js'));
  await waitFor(() => dom.window.Aster && !dom.window.Aster.boot.state().scanning && dom.window.Aster.boot.index().length, 'runtime boot');
  if (!shellFirst) runFragment(dom.context, path.join(ROOT, 'plugin-runtime/ui/shell.html'));
  await waitFor(() => dom.window.Aster.shell && dom.window.Aster.shell.connected, 'shell connection');
  return { books, mock, ...dom, Aster: dom.window.Aster };
}

function closeAll(env) {
  env.Aster.overlay.closeAll();
  equal(env.Aster.overlay.depth(), 0, 'overlay stack closes completely');
}

function phoneStateNodes(env) { return env.document.querySelectorAll('[data-aster-phone-state]'); }
function assertPhoneState(env, state) {
  equal(env.Aster.phone.state().state, state, 'phone controller state is ' + state);
  equal(phoneStateNodes(env).length, 1, 'phone renders exactly one state at a time');
  equal(phoneStateNodes(env)[0].getAttribute('data-aster-phone-state'), state, 'visible phone state is ' + state);
}
function openPhone(env) {
  env.window.__asterShell.hosts.phone.button.click();
  check(env.Aster.overlay.isOpen('phone'), 'upper-right phone event opens phone overlay');
  assertPhoneState(env, 'home');
}
function openDrawer(env) {
  openPhone(env);
  const key = env.document.querySelector('[data-aster-phone-key="drawer"]');
  check(key && key.textContent === '△', 'triangle quick key exists');
  key.click();
  assertPhoneState(env, 'drawer');
}
function enterDeveloper(env) {
  openPhone(env);
  env.document.querySelector('[data-aster-phone-world="true"]').click();
  check(env.document.querySelector('[data-aster-dev-prompt="true"]'), 'world-name click asks before entering developer mode');
  env.document.querySelector('[data-aster-dev-enter="true"]').click();
  assertPhoneState(env, 'developer');
}

async function main() {
  const env = await boot(true);
  const { Aster, document, window, mock } = env;
  const inventory = JSON.parse(fs.readFileSync(path.join(ROOT, 'out/aster-module-inventory.json'), 'utf8'));

  equal(Aster.boot.state().books.length, 5, 'all five exact books discovered');
  equal(Aster.boot.index().length, inventory.length, 'every built module reached boot index');
  equal(Aster.boot.state().errors.length, 0, 'boot has zero module errors');
  check(Aster.boot.index().every((row) => row.status === 'loaded'), 'all modules have loaded status');
  equal(mock.reads.length, 5, 'runtime reads exactly five matching books');
  check(!('Vic' in window), 'legacy global is absent');
  check(Array.from(mock.stores.global.keys()).every((key) => key.startsWith('aster.')), 'all runtime global keys are Aster-owned');
  equal(Aster.panels.count(), 25, 'all public panels are registered without a duplicate social thread overlay');
  equal(Aster.apps.count(), 16, 'normal and developer phone applications are registered');
  equal(Aster.params.count(), 62, 'core, phone, theme, semantic-slot, and resource parameters are registered');
  check(Aster.uiClasses.count() >= 158, 'expanded semantic UI and workbench class contract is populated');
  equal(Aster.containers.count(), 27, 'application and standalone container skeletons are registered');
  equal(Aster.slots.count(), 19, 'host, application, standalone, preference, and component slots are registered');
  equal(Aster.preferenceTypes.count(), 6, 'six preference types are registered by Skin');
  equal(Aster.preferenceSlots.count(), 6, 'six inner semantic preference slots are registered by Skin');
  equal(Aster.resourceSlots.count(), 6, 'six replaceable visual resource slots are registered by Skin');
  for (const id of ['io.aster.ui.world-media:world-map']) {
    check(Aster.assetManifests.has(id), 'generated world media manifest is registered: ' + id);
    check(/^aster-mod:\/\//.test(Aster.assetManifests.get(id).source), 'generated world media is declared as local Mod-managed content: ' + id);
  }
  check(!Aster.assetManifests.has('io.aster.ui.world-media:player-standing'), 'base runtime does not register a bundled player portrait');
  check(!Aster.assetManifests.has('io.aster.ui.orbit-holo:player-open'), 'orbit package does not register a bundled player portrait');
  equal(Aster.orbitAssets.records().length, 11, 'selected double-orbit and Holo Veil asset bridge owns eleven portrait-free runtime resources');
  for (const id of ['world-sphere', 'world-home', 'orbit-team', 'orbit-map-marker']) {
    check(Aster.assetManifests.has('io.aster.ui.orbit-holo:' + id), 'selected UI asset manifest is registered: ' + id);
  }
  equal(Aster.tools.count(), 26, 'Core owns twenty-six reusable atomic tools');
  const paged = Aster.toolkit.run('collection.paginate', { rows: [1, 2, 3, 4, 5], page: 2, pageSize: 2 });
  equal(paged.items.join(','), '3,4', 'shared collection pagination returns the requested stable slice');
  check(paged.hasMore && paged.pages === 3, 'shared collection pagination reports continuation metadata');
  const faceted = Aster.toolkit.run('collection.facets', { rows: [{ tag: 'home' }, { tag: 'home' }, { tag: 'north' }], fields: ['tag'] });
  equal(faceted.tag[0].value + ':' + faceted.tag[0].count, 'home:2', 'shared collection facets count reusable filter values');
  equal(Aster.workbenchAdapters.count(), 5, 'five thin Tavo workbench adapters are registered');
  equal(Aster.workbenches.count(), 5, 'five composable workbench recipes are registered');
  equal(Aster.managementAdapters.count(), 5, 'Data Manager reuses the shared adapter registry');
  const lorebookWorkbench = Aster.workbenchRuntime.inspect('data.lorebook');
  check(lorebookWorkbench.tools.includes('collection.query') && lorebookWorkbench.tools.includes('batch.affix') && lorebookWorkbench.tools.includes('record.commit'), 'a workbench composes selected Core tools instead of copying their logic');
  const resourceWorkbench = Aster.workbenchRuntime.inspect('resource.file');
  check(resourceWorkbench.tools.includes('record.batch-delete') && resourceWorkbench.tools.includes('adapter.action') && resourceWorkbench.tools.includes('text.copy'), 'resource workbench opts into shared batch, adapter-action, and copy tools');
  const pipelineCount = await Aster.workbenchRuntime.create('data.lorebook').pipe([
    { tool: 'entries.normalize' },
    { tool: 'batch.affix', payload: function (rows) { return { entries: rows, selection: 'all', position: 'prefix', value: '[组合] ' }; } }
  ], [{ name: '条目' }]);
  equal(pipelineCount, 1, 'workbench pipeline composes only the requested portions of reusable tools');
  equal(Aster.modules.get('aster.collection.tools').book, 'Aster·核心', 'tool and workbench registries physically live in the Core book');
  equal(Aster.blueprintModules.count(), 83, 'all r188 module boundaries are registered in the audit catalog');
  equal(Aster.interfaceContracts.count(), 19, 'known cross-book interfaces are registered with method contracts');
  const contractAudit = Aster.contractAudit.audit();
  check(contractAudit.summary.modulePending > 0, 'unimplemented blueprint modules remain explicitly pending');
  check(contractAudit.summary.interfaceReady >= 5, 'implemented Aster interfaces pass method-level conformance');
  assert.throws(() => Aster.contractAudit.require('repository.save'), /unavailable/, 'pending repository port never returns a fake service');
  const resourceRepository = Aster.contractAudit.require('repository.resource');
  check(resourceRepository === Aster.assets, 'resource repository contract resolves to the real localized asset ledger');
  checks += 1;
  equal(Aster.capabilities.count(), 5, 'five reusable container capabilities are registered');
  equal(Aster.containerBindings.count(), 3, 'shell and overlay capability bindings are registered');
  equal(Aster.cues.count(), 6, 'semantic feedback cues are registered');
  equal(Aster.componentTypes.count(), 3, 'surface, card, and action-card component types are registered');
  equal(Aster.styleRecipes.count(), 5, 'visual style recipes are separate from containers');
  equal(Aster.effectPresets.count(), 4, 'effect presets are separate from styles and functions');
  equal(Aster.commands.count(), 10, 'five shared commands plus five inner-orbit commands are registered independently');
  equal(Aster.blueprints.count(), 3, 'reusable UI composition blueprints are registered');
  equal(Aster.slotRuntime.status().filter((row) => row.kind === 'host' && row.attached).length, 4, 'all four real shell hosts are attached');
  check(Aster.capabilityRuntime.status().some((row) => row.binding === 'shell.phone'), 'phone host consumes registered capabilities');
  check(Aster.capabilityRuntime.status().some((row) => row.binding === 'shell.dashboard'), 'dashboard host consumes registered capabilities');

  const inheritedCard = Aster.composer.explain('card.default');
  equal(inheritedCard.style, 'card.standard', 'component type supplies its default style');
  equal(inheritedCard.sources.style, 'type', 'composition audit reports type-level style inheritance');
  equal(inheritedCard.fontRole, 'inherit', 'unmodified typography falls through to global default');
  equal(inheritedCard.sources.fontRole, 'global', 'composition audit reports global typography inheritance');
  const exceptionalCard = Aster.composer.explain('card.default', { style: 'card.danger', effects: [], fontRole: 'mono' });
  equal(exceptionalCard.style, 'card.danger', 'instance declaration overrides type style');
  equal(exceptionalCard.sources.style, 'instance', 'composition audit reports instance source');
  equal(exceptionalCard.effects.length, 0, 'explicit empty effect list disables inherited effects');
  equal(exceptionalCard.fontRole, 'mono', 'instance typography can override the default');
  let composedEvents = 0;
  Aster.hooks.on('aster:test-composed-command', function () { composedEvents += 1; }, { id: 'test.composed-command' });
  const composedCard = Aster.composer.create({
    type: 'action-card', style: 'card.danger', effects: [],
    command: { id: 'event.emit', payload: { type: 'aster:test-composed-command' } }
  });
  check(composedCard.root.classList.contains(Aster.ui.className('style.danger')), 'composer applies registered style recipe');
  equal(composedCard.root.getAttribute('data-aster-command'), 'event.emit', 'composer binds registered command');
  composedCard.root.click();
  equal(composedEvents, 1, 'composed command executes through registry');
  composedCard.destroy();

  const normalApps = Aster.apps.list((app) => !app.developer);
  const developerApps = Aster.apps.list((app) => !!app.developer);
  equal(normalApps.length, 11, 'player phone has eleven normal applications');
  equal(developerApps.length, 5, 'developer tray has five isolated tools');
  for (const app of normalApps) {
    openDrawer(env);
    const button = document.querySelector('[data-aster-app="' + app.id + '"]');
    check(button, 'normal application renders in drawer: ' + app.id);
    button.click();
    check(Aster.overlay.isOpen('panel:' + app.panel), 'normal application opens real panel: ' + app.id);
    closeAll(env);
  }
  for (const app of developerApps) {
    enterDeveloper(env);
    const button = document.querySelector('[data-aster-app="' + app.id + '"]');
    check(button, 'developer application renders only in developer tray: ' + app.id);
    button.click();
    check(Aster.overlay.isOpen('panel:' + app.panel), 'developer application opens real panel: ' + app.id);
    closeAll(env);
  }

  openDrawer(env);
  check(document.querySelector('[data-aster-app="data-manager"]'), 'Data Manager is player-facing in app drawer');
  check(document.querySelector('[data-aster-app="theme"]'), 'Theme is player-facing in app drawer');
  check(!document.querySelector('[data-aster-app="parameters"]'), 'parameter center is hidden outside developer mode');
  check(!document.querySelector('[data-aster-phone-dashboard="open"]'), 'phone contains no dashboard transition');
  const circleKey = document.querySelector('[data-aster-phone-key="home"]');
  const crossKey = document.querySelector('[data-aster-phone-key="back"]');
  check(circleKey && circleKey.textContent === '○', 'circle quick key exists');
  check(crossKey && crossKey.textContent === '×', 'cross quick key exists');
  circleKey.click();
  assertPhoneState(env, 'home');
  document.querySelector('[data-aster-phone-key="drawer"]').click();
  assertPhoneState(env, 'drawer');
  document.querySelector('[data-aster-phone-key="back"]').click();
  assertPhoneState(env, 'home');
  document.querySelector('[data-aster-phone-key="back"]').click();
  check(!Aster.overlay.isOpen('phone'), 'cross closes phone from home');

  openPhone(env);
  document.querySelector('[data-aster-phone-edit="true"]').click();
  assertPhoneState(env, 'edit');
  const wallpaper = document.querySelector('[data-aster-wallpaper-choice="violet-crystal"]');
  check(wallpaper, 'edit mode exposes registered wallpaper resources');
  wallpaper.click();
  equal(mock.stores.global.get('aster.param.skin.resource.phone.wallpaper'), 'violet-crystal', 'wallpaper selection persists through shared resource parameter');
  let dragApps = document.querySelectorAll('[data-aster-phone-drag]');
  check(dragApps.length >= 2, 'edit mode renders draggable application cards');
  const fromId = dragApps[0].getAttribute('data-aster-phone-drag');
  const toId = dragApps[1].getAttribute('data-aster-phone-drag');
  dragApps[0].dispatchEvent(new FakeEvent('pointerdown', { bubbles: true }));
  dragApps[1].dispatchEvent(new FakeEvent('pointerup', { bubbles: true }));
  const savedLayout = mock.stores.global.get('aster.phone.layout.v1');
  check(savedLayout && savedLayout.pages.some((page) => page.indexOf(fromId) >= 0 && page.indexOf(toId) >= 0), 'desktop drag swap persists complete layout');
  equal(Aster.phone.layout.get().pages.flat().filter((id) => id === fromId || id === toId).length, 2, 'desktop layout readback preserves both swapped apps');
  document.querySelector('[data-aster-phone-key="home"]').click();
  assertPhoneState(env, 'home');
  const beforeSwipe = Aster.phone.state().page;
  const homeScreen = document.querySelector('[data-aster-phone-state="home"]');
  homeScreen.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 21, clientX: 320, bubbles: true }));
  homeScreen.dispatchEvent(new FakeEvent('pointerup', { pointerId: 21, clientX: 40, bubbles: true }));
  check(Aster.phone.state().pages > 1, 'phone desktop contains multiple pages');
  check(Aster.phone.state().page !== beforeSwipe, 'horizontal swipe changes phone page');
  const touchHome = document.querySelector('[data-aster-phone-state="home"]');
  touchHome.dispatchEvent(new FakeEvent('touchstart', { touches: [{ clientX: 190, clientY: 620 }], bubbles: true }));
  touchHome.dispatchEvent(new FakeEvent('touchend', { changedTouches: [{ clientX: 190, clientY: 500 }], bubbles: true }));
  assertPhoneState(env, 'drawer');
  document.querySelector('[data-aster-phone-key="home"]').click();
  const holdTarget = document.querySelector('[data-aster-app]');
  holdTarget.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 22, clientX: 80, clientY: 330, bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 560));
  assertPhoneState(env, 'edit');
  closeAll(env);

  enterDeveloper(env);
  check(document.querySelector('[data-aster-app="parameters"]'), 'parameter center appears in developer mode');
  check(!document.querySelector('[data-aster-app="data-manager"]'), 'developer state replaces rather than flattens normal drawer');
  document.querySelector('[data-aster-dev-exit="true"]').click();
  assertPhoneState(env, 'home');
  closeAll(env);

  Aster.phone.open();
  const firstPhone = Aster.overlay.current('phone');
  const firstPhoneDepth = Aster.overlay.depth();
  const firstPhoneRenderCount = firstPhone.renderCount;
  const reusedPhone = Aster.phone.open();
  equal(reusedPhone.root, firstPhone.root, 'phone singleton reuses same overlay root');
  equal(Aster.overlay.depth(), firstPhoneDepth, 'phone singleton does not increase overlay depth');
  equal(reusedPhone.renderCount, firstPhoneRenderCount, 'phone singleton focus does not duplicate rendering');
  closeAll(env);

  Aster.dashboard.open();
  const firstDashboard = Aster.overlay.current('dashboard');
  const reusedDashboard = Aster.dashboard.open();
  equal(reusedDashboard.root, firstDashboard.root, 'dashboard singleton reuses same overlay root');
  equal(Aster.overlay.depth(), 1, 'dashboard singleton remains one global instance');
  closeAll(env);

  for (const panel of Aster.panels.list((row) => !row.internal)) {
    Aster.shell.openManager();
    const button = document.querySelector('[data-aster-open-panel="' + panel.id + '"]');
    check(button, 'manager renders registered panel button: ' + panel.id);
    button.click();
    check(Aster.overlay.isOpen('panel:' + panel.id), 'manager opens panel: ' + panel.id);
    closeAll(env);
  }
  for (const panel of Aster.panels.list((row) => !!row.internal)) {
    Aster.shell.openManager();
    check(!document.querySelector('[data-aster-open-panel="' + panel.id + '"]'), 'manager hides route-only child panel: ' + panel.id);
    closeAll(env);
  }

  window.__asterShell.hosts.dashboard.button.click();
  check(Aster.overlay.isOpen('dashboard'), 'lower-right hexagonal entry opens dashboard');
  equal(document.querySelector('[data-aster-dashboard-frame]').getAttribute('data-aster-surface'), 'safe-fullscreen', 'dashboard uses the host-safe fullscreen surface');
  equal(document.querySelector('[data-aster-dashboard-frame]').getAttribute('data-layout-revision'), 'orbit-2', 'dashboard mounts the compact double-orbit layout namespace');
  check(document.querySelector('.aster-worlddash') && !document.querySelector('.aster-dash-frame'), 'dashboard markup is insulated from legacy dash CSS');
  check(!document.querySelector('[data-aster-dice="roll"]'), 'world die is removed from immersive dashboard');
  equal(document.querySelector('.aster-worlddash-player-art').getAttribute('data-aster-resource-slot'), 'player.standing', 'dashboard keeps an empty semantic player-art slot');
  equal(document.querySelector('.aster-worlddash-player-art').getAttribute('data-aster-resource-state'), 'builtin', 'dashboard uses the non-image base fallback');
  check(document.querySelector('[data-aster-orbit-asset="world.sphere"]'), 'dashboard mounts the selected transparent world sphere');
  check(document.querySelector('[data-aster-orbit-asset="world.home"]'), 'dashboard mounts the selected isometric home scene');
  check(document.querySelector('[data-aster-scroll-key="world-dashboard"]'), 'dashboard owns one internal fullscreen scroll document');
  equal(Aster.dashboard.state().stats, 6, 'dashboard starts from six registered player stat slots');
  equal(Aster.dashboard.state().locations, 4, 'dashboard starts from four registered map locations');
  equal(Aster.dashboard.state().gameplayModes, 4, 'dashboard starts from four registered gameplay modes');
  equal(Aster.dashboard.state().routes, 4, 'dashboard starts from four registered destination routes');
  equal(Aster.dashboard.state().orbitEntries, 9, 'dashboard starts from five inner and four outer orbit entries');
  equal(document.querySelectorAll('[data-orbit-ring]').length, 2, 'dashboard renders exactly two independent orbit rings');
  check(Array.from(document.querySelectorAll('[data-orbit-entry]')).every((button) => button.querySelector('.aster-worlddash-satellite-icon')), 'every inner and outer orbit action uses the same satellite icon wrapper');
  Aster.dashboard.setVariable('player.name', '变量旅人');
  equal(document.querySelector('.aster-worlddash-player-meta').querySelector('h2').textContent, '变量旅人', 'dashboard player identity resolves a live variable binding');
  Aster.dashboard.setVariable('player.name', '星轨旅人');
  Aster.dashboard.registerStat('luck-test', { label: '幸运', value: '47', valueBinding: 'player.luck', order: 70 });
  check(document.querySelector('[data-dashboard-stat="luck-test"]'), 'newly registered world stat auto-expands the dashboard model');
  Aster.dashboard.unregisterStat('luck-test');
  const gameplayAssets = {
    equipment: 'io.aster.ui.world-media:world-map',
    craft: 'io.aster.ui.orbit-holo:world-home'
  };
  for (const id of ['home', 'pet', 'equipment', 'craft']) {
    document.querySelector('[data-gameplay-tab="' + id + '"]').click();
    const gameplayStage = document.querySelector('[data-gameplay-stage]');
    equal(gameplayStage.getAttribute('data-gameplay-stage'), id, 'gameplay screen switches to ' + id);
    if (gameplayAssets[id]) {
      equal(gameplayStage.getAttribute('data-aster-resource-value'), gameplayAssets[id], 'gameplay screen stamps the registered asset ID for ' + id);
      check(!gameplayStage.hasAttribute('data-aster-orbit-asset'), 'resource gameplay clears the previous orbit-art stamp for ' + id);
    }
  }
  document.querySelector('[data-gameplay-tab="home"]').click();
  check(document.querySelector('[data-gameplay-stage]').getAttribute('data-aster-orbit-asset') === 'world.home', 'home gameplay restores the semantic orbit-art stamp');
  check(!document.querySelector('[data-gameplay-stage]').hasAttribute('data-aster-resource-value'), 'home gameplay clears stale resource identity before its asset promise settles');
  document.querySelector('[data-map-node="archive"]').click();
  check(document.querySelector('[data-map-popup="archive"]').textContent.includes('书亭档案馆'), 'map node opens its complete registered tether card');
  Aster.dashboard.registerLocation('harbour-test', { label: '银桥港', kicker: '测试地点', summary: '动态点位', meta: '已探索', x: '32%', y: '72%', icon: '◇', order: 35 });
  check(document.querySelector('[data-map-node="harbour-test"]'), 'registered map point becomes a real clickable button without view hardcoding');
  Aster.dashboard.configure({ location: 'harbour-test' });
  Aster.dashboard.unregisterLocation('harbour-test');
  check(Aster.dashboard.state().location !== 'harbour-test' && Aster.dashboardMapPoints.has(Aster.dashboard.state().location), 'deleting the active map point persists a valid fallback in dashboard state');
  Aster.dashboard.registerGameplay('garden-test', { label: '庭院', title: '庭院经营', summary: '动态玩法', resource: 'garden', order: 35 });
  check(document.querySelector('[data-gameplay-tab="garden-test"]'), 'registered gameplay mode auto-expands the gameplay tab rail');
  Aster.dashboard.unregisterGameplay('garden-test');
  let dynamicRouteOpened = false;
  Aster.dashboard.registerRoute('route-test', { label: '动态入口', description: '模组注册', icon: '◇', open: function () { dynamicRouteOpened = true; }, order: 35 });
  check(document.querySelector('[data-orbit-entry="route-test"]'), 'registered destination route auto-expands the outer orbit');
  activateOrbitEntry(env, 'route-test', () => dynamicRouteOpened);
  Aster.dashboard.unregisterRoute('route-test');
  const configuredOuter = Aster.dashboard.configure({ orbits: { outer: { activeId: 'world-bag' } } }).orbits.outer;
  equal(configuredOuter.index, 0, 'activeId configuration preserves a valid zero orbit index');
  equal(mock.stores.global.get('aster.dashboard.orbits.v2').outer.index, 0, 'activeId configuration persists the reconciled zero orbit index');
  const configuredOuterByIndex = Aster.dashboard.configure({ orbits: { outer: { index: 1 } } }).orbits.outer;
  equal(configuredOuterByIndex.activeId, 'world-quest', 'explicit orbit index configuration overrides the previously active ID');
  equal(mock.stores.global.get('aster.dashboard.orbits.v2').outer.activeId, 'world-quest', 'index configuration persists its reconciled active ID');
  const savedBagRoute = Aster.dashboardRoutes.get('world-bag');
  Aster.dashboard.configure({ orbits: { outer: { activeId: 'world-social' } } });
  Aster.dashboard.unregisterRoute('world-bag');
  equal(Aster.dashboard.state().orbits.outer.index, 1, 'deleting an earlier orbit entry reconciles the active ID to its new index');
  equal(mock.stores.global.get('aster.dashboard.orbits.v2').outer.index, 1, 'deleting an orbit entry persists its reconciled index');
  Aster.dashboard.registerRoute('world-bag', savedBagRoute);
  Aster.dashboard.registerRoute('route-replace-test', { label: '待覆盖路由', icon: '◇', open: function () {}, order: 70 });
  Aster.dashboard.registerOrbit('route-replace-test', { ring: 'inner', label: '已改为内轨', iconAssetId: 'ui.orbit.team', action: { type: 'command', target: 'world.team.open' }, order: 70 });
  check(!Aster.dashboardRoutes.has('route-replace-test'), 'overwriting a route as a plain orbit entry removes the stale route facade');
  Aster.dashboard.unregisterOrbit('route-replace-test');
  for (const id of ['world-bag', 'world-quest', 'world-following']) {
    activateOrbitEntry(env, id, () => Aster.overlay.isOpen('panel:' + id));
    Aster.overlay.close('panel:' + id);
  }

  let dragTargetOpened = 0;
  Aster.dashboard.registerRoute('drag-neighbour-test', { label: '拖动前项', description: '拖动测试', icon: '◇', open: function () {}, order: 50 });
  Aster.dashboard.registerRoute('drag-target-test', { label: '拖动目标', description: '拖动测试', icon: '◇', open: function () { dragTargetOpened += 1; }, order: 60 });
  document.querySelector('[data-orbit-entry="drag-neighbour-test"]').click();
  const dragRing = ancestorWithAttribute(document.querySelector('[data-orbit-entry="drag-neighbour-test"]'), 'data-orbit-ring');
  dragRing.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 41, clientX: 280, bubbles: true }));
  dragRing.dispatchEvent(new FakeEvent('pointermove', { pointerId: 41, clientX: 170, bubbles: true }));
  dragRing.dispatchEvent(new FakeEvent('pointerup', { pointerId: 41, clientX: 150, bubbles: true }));
  const dragTarget = document.querySelector('[data-orbit-entry="drag-target-test"]');
  equal(dragTarget.getAttribute('aria-selected'), 'true', 'orbit drag snaps to the next registered satellite before click suppression is checked');
  dragTarget.click();
  equal(dragTargetOpened, 0, 'orbit drag suppresses its browser follow-up click instead of executing the focused route');
  dragTarget.click();
  equal(dragTargetOpened, 1, 'the next intentional orbit click executes after one suppressed drag follow-up');
  dragRing.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 42, clientX: 280, bubbles: true }));
  dragRing.dispatchEvent(new FakeEvent('pointermove', { pointerId: 42, clientX: 170, bubbles: true }));
  dragRing.dispatchEvent(new FakeEvent('pointercancel', { pointerId: 42, clientX: 170, bubbles: true }));
  dragTarget.click();
  equal(dragTargetOpened, 2, 'pointer cancellation clears drag suppression without rotating or swallowing the next click');
  dragRing.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 43, clientX: 280, bubbles: true }));
  dragRing.dispatchEvent(new FakeEvent('pointermove', { pointerId: 43, clientX: 170, bubbles: true }));
  dragRing.dispatchEvent(new FakeEvent('lostpointercapture', { pointerId: 43, clientX: 170, bubbles: true }));
  dragTarget.click();
  equal(dragTargetOpened, 3, 'lost pointer capture clears drag suppression without swallowing the next click');
  Aster.dashboard.unregisterRoute('drag-target-test');
  Aster.dashboard.unregisterRoute('drag-neighbour-test');

  activateOrbitEntry(env, 'world-social', () => Aster.overlay.isOpen('panel:world-social'));
  check(!Aster.overlay.isOpen('dashboard'), 'opening world social closes the dashboard instead of stacking two fullscreen surfaces');
  equal(Aster.overlay.depth(), 1, 'world social is the only fullscreen overlay after the dashboard route executes');
  check(document.querySelector('[data-aster-social-frame="holo-veil-2"]'), 'social application uses the revised Holo Veil shell');
  equal(document.querySelector('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-aster-surface'), 'safe-fullscreen', 'social application uses the host-safe fullscreen surface');
  equal(document.querySelector('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation'), 'messages', 'social root declares the current messages presentation');
  check(!Aster.overlay.current('panel:world-social').panel.querySelector('.aster-app-shell'), 'social application does not nest the generic application shell');
  const socialPortrait = document.querySelector('[data-aster-resource-slot="social.portrait"]');
  check(socialPortrait, 'social rail keeps one empty semantic portrait slot');
  equal(socialPortrait.getAttribute('data-aster-resource-state'), 'builtin', 'social portrait slot uses the non-image base fallback');
  check(socialPortrait.parentNode.classList.contains('aster-standalone-body'), 'portrait slot is a body backdrop sibling instead of a sidebar child that can cover social.main');
  equal(document.querySelector('[data-aster-social-mode="messages"]').getAttribute('aria-current'), 'page', 'active social mode is exposed to assistive technology');
  check(document.querySelector('[data-aster-social-search="messages"]').getAttribute('aria-label'), 'social search has a stable accessible name');
  equal(Aster.socialSections.count(), 3, 'social application owns three default registered sections');
  check(Aster.socialEntries.count() >= 18, 'social content is supplied by a registered entry collection instead of view-local arrays');
  const unreadIds = socialEntryIds(document.querySelectorAll('[data-aster-social-unread]'));
  check(unreadIds.length >= 3, 'message presentation exposes registered unread state on individual entries');
  equal(new Set(unreadIds).size, unreadIds.length, 'each unread state marker belongs to one unique social entry');
  const onlineIds = socialEntryIds(document.querySelectorAll('[data-aster-social-online]'));
  check(onlineIds.length > 0, 'message presentation exposes registered online state');
  equal(new Set(onlineIds).size, onlineIds.length, 'each online state marker belongs to one unique social entry');
  const socialModeBeforeInvalidOpen = Aster.social.state().mode;
  equal(Aster.social.open({ mode: 'missing-social-mode' }), false, 'public social open rejects an unregistered mode');
  equal(Aster.social.open({ mode: 'forum', entryId: 'messages:archive' }), false, 'public social open rejects an entry owned by another section');
  equal(Aster.social.state('missing-social-mode'), null, 'public social state rejects an unregistered inspection mode');
  equal(Aster.social.state().mode, socialModeBeforeInvalidOpen, 'invalid public social requests do not corrupt the active mode');
  document.querySelector('[data-aster-social-mode="forum"]').click();
  equal(Aster.social.state().mode, 'forum', 'social sidebar switches to forum');
  equal(document.querySelector('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation'), 'forum', 'social root updates to the forum presentation');
  const forumInitial = Aster.social.state('forum');
  check(forumInitial.total > 5 && forumInitial.hasMore, 'forum starts with a real paged result set');
  const forumSearch = document.querySelector('[data-aster-social-search="forum"]');
  check(forumSearch, 'forum exposes a dedicated search control');
  check(forumSearch.getAttribute('aria-label'), 'forum search retains an accessible name');
  forumSearch.value = '家园'; forumSearch.dispatchEvent(new FakeEvent('input', { bubbles: true }));
  equal(Aster.social.state('forum').query, '家园', 'forum search writes into section query state');
  check(Aster.social.state('forum').total > 0 && Aster.social.state('forum').total < forumInitial.total, 'forum search filters title, author, summary, board, and tag fields');
  equal(Array.from(document.querySelectorAll('[data-aster-social-item]')).filter((node) => node.getAttribute('data-aster-social-item').startsWith('forum:')).length, Aster.social.state('forum').visible, 'forum list renders only the visible search results');
  document.querySelector('[data-aster-social-search-clear="forum"]').click();
  equal(Aster.social.state('forum').total, forumInitial.total, 'clearing forum search restores all registered rows');
  const forumLoad = document.querySelector('[data-aster-social-load="forum"]');
  check(forumLoad, 'forum exposes load-more pagination when results exceed the registered page size');
  forumLoad.click();
  equal(Aster.social.state('forum').visible, forumInitial.total, 'forum load-more appends the remaining result window');
  const forumBoard = document.querySelector('[data-aster-social-filter="forum:board:guide"]');
  forumBoard.click();
  equal(Aster.social.state('forum').filters.board, 'guide', 'forum section filter is functional');
  equal(document.querySelector('[data-aster-social-filter="forum:board:guide"]').getAttribute('aria-pressed'), 'true', 'active forum filter exposes aria-pressed');
  check(Aster.social.state('forum').total < forumInitial.total, 'forum section filter narrows the result set');
  document.querySelector('[data-aster-social-sort="forum:replies"]').click();
  equal(Aster.social.state('forum').sort, 'replies', 'forum reply-count sort is functional');
  document.querySelector('[data-aster-social-filter="forum:board:all"]').click();
  const sectionBase = { pageSize: 5, searchFields: ['title'], sorts: [{ id: 'latest', label: '最新', field: 'timestamp', direction: 'desc' }], defaultSort: 'latest' };
  Aster.social.registerSection('square-test', Object.assign({}, sectionBase, { label: '广场', title: '世界广场', icon: 'forum', presentation: 'forum', order: 25 }));
  Aster.social.registerSection('archive-test', Object.assign({}, sectionBase, { label: '档案', title: '档案直播', icon: 'archive', presentation: 'live', order: 40 }));
  Aster.social.registerSection('custom-test', Object.assign({}, sectionBase, { label: '自定义', title: '模组频道', icon: 'more', presentation: 'custom', order: 50 }));
  Aster.social.registerEntry('custom-test:welcome', { section: 'custom-test', title: '模组入口', summary: '自定义 presentation 不应冒充直播卡片。', timestamp: 1, order: 10 });
  equal(document.querySelectorAll('[data-aster-social-mode]').length, 5, 'social rail renders at most five direct section controls');
  const socialMore = document.querySelector('[data-aster-social-more]');
  check(socialMore, 'a sixth registered section produces a real More control');
  equal(socialMore.getAttribute('aria-expanded'), 'false', 'collapsed More control exposes aria-expanded=false');
  equal(socialMore.getAttribute('aria-controls'), 'aster-social-overflow-modes', 'More identifies the overflow group it controls');
  socialMore.click();
  equal(document.querySelector('[data-aster-social-more]').getAttribute('aria-expanded'), 'true', 'expanded More control exposes aria-expanded=true');
  const customMode = document.querySelector('[data-aster-social-mode="custom-test"]');
  check(customMode, 'More expands the previously hidden registered section');
  equal(customMode.getAttribute('data-aster-social-overflow'), 'true', 'expanded overflow route is explicitly marked');
  document.querySelector('[data-aster-social-mode="square-test"]').click();
  check(!document.querySelector('.aster-social-modules'), 'registered forum presentation does not inherit default-forum hardcoded modules');
  document.querySelector('[data-aster-social-mode="archive-test"]').click();
  check(!document.querySelector('.aster-social-upcoming'), 'registered live presentation does not inherit default-live hardcoded upcoming content');
  customMode.click();
  equal(document.querySelector('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation'), 'custom', 'custom section drives its declared root presentation');
  check(document.querySelector('[data-social-index="custom-test"]'), 'custom section retains its own data index instead of being hardcoded to a built-in route');
  equal(document.querySelector('[data-aster-social-item="custom-test:welcome"]').getAttribute('data-social-presentation'), 'custom', 'custom section cards inherit the section presentation');
  check(!document.querySelector('.aster-social-upcoming'), 'custom presentation does not fall through to live-only upcoming content');
  equal(document.querySelector('[data-aster-social-mode="custom-test"]').getAttribute('aria-current'), 'page', 'expanded active mode keeps programmatic current state');
  check(Aster.social.unregisterSection('custom-test'), 'removing the active dynamic section succeeds while other sections remain');
  equal(Aster.social.state().mode, 'messages', 'removing the active dynamic section falls back to the first valid section');
  Aster.social.unregisterEntry('custom-test:welcome');
  for (const id of ['archive-test', 'square-test']) Aster.social.unregisterSection(id);
  check(!document.querySelector('[data-aster-social-more]'), 'removing overflow sections removes the More control');
  document.querySelector('[data-aster-social-mode="live"]').click();
  equal(Aster.social.state().mode, 'live', 'social sidebar switches to live chat');
  equal(document.querySelector('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation'), 'live', 'social root updates to the live presentation');
  document.querySelector('[data-aster-social-mode="messages"]').click();
  document.querySelector('[data-aster-social-item="messages:archive"]').click();
  equal(Aster.social.state().surface, 'detail', 'message row replaces social.main with its detail state');
  equal(document.querySelector('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation'), 'messages', 'same-root detail preserves its source presentation');
  check(!Aster.panels.has('world-social-thread') && !Aster.overlay.isOpen('panel:world-social-thread'), 'social detail never creates the retired thread overlay');
  check(document.querySelector('[data-social-detail="messages:archive"]'), 'message detail remains inside the single Holo Veil root');
  const socialSend = document.querySelector('[data-aster-social-send="messages"]');
  const socialInput = socialSend.parentNode.querySelector('input');
  equal(socialInput.getAttribute('aria-label'), '输入消息', 'same-root composer has a stable accessible name');
  socialInput.value = '详情同面测试回复';
  socialSend.click();
  equal(Aster.social.state().sent, 1, 'same-root detail composer appends a message in session');
  document.querySelector('[data-aster-social-back="messages"]').click();
  equal(Aster.social.state().surface, 'index', 'detail back restores the source mode index in the same root');
  Aster.overlay.close('panel:world-social');
  Aster.dashboard.open();
  Aster.social.open({ mode: 'messages' });
  check(!Aster.overlay.isOpen('dashboard') && Aster.overlay.isOpen('panel:world-social'), 'public Aster.social.open replaces an open dashboard');
  Aster.overlay.close('panel:world-social');
  Aster.dashboard.open();
  Aster.social.openThread('messages', Aster.socialEntries.get('messages:archive'), 0);
  check(!Aster.overlay.isOpen('dashboard') && Aster.social.state().surface === 'detail', 'legacy openThread validates ownership and replaces an open dashboard');
  Aster.overlay.close('panel:world-social');
  Aster.dashboard.open();
  Aster.panels.open('world-social');
  check(!Aster.overlay.isOpen('dashboard') && Aster.overlay.isOpen('panel:world-social'), 'direct world-social panel rendering also closes the dashboard');
  Aster.overlay.close('panel:world-social');
  const savedDefaultSections = Aster.socialSections.list().map((row) => Object.assign({}, row));
  check(Aster.social.unregisterSection('forum') && Aster.social.unregisterSection('live'), 'default sections can be removed while a valid fallback remains');
  equal(Aster.social.unregisterSection('messages'), false, 'public API refuses to remove the last social section');
  savedDefaultSections.filter((row) => row.id !== 'messages').forEach((row) => Aster.social.registerSection(row.id, row));
  Aster.socialSections.clear();
  Aster.panels.open('world-social');
  equal(Aster.social.state().sections, 0, 'empty raw registry renders a safe zero-section state instead of dereferencing undefined');
  equal(document.querySelector('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation'), 'custom', 'zero-section state uses the generic presentation fallback');
  Aster.overlay.close('panel:world-social');
  savedDefaultSections.forEach((row) => Aster.social.registerSection(row.id, row));
  equal(Aster.socialSections.count(), 3, 'default social section registry is restored after the zero-section safety probe');
  check(!document.querySelector('[data-aster-dashboard-phone="open"]'), 'dashboard contains no phone transition');
  check(!document.querySelector('[data-aster-reset-positions="true"]'), 'dashboard contains no settings control');
  closeAll(env);

  Aster.panels.open('catalog');
  const catalogIds = Aster.catalog.list().map((item) => item.id);
  closeAll(env);
  for (const id of catalogIds) {
    Aster.panels.open('catalog');
    const row = document.querySelector('[data-aster-catalog="' + id + '"]');
    check(row, 'catalog row is rendered as a control: ' + id);
    row.click();
    check(Aster.overlay.top() !== 'panel:catalog', 'catalog row opens real destination: ' + id);
    closeAll(env);
  }

  Aster.panels.open('parameters');
  const compact = document.querySelector('[data-aster-field="ui.compact"]');
  check(compact, 'schema parser renders switch parameter');
  compact.checked = true;
  compact.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  equal(mock.stores.global.get('aster.param.ui.compact'), true, 'switch persists in global scope');
  Aster.overlay.close('panel:parameters');
  Aster.panels.open('parameters');
  equal(document.querySelector('[data-aster-field="ui.compact"]').checked, true, 'switch restores after reopen');
  const density = document.querySelector('[data-aster-field="ui.density"]');
  density.value = '1.15';
  density.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  equal(mock.stores.global.get('aster.param.ui.density'), 1.15, 'density change persists normalized value');
  equal(density.getAttribute('data-aster-persisted'), 'true', 'density reports successful write/readback');
  equal(document.querySelector('[data-aster-output="ui.density"]').textContent, '1.15×', 'density readback updates visible output');
  equal(document.documentElement.style['--aster-density'], '1.15', 'density immediately updates CSS token');
  const worldLabel = document.querySelector('[data-aster-field="world.label"]');
  worldLabel.value = '浮动小镇';
  worldLabel.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  equal(mock.stores.chat.get('aster.param.world.label'), '浮动小镇', 'text parameter persists in chat scope');
  Aster.overlay.close('panel:parameters');
  Aster.panels.open('forms');
  equal(document.querySelector('[data-aster-field="world.label"]').value, '浮动小镇', 'form lab reads shared parameter value');
  check(document.querySelector('[data-aster-field="probe.number"]'), 'form registry renders number control');
  check(document.querySelector('[data-aster-field="probe.notes"]'), 'form registry renders textarea control');
  const formProbe = document.querySelector('[data-aster-action="form-probe"]');
  const toastCount = mock.toasts.length;
  formProbe.click();
  equal(mock.toasts.length, toastCount + 1, 'schema action invokes registered callback');
  closeAll(env);

  Aster.apps.open('theme');
  const themeLayer = Aster.overlay.current('panel:theme');
  check(themeLayer, 'Theme opens as independent application panel');
  check(document.querySelector('.aster-app-shell'), 'Theme consumes shared application shell');
  check(!document.querySelector('[data-aster-field="interaction.drag.threshold"]'), 'Theme does not absorb interaction settings');
  check(!document.querySelector('[data-aster-field="feedback.sound.volume"]'), 'Theme does not absorb sound settings');
  equal(Aster.preferenceSlots.count(), document.querySelectorAll('[data-aster-preference-select]').length, 'Theme renders every registered semantic slot');
  equal(themeLayer.header, null, 'Theme panel omits the generic outer overlay header entirely');
  check(themeLayer.root.classList.contains('is-chromeless'), 'Theme uses the registered chromeless application layout');
  check(!themeLayer.panel.querySelector('.aster-overlay-header'), 'chromeless application has no nested outer shell');
  check(document.querySelector('[data-aster-app-close="theme"]'), 'Theme owns one functional in-app close control');
  equal(document.querySelector('.aster-overlay-body').getAttribute('data-aster-preference-slot'), 'inner.body', 'inner overlay body is bound to semantic body slot');
  equal(document.querySelectorAll('[data-aster-font-card]').length, 5, 'Theme exposes five visibly distinct built-in font profiles');
  document.querySelector('[data-aster-font-card="kaiti"]').click();
  equal(mock.stores.global.get('aster.param.theme.fontFamily'), 'kaiti', 'font profile card persists the selected family');
  equal(document.documentElement.getAttribute('data-aster-font-profile'), 'kaiti', 'font profile is applied as a global semantic token');
  await waitFor(() => Aster.theme.fontState('kaiti') === 'ready', 'lazy local font ready');
  check(mock.files.global.some((row) => row.name === 'LXGWWenKaiLite-Regular.ttf'), 'first font use saves the remote asset into Tavo global files');
  check(Aster.assets.index('global').some((row) => row.assetId === 'font.lxgw-wenkai'), 'font localization is recorded in the persistent resource index');
  check(document.getElementById('aster-style-skin-local-font-lxgw-wenkai'), 'Skin registers a local-URL font face after localization');
  document.querySelector('[data-aster-preference-select="inner.button"]').click();
  const buttonFont = document.querySelector('[data-aster-field="skin.slot.inner.button.fontFamily"]');
  check(buttonFont, 'button slot form is generated from registry schema');
  buttonFont.value = 'mono';
  buttonFont.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  equal(mock.stores.global.get('aster.param.skin.slot.inner.button.fontFamily'), 'mono', 'semantic button font persists through parameter registry');
  equal(Aster.skinPreferences.explain('inner.button').fontFamily.value, 'mono', 'semantic preference readback resolves persisted override');
  const crimson = document.querySelector('[data-aster-theme-card="ink-crimson"]');
  crimson.click();
  equal(mock.stores.global.get('aster.param.theme.active'), 'ink-crimson', 'theme selection persists active theme');
  equal(mock.stores.global.get('aster.param.theme.accent'), '#ff8d9d', 'theme selection persists matching accent');
  equal(document.documentElement.getAttribute('data-aster-theme'), 'ink-crimson', 'theme selection applies globally');
  equal(Aster.overlay.current('panel:theme').root, themeLayer.root, 'Theme refresh retains singleton root');
  const themeDensity = document.querySelector('[data-aster-field="ui.density"]');
  equal(themeDensity.value, '1.15', 'Theme reads density saved in parameter center');
  themeDensity.value = '0.9';
  themeDensity.dispatchEvent(new FakeEvent('pointerup', { bubbles: true }));
  equal(mock.stores.global.get('aster.param.ui.density'), 0.9, 'Theme density pointer release persists');
  Aster.overlay.close('panel:theme');
  Aster.apps.open('theme');
  document.querySelector('[data-aster-preference-select="inner.button"]').click();
  equal(document.querySelector('[data-aster-field="skin.slot.inner.button.fontFamily"]').value, 'mono', 'semantic slot survives close and reopen');
  equal(document.querySelector('[data-aster-field="ui.density"]').value, '0.9', 'Theme density survives close and reopen');
  equal(Aster.overlay.depth(), 1, 'Theme remains singleton');
  closeAll(env);

  Aster.apps.open('data-manager');
  equal(Object.values(Aster.dataManager.capabilities()).filter(Boolean).length, 5, 'Data Manager sees all four data APIs and the file API');
  equal(Aster.tabs.forApp('data-manager').length, 2, 'Data Manager owns exactly two registered workbench tabs');
  check(document.querySelector('[data-aster-tab="data"]') && document.querySelector('[data-aster-tab="resource"]'), 'Data and Resource are the only visible Data Manager tabs');
  check(!document.querySelector('[data-aster-tab="general"]') && !document.querySelector('[data-aster-tab="module"]'), 'general settings and Mod management are absent from Data Manager');
  check(!document.querySelector('[data-aster-manager-import]') && !document.querySelector('[data-aster-settings-import]'), 'Data Manager contains no package import route');
  await waitFor(() => document.querySelectorAll('[data-aster-manager-row]').length >= 8, 'Data Manager data rows');
  check(document.querySelector('[data-aster-manager-row="regex:' + mock.regexes[0].id + '"]'), 'data workbench lists regex groups');
  check(document.querySelector('[data-aster-manager-row="character:' + mock.characters[0].id + '"]'), 'data workbench lists character cards');
  check(document.querySelector('[data-aster-manager-row="preset:' + mock.presets[0].id + '"]'), 'data workbench lists presets');
  check(document.querySelector('[data-aster-manager-row="lorebook:1"]'), 'data workbench lists world books');
  const dataSearch = document.querySelector('[data-aster-manager-search="data"]');
  dataSearch.value = 'Aster UI probe';
  dataSearch.dispatchEvent(new FakeEvent('input', { bubbles: true }));
  equal(document.querySelectorAll('[data-aster-manager-row]').length, 1, 'Core collection query filters all data adapters uniformly');
  dataSearch.value = '';
  dataSearch.dispatchEvent(new FakeEvent('input', { bubbles: true }));

  const regexId = mock.regexes[0].id;
  document.querySelector('[data-aster-manager-edit="regex:' + regexId + '"]').click();
  await waitFor(() => document.querySelector('[data-aster-record-save="regex"]'), 'visual regex editor');
  check(Aster.overlay.isOpen('panel:data-record-editor'), 'data edit opens an independent registered workbench panel');
  equal(Aster.overlay.top(), 'panel:data-record-editor', 'independent workbench is visible above the data list');
  check(document.querySelector('[data-aster-standalone="data-record-editor"][data-aster-workbench-mode="record-editor"]'), 'data editor mounts the dedicated safe-area fullscreen workbench');
  check(document.querySelector('[data-aster-editor-toolbar="regex"]') && document.querySelector('[data-aster-entry-duplicate="regex"]'), 'data editor exposes the compact functional object toolbar');
  check(String(Aster.panels.get('data-record-editor').width).includes('100vw'), 'data editor panel width is viewport-responsive instead of the old narrow card');
  check(document.querySelector('[data-aster-field="regex.name"]') && document.querySelector('[data-aster-field="regex.0.find"]'), 'regex editor exposes record and entry field forms instead of raw JSON');
  equal(document.querySelector('[data-aster-field="regex.0.find"]').parentNode.getAttribute('data-aster-field-row'), 'find', 'data editor annotates schema rows for Skin-only responsive layout');
  check(!document.querySelector('[data-aster-settings-editor]'), 'legacy whole-object JSON editor is absent');
  const regexName = document.querySelector('[data-aster-field="regex.name"]');
  regexName.value = 'Aster UI probe edited'; regexName.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  const regexFind = document.querySelector('[data-aster-field="regex.0.find"]');
  regexFind.value = 'edited-pattern'; regexFind.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  const regexCheck = document.querySelector('[data-aster-entry-check="0"]'); regexCheck.checked = true; regexCheck.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  const batchTags = Array.from(document.querySelectorAll('input')).find((node) => node.getAttribute('placeholder') === '标签（逗号分隔）');
  batchTags.value = 'batch-probe'; findByText(document.querySelectorAll('.aster-button'), '加标签').click();
  document.querySelector('[data-aster-record-save="regex"]').click();
  await waitFor(() => mock.regexes[0].name === 'Aster UI probe edited' && mock.regexes[0].entries[0].find === 'edited-pattern', 'regex visual form update and readback');
  check(mock.regexes[0].entries[0].tags.includes('batch-probe'), 'batch tag action is composed from the Core tool registry');
  await waitFor(() => !Aster.overlay.isOpen('panel:data-record-editor'), 'visual editor closes after verified readback');
  await waitFor(() => document.querySelector('[data-aster-manager-export="regex:' + regexId + '"]'), 'Data Manager restores remembered data tab');
  document.querySelector('[data-aster-manager-export="regex:' + regexId + '"]').click();
  await waitFor(() => mock.exports.length > 0, 'data export uses the shared record export tool');

  document.querySelector('[data-aster-manager-edit="character:' + mock.characters[0].id + '"]').click();
  await waitFor(() => document.querySelector('[data-aster-field="character.description"]'), 'character visual editor');
  const characterDescription = document.querySelector('[data-aster-field="character.description"]');
  characterDescription.value = 'Aster character edited'; characterDescription.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  document.querySelector('[data-aster-record-save="character"]').click();
  await waitFor(() => mock.characters[0].description === 'Aster character edited', 'character fields save and read back');
  await waitFor(() => !Aster.overlay.isOpen('panel:data-record-editor'), 'character editor closes');

  await waitFor(() => document.querySelector('[data-aster-manager-edit="preset:' + mock.presets[0].id + '"]'), 'preset row restored');
  document.querySelector('[data-aster-manager-edit="preset:' + mock.presets[0].id + '"]').click();
  await waitFor(() => document.querySelector('[data-aster-field="preset.0.content"]'), 'preset visual editor');
  const presetContent = document.querySelector('[data-aster-field="preset.0.content"]');
  presetContent.value = 'Aster preset edited'; presetContent.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  document.querySelector('[data-aster-record-save="preset"]').click();
  await waitFor(() => mock.presets[0].entries[0].content === 'Aster preset edited', 'preset entries save and read back');
  await waitFor(() => !Aster.overlay.isOpen('panel:data-record-editor'), 'preset editor closes');

  const dataKind = document.querySelector('[data-aster-manager-kind="data"]');
  dataKind.value = 'lorebook'; dataKind.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  await waitFor(() => document.querySelector('[data-aster-manager-create="data"]'), 'lorebook workbench filter');
  document.querySelector('[data-aster-manager-create="data"]').click();
  await waitFor(() => document.querySelector('[data-aster-field="lorebook.name"]'), 'new lorebook visual editor');
  const lorebookName = document.querySelector('[data-aster-field="lorebook.name"]');
  lorebookName.value = 'Workbench lorebook probe'; lorebookName.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  document.querySelector('[data-aster-entry-create="lorebook"]').click();
  await waitFor(() => document.querySelector('[data-aster-field="lorebook.0.content"]'), 'new lorebook entry form');
  const loreEntryName = document.querySelector('[data-aster-field="lorebook.0.name"]');
  loreEntryName.value = 'Probe entry'; loreEntryName.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  const loreEntryContent = document.querySelector('[data-aster-field="lorebook.0.content"]');
  loreEntryContent.value = 'Probe content'; loreEntryContent.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  document.querySelector('[data-aster-record-save="lorebook"]').click();
  await waitFor(() => mock.books.some((row) => row.name === 'Workbench lorebook probe'), 'new lorebook and entry save with verified readback');
  const probeBook = mock.books.find((row) => row.name === 'Workbench lorebook probe');
  await waitFor(() => document.querySelector('[data-aster-manager-delete="lorebook:' + probeBook.id + '"]'), 'created lorebook row');
  const removeBook = document.querySelector('[data-aster-manager-delete="lorebook:' + probeBook.id + '"]');
  removeBook.click(); equal(removeBook.getAttribute('data-confirm'), 'true', 'data deletion requires explicit second confirmation'); removeBook.click();
  await waitFor(() => !mock.books.some((row) => row.id === probeBook.id), 'shared record delete removes the selected lorebook');

  document.querySelector('[data-aster-tab="resource"]').click();
  await waitFor(() => document.querySelector('[data-aster-manager-row="files/chat/aster-notes.json"]'), 'resource workbench rows');
  check(document.querySelector('[data-aster-resource-reconcile="true"]'), 'resource tab exposes explicit local-state reconciliation');
  check(document.querySelector('[data-aster-resource-ledger="true"]'), 'resource tab exposes one-click fixed resource-book sync');
  check(document.querySelector('[data-aster-resource-export-index="true"]'), 'resource tab exposes reverse manifest export');
  check(document.querySelector('[data-aster-resource-source="true"]'), 'resource workbench exposes source filtering');
  check(document.querySelector('[data-aster-resource-deduplicate="true"]'), 'resource tab exposes safe content-hash deduplication');
  equal(document.querySelectorAll('.aster-resource-stat').length, 3, 'resource table renders the three compact P4 summary cards');
  check(document.querySelector('.aster-resource-table-head') && document.querySelector('.aster-resource-row-main'), 'resource tab uses the compact table contract instead of giant action cards');
  check(document.querySelector('[data-aster-resource-trash-open="true"]'), 'resource workbench exposes the verified recycle bin');
  const resourceRowBeforeExpand = document.querySelector('[data-aster-resource-row="files/chat/aster-notes.json"]');
  const managerScroll = document.querySelector('.aster-app-body'); managerScroll.scrollTop = 137;
  resourceRowBeforeExpand.querySelector('.aster-resource-menu').click();
  equal(document.querySelector('[data-aster-resource-row="files/chat/aster-notes.json"]'), resourceRowBeforeExpand, 'resource more toggles the existing row instead of rebuilding the whole list');
  equal(managerScroll.scrollTop, 137, 'resource more preserves the manager internal scroll position');
  equal(resourceRowBeforeExpand.querySelector('.aster-resource-detail').getAttribute('aria-hidden'), 'false', 'resource more opens inline actions in place');
  check(!document.querySelector('[data-aster-manager-import]'), 'resource workbench also contains no importer');
  document.querySelector('[data-aster-manager-edit="files/chat/aster-notes.json"]').click();
  await waitFor(() => document.querySelector('[data-aster-resource-text="files/chat/aster-notes.json"]'), 'text resource preview editor');
  document.querySelector('[data-aster-resource-text="files/chat/aster-notes.json"]').value = '{"ready":"edited"}';
  const resourceFilename = document.querySelector('[data-aster-field="resource.storedName"]');
  resourceFilename.value = 'aster-notes-renamed.json'; resourceFilename.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  document.querySelector('[data-aster-resource-save="files/chat/aster-notes.json"]').click();
  await waitFor(() => mock.files.chat.some((row) => row.path === 'files/chat/aster-notes-renamed.json' && row.content === '{"ready":"edited"}'), 'resource rename copies bytes, deletes the old file, and writes edited text through official file APIs');
  check(!mock.files.chat.some((row) => row.path === 'files/chat/aster-notes.json'), 'resource rename leaves no stale original file');
  check(Aster.assets.mutationManifest('chat').renames.some((row) => row.fromName === 'aster-notes.json' && row.toName === 'aster-notes-renamed.json'), 'verified rename persists in the resource mutation manifest');
  await waitFor(() => document.querySelector('[data-aster-manager-export="files/chat/aster-notes-renamed.json"]'), 'resource workbench restores the renamed row after editor save');
  document.querySelector('[data-aster-resource-copy-url="files/chat/aster-notes-renamed.json"]').click();
  await waitFor(() => document.querySelector('[data-aster-export-text="aster-notes-renamed.json"]'), 'copy URL falls back to an independent copy panel when Clipboard API is unavailable');
  check(document.querySelector('[data-aster-export-text="aster-notes-renamed.json"]').value.includes('mock://file/'), 'copy URL resolves the Tavo-local resource URL');
  Aster.overlay.close('panel:data-export');
  document.querySelector('[data-aster-manager-export="files/chat/aster-notes-renamed.json"]').click();
  await waitFor(() => mock.exports.some((row) => row.path === 'files/chat/aster-notes-renamed.json'), 'resource export uses native file export');
  await Aster.assets.syncResourceBook();
  const ledgerWritesBeforeTrash = mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length;
  const resourceDelete = document.querySelector('[data-aster-manager-delete="files/chat/aster-notes-renamed.json"]');
  resourceDelete.click(); resourceDelete.click();
  await waitFor(() => !mock.files.chat.some((row) => row.path === 'files/chat/aster-notes-renamed.json'), 'resource trash removes the original local path');
  await waitFor(() => !Aster.assets.index('chat').some((row) => row.path === 'files/chat/aster-notes-renamed.json'), 'resource trash removes the active metadata row');
  equal(Aster.assets.trash.count('chat'), 1, 'resource trash persists one recoverable manifest item');
  check(mock.files.chat.some((row) => /^aster-trash-/.test(row.name)), 'resource trash keeps a verified hidden physical copy');
  check(!Aster.assets.mutationManifest('chat').deletions.some((row) => row.storedName === 'aster-notes-renamed.json'), 'recoverable trash is not falsely recorded as permanent deletion');
  await waitFor(() => document.querySelector('[data-aster-resource-trash-open="true"]'), 'resource manager returns after moving the item');
  equal(mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length - ledgerWritesBeforeTrash, 1, 'resource trash performs exactly one resource-book write');
  const indexWritesAfterTrash = mock.writes.filter((row) => row.op === 'set' && row.key === 'aster.resource.index.v1').length;
  const ledgerWritesAfterTrash = mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length;
  await Aster.assets.list('chat'); await Aster.assets.list('chat');
  const noOpSyncA = await Aster.assets.syncResourceBook(); const noOpSyncB = await Aster.assets.syncResourceBook();
  equal(noOpSyncA.changed, false, 'unchanged resource-book sync reports a no-op'); equal(noOpSyncB.changed, false, 'queued unchanged sync also reports a no-op');
  equal(mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length, ledgerWritesAfterTrash, 'unrelated resource reads and no-op syncs never retrigger Tavo resource-book modified notices');
  equal(mock.writes.filter((row) => row.op === 'set' && row.key === 'aster.resource.index.v1').length, indexWritesAfterTrash, 'unchanged reconciliation does not rewrite the resource index');
  Aster.assets.register('fixture.runtime-probe', {
    name: 'runtime-probe.txt', storedName: 'runtime-probe.txt', scope: 'global', kind: 'text',
    mime: 'text/plain', source: 'runtime-probe-content'
  });
  await Aster.assets.ensure('fixture.runtime-probe');
  await Aster.assets.syncResourceBook();
  const writesBeforeRenderEnsure = mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length;
  await Aster.assets.ensure('fixture.runtime-probe'); await Aster.assets.ensure('fixture.runtime-probe');
  await Promise.resolve(); await Promise.resolve();
  equal(mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length, writesBeforeRenderEnsure, 'render-time asset checks never write the resource lorebook');
  document.querySelector('[data-aster-resource-trash-open="true"]').click();
  await waitFor(() => document.querySelector('[data-aster-trash-restore]'), 'recycle bin lists the recoverable resource');
  document.querySelector('[data-aster-trash-restore]').click();
  await waitFor(() => mock.files.chat.some((row) => row.path === 'files/chat/aster-notes-renamed.json'), 'recycle bin restore writes back the original resource');
  equal(Aster.assets.trash.count('chat'), 0, 'restored resource is removed from active trash without resurrection');
  document.querySelector('[data-aster-standalone-close="resource-trash"]').click();
  await waitFor(() => document.querySelector('[data-aster-manager-delete="files/chat/aster-notes-renamed.json"]'), 'resource manager refreshes after closing recycle bin');
  const resourceDeleteAgain = document.querySelector('[data-aster-manager-delete="files/chat/aster-notes-renamed.json"]'); resourceDeleteAgain.click(); resourceDeleteAgain.click();
  await waitFor(() => Aster.assets.trash.count('chat') === 1, 'restored resource can be moved to trash again');
  document.querySelector('[data-aster-resource-trash-open="true"]').click();
  await waitFor(() => document.querySelector('[data-aster-trash-purge]'), 'recycle bin exposes permanent deletion');
  const purgeTrash = document.querySelector('[data-aster-trash-purge]'); purgeTrash.click(); equal(purgeTrash.getAttribute('data-confirm'), 'true', 'permanent deletion requires a second confirmation'); purgeTrash.click();
  await waitFor(() => Aster.assets.trash.count('chat') === 0, 'permanent deletion resolves the recycle record');
  check(!mock.files.chat.some((row) => /^aster-trash-/.test(row.name)), 'permanent deletion removes the hidden physical copy');
  check(Aster.assets.mutationManifest('chat').deletions.some((row) => row.storedName === 'aster-notes-renamed.json'), 'permanent deletion persists in the mutation manifest');
  document.querySelector('[data-aster-standalone-close="resource-trash"]').click();
  await waitFor(() => document.querySelector('[data-aster-resource-reconcile="true"]'), 'resource manager refreshes after recycle purge');
  await Aster.assets.saveText('batch-a.txt', 'a', { scope: 'chat', source: 'first-gate' });
  await Aster.assets.saveText('batch-b.txt', 'b', { scope: 'chat', source: 'first-gate' });
  document.querySelector('[data-aster-resource-reconcile="true"]').click();
  await waitFor(() => document.querySelector('[data-aster-resource-select="files/chat/batch-a.txt"]') && document.querySelector('[data-aster-resource-select="files/chat/batch-b.txt"]'), 'resource workbench discovers batch-delete fixtures');
  const batchA = document.querySelector('[data-aster-resource-select="files/chat/batch-a.txt"]');
  const batchB = document.querySelector('[data-aster-resource-select="files/chat/batch-b.txt"]');
  batchA.checked = true; batchA.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  batchB.checked = true; batchB.dispatchEvent(new FakeEvent('change', { bubbles: true }));
  const batchDelete = document.querySelector('[data-aster-resource-batch-delete="true"]');
  batchDelete.click(); equal(batchDelete.getAttribute('data-confirm'), 'true', 'shared batch delete requires explicit second confirmation'); batchDelete.click();
  await waitFor(() => !mock.files.chat.some((row) => /^files\/chat\/batch-[ab]\.txt$/.test(row.path)), 'shared batch-delete tool moves every selected original file to trash');
  check(!Aster.assets.index('chat').some((row) => /^files\/chat\/batch-[ab]\.txt$/.test(row.path)), 'shared batch-delete tool removes both active metadata rows');
  equal(Aster.assets.trash.count('chat'), 2, 'batch delete composes the same recoverable trash adapter for both resources');
  const duplicatePrimary = await Aster.assets.saveText('localized-primary.txt', 'QUJDRA==', { scope: 'chat', assetId: 'fixture.localized.primary', source: 'localization' });
  const duplicateAlias = await Aster.assets.saveText('localized-copy.txt', 'QUJDRA==', { scope: 'chat', assetId: 'fixture.localized.copy', source: 'localization' });
  equal(duplicateAlias.path, duplicatePrimary.path, 'content-identical managed localization reuses its verified canonical file');
  check(!mock.files.chat.some((row) => row.path === 'files/chat/localized-copy.txt'), 'automatic deduplication removes the redundant physical file');
  check(Aster.assets.mutationManifest('chat').aliases.some((row) => row.fromName === 'localized-copy.txt' && row.toName === 'localized-primary.txt'), 'deduplication alias is persisted for future rescans');
  await Aster.assets.saveText('new-resource.txt', 'hello', { scope: 'chat', source: 'first-gate' });
  document.querySelector('[data-aster-resource-reconcile="true"]').click();
  await waitFor(() => Aster.assets.index('chat').some((row) => row.path === 'files/chat/new-resource.txt' && row.localState === 'ready'), 'localized text resource is discovered without a Data Manager import route');
  const importedAt = mock.files.chat.findIndex((row) => row.path === 'files/chat/new-resource.txt');
  mock.files.chat.splice(importedAt, 1);
  document.querySelector('[data-aster-resource-reconcile="true"]').click();
  await waitFor(() => Aster.assets.index('chat').some((row) => row.path === 'files/chat/new-resource.txt' && row.localState === 'missing'), 'external cache deletion is detected by resource rescan');
  const rawIndex = mock.stores.chat.get('aster.resource.index.v1').slice();
  rawIndex.push({ spec: 'aster.resource/v1', assetId: 'broken-empty', name: '', storedName: '', path: '', scope: 'chat' });
  rawIndex.push({ spec: 'aster.resource/v1', assetId: 'broken-duplicate', name: 'Duplicate A', storedName: 'duplicate.bin', path: 'files/chat/duplicate.bin', scope: 'chat' });
  rawIndex.push({ spec: 'aster.resource/v1', assetId: 'broken-duplicate', name: 'Duplicate B', storedName: 'duplicate.bin', path: 'files/chat/duplicate.bin', scope: 'chat' });
  mock.stores.chat.set('aster.resource.index.v1', rawIndex);
  const ledgerReport = await Aster.assets.syncResourceBook();
  check(ledgerReport.diagnostics.repairedEmptyNames >= 1, 'resource-book sync repairs empty resource names');
  check(ledgerReport.diagnostics.repairedDuplicates >= 1, 'resource-book sync consolidates duplicate resource rows');
  const fixedBooks = mock.books.filter((row) => row.name === 'Aster·资源书');
  equal(fixedBooks.length, 1, 'resource sync updates one exact-name fixed book instead of creating duplicates');
  const fixedEntries = fixedBooks[0].entries.filter((entry) => String(entry.identifier || '').startsWith('aster-resource:'));
  equal(new Set(fixedEntries.map((entry) => entry.identifier)).size, fixedEntries.length, 'resource book contains no duplicate resource entry identifiers');
  check(fixedEntries.every((entry) => /^\[(?:图片|音频|视频|字体|文本|文件)\] \S/.test(entry.name)), 'resource book repairs names and labels entries by actual resource type');
  check(!fixedEntries.some((entry) => /\.(?:zip|tpg|thm)$/i.test(entry.name) || /readme/i.test(entry.name)), 'source packages and package documentation do not pollute the resource book');
  closeAll(env);

  Aster.panels.open('diagnostics');
  const selftestButton = document.querySelector('[data-aster-selftest="run"]');
  check(selftestButton, 'diagnostic self-test button exists');
  selftestButton.click();
  check(document.querySelector('.aster-log').textContent.includes('✓ shell connection'), 'diagnostic writes pass report');
  const diagnosticClose = document.querySelector('[data-aster-close="panel:diagnostics"]');
  diagnosticClose.click();
  check(!Aster.overlay.isOpen('panel:diagnostics'), 'overlay close button closes panel');

  const writesBeforePanelOpen = mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length;
  const phone = window.__asterShell.hosts.phone.button;
  phone.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 7, clientX: 350, clientY: 90, bubbles: true }));
  phone.dispatchEvent(new FakeEvent('pointermove', { pointerId: 7, clientX: -100, clientY: 1200, bubbles: true }));
  phone.dispatchEvent(new FakeEvent('pointerup', { pointerId: 7, clientX: -100, clientY: 1200, bubbles: true }));
  const saved = mock.stores.global.get('aster.ui.positions');
  check(saved && saved.phone, 'drag persists phone position');
  check(saved.phone.x >= 8 && saved.phone.y <= 844 - 58 - 8, 'dragged phone position is clamped');
  phone.click();
  check(!Aster.overlay.isOpen('phone'), 'drag suppresses accidental phone click');
  phone.click();
  check(Aster.overlay.isOpen('phone'), 'next deliberate phone click opens');
  closeAll(env);
  const dashboardButton = window.__asterShell.hosts.dashboard.button;
  dashboardButton.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 8, clientX: 350, clientY: 700, bubbles: true }));
  dashboardButton.dispatchEvent(new FakeEvent('pointermove', { pointerId: 8, clientX: 150, clientY: 500, bubbles: true }));
  dashboardButton.dispatchEvent(new FakeEvent('pointerup', { pointerId: 8, clientX: 150, clientY: 500, bubbles: true }));
  check(mock.stores.global.get('aster.ui.positions').dashboard, 'drag persists dashboard position');
  dashboardButton.click();
  check(!Aster.overlay.isOpen('dashboard'), 'dashboard drag suppresses accidental click');
  dashboardButton.click();
  check(Aster.overlay.isOpen('dashboard'), 'next deliberate dashboard click opens');
  closeAll(env);
  await Promise.resolve(); await Promise.resolve();
  equal(mock.writes.filter((row) => row.op === 'lorebook.update' && row.name === 'Aster·资源书').length, writesBeforePanelOpen, 'opening the phone and dashboard never writes the resource lorebook');
  Aster.panels.open('parameters');
  const resetPositions = document.querySelector('[data-aster-action="reset-ui-positions"]');
  check(resetPositions, 'position reset lives in the developer parameter center');
  resetPositions.click();
  check(!mock.stores.global.has('aster.ui.positions'), 'position reset removes persisted coordinates');
  const resetParameters = document.querySelector('[data-aster-action="reset-parameters"]');
  check(resetParameters, 'parameter center exposes reset control');
  resetParameters.click();
  equal(mock.stores.global.has('aster.param.ui.compact'), false, 'parameter reset clears global value');
  equal(mock.stores.chat.has('aster.param.world.label'), false, 'parameter reset clears chat value');
  equal(document.querySelector('[data-aster-field="world.label"]').value, '未命名世界', 'parameter reset rerenders defaults');
  closeAll(env);

  const result = Aster.selftest.run();
  check(result.ok, 'runtime release-gate self-test passes');
  equal(result.count, 20, 'self-test covers twenty registered capabilities including tools and workbenches');

  await mock.sidebar['aster-manager']();
  check(Aster.overlay.isOpen('manager'), 'native sidebar manager action opens manager');
  closeAll(env);
  await mock.sidebar['aster-rescan']();
  await waitFor(() => window.Aster.boot.state().booted, 'sidebar rescan');
  equal(window.Aster.boot.state().errors.length, 0, 'full rescan remains error-free');
  equal(window.Aster.boot.index().length, inventory.length, 'rescan reloads complete inventory');
  equal(window.Aster.capabilityRuntime.status().filter((row) => /^shell\./.test(row.binding)).length, 2, 'rescan leaves exactly two live shell bindings');
  const writesBeforeRescanDrag = mock.writes.filter((row) => row.key === 'aster.ui.positions').length;
  const rescannedPhone = window.__asterShell.hosts.phone.button;
  rescannedPhone.dispatchEvent(new FakeEvent('pointerdown', { pointerId: 9, clientX: 320, clientY: 90, bubbles: true }));
  rescannedPhone.dispatchEvent(new FakeEvent('pointermove', { pointerId: 9, clientX: 210, clientY: 180, bubbles: true }));
  rescannedPhone.dispatchEvent(new FakeEvent('pointerup', { pointerId: 9, clientX: 210, clientY: 180, bubbles: true }));
  equal(mock.writes.filter((row) => row.key === 'aster.ui.positions').length - writesBeforeRescanDrag, 1, 'rescan does not duplicate drag listeners');

  const race = await boot(false);
  check(race.Aster.shell.connected, 'runtime-first/fragment-second load order reconnects');
  check(race.Aster.selftest.run().ok, 'load-order race passes self-test');
  race.window.__asterShell.hosts.phone.button.click();
  check(race.Aster.overlay.isOpen('phone'), 'race-order phone button is live');

  const degraded = await boot(true, (tavo) => { delete tavo.character; delete tavo.file; });
  degraded.Aster.apps.open('data-manager');
  equal(degraded.Aster.dataManager.capabilities().character, false, 'capability probe reports unavailable Tavo character API');
  equal(degraded.Aster.dataManager.capabilities().file, false, 'capability probe reports unavailable Tavo file API');
  degraded.document.querySelector('[data-aster-tab="data"]').click();
  await waitFor(() => degraded.document.querySelectorAll('[data-aster-manager-row]').length >= 7, 'degraded Data Manager rows');
  check(degraded.document.querySelector('[data-aster-manager-row="lorebook:1"]'), 'missing character API does not blank lorebook data');
  check(degraded.document.querySelector('[data-aster-manager-row="regex:6"]'), 'missing character API does not blank regex data');
  const degradedInfo = degraded.document.querySelectorAll('.aster-form-info').map((node) => node.textContent).join(' ');
  check(degradedInfo.includes('角色卡未授权'), 'degraded data tab names the unavailable adapter without hiding healthy rows');
  degraded.document.querySelector('[data-aster-tab="resource"]').click();
  await waitFor(() => degraded.document.querySelector('.aster-error'), 'degraded resource error');
  check(degraded.document.querySelector('.aster-error').textContent.includes('tavo.file'), 'resource tab reports the exact missing file capability');
  degraded.Aster.overlay.closeAll();

  const legacyFile = await boot(true, (tavo) => { delete tavo.file.list; delete tavo.file.import; delete tavo.file.export; });
  equal(legacyFile.Aster.dataManager.capabilities().file, true, 'v117 save/load/delete/url base remains a valid file capability');
  equal(legacyFile.Aster.dataManager.capabilityDetails().fileList, false, 'method-granular probe does not invent file.list');
  await legacyFile.Aster.assets.saveText('legacy-local.txt', 'v117-local', { scope: 'chat' });
  legacyFile.Aster.apps.open('data-manager');
  legacyFile.document.querySelector('[data-aster-tab="resource"]').click();
  await waitFor(() => legacyFile.document.querySelector('[data-aster-manager-row="files/chat/legacy-local.txt"]'), 'v117 indexed resource row');
  check(legacyFile.document.querySelector('[data-aster-manager-edit="files/chat/legacy-local.txt"]'), 'v117 indexed text resource remains editable without file.list');
  legacyFile.Aster.overlay.closeAll();

  const runtimeSource = fs.readFileSync(path.join(ROOT, 'plugin-runtime/entry.js'), 'utf8');
  const shellSource = fs.readFileSync(path.join(ROOT, 'plugin-runtime/ui/shell.html'), 'utf8');
  const runtimeManifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'plugin-runtime/manifest.json'), 'utf8'));
  const shellCss = fs.readFileSync(path.join(ROOT, 'src-modules/skin/18-shell-style.txt'), 'utf8');
  const capabilitySource = fs.readFileSync(path.join(ROOT, 'src-modules/core/08-capabilities.txt'), 'utf8');
  check(!/window\.tavo|globalThis\.tavo/.test(runtimeSource + shellSource), 'plugin uses only official unqualified tavo binding');
  check(!/<style[\s>]/i.test(shellSource), 'plugin fragment owns no visual CSS');
  check(/#aster-shell-root[\s\S]*pointer-events:\s*auto/.test(shellCss), 'Skin book owns interactive floating-shell CSS');
  check(/\.aster-phone-frame[^}]*width:\s*min\(75vw,307px\)[^}]*height:\s*min\(775px,87\.5dvh\)/.test(shellCss), 'only the phone shell is one quarter taller and one quarter narrower');
  check(/\.aster-phone-screen[^}]*overflow-y:\s*auto/.test(shellCss), 'phone state owns vertical scrolling instead of the Tavo page');
  check(/\.aster-phone-quickbar[^}]*flex:\s*0 0 auto/.test(shellCss), 'phone quick-key bar remains outside the scrolling state');
  check(/data-layout-revision="orbit-2"/.test(shellCss), 'Skin owns the compact double-orbit dashboard namespace');
  check(/\.aster-worlddash-scroll\s*\{[^}]*overflow-y:\s*auto/.test(shellCss), 'dashboard scroll is isolated from the Tavo page');
  const dashboardRecipeStart = shellCss.indexOf('.aster-worlddash[data-layout-revision="orbit-2"] {');
  const dashboardRecipeEnd = shellCss.indexOf('[data-aster-social-frame="holo-veil-2"]', dashboardRecipeStart);
  const dashboardRecipe = shellCss.slice(dashboardRecipeStart, dashboardRecipeEnd);
  check(/grid-template-rows:\s*calc\(68px \+ env\(safe-area-inset-top,0px\)\)/.test(dashboardRecipe), 'dashboard safe-area inset expands its header row instead of consuming header content height');
  check(/\.aster-worlddash-sphere\s*\{[^}]*width:\s*min\(72%,266px\)/.test(dashboardRecipe), 'world sphere is diameter-capped for 390/394px hosts');
  check(/\.aster-worlddash-map-action\s*\{[^}]*overflow:\s*hidden[^}]*text-overflow:\s*ellipsis[^}]*white-space:\s*nowrap/.test(dashboardRecipe), 'compact location actions remain single-line and contained');
  check(!/(?:font-size:\s*|font:[^;]*\s)(?:8|9|10)px/.test(dashboardRecipe), 'orbit-2 contains no readable dashboard text below 11px');
  const compactPlayerHeight = cssPixel(cssRuleBody(shellCss, ['data-layout-revision="orbit-2"', '.aster-worlddash-player']), 'height');
  const compactOrbitHeight = cssPixel(cssRuleBody(shellCss, ['data-layout-revision="orbit-2"', '.aster-worlddash-orbit']), 'height');
  const compactGameplayHeight = cssPixel(cssRuleBody(shellCss, ['data-layout-revision="orbit-2"', '.aster-worlddash-gameplay-stage']), 'height');
  check(compactPlayerHeight >= 160 && compactPlayerHeight <= 210, 'compact player hero stays inside the 160–210px target band');
  check(compactOrbitHeight >= 350 && compactOrbitHeight <= 440, 'compact orbit stays inside the 350–440px target band');
  check(compactGameplayHeight >= 220 && compactGameplayHeight <= 300, 'compact gameplay scene stays inside the 220–300px target band');
  check(/data-aster-social-frame="holo-veil-2"/.test(shellCss), 'Skin owns the revised Holo Veil social recipe');
  const holoRecipeStart = shellCss.indexOf('/* Holo Veil 2');
  const holoRecipeEnd = shellCss.indexOf('--- doc', holoRecipeStart);
  const holoRecipe = shellCss.slice(holoRecipeStart, holoRecipeEnd < 0 ? shellCss.length : holoRecipeEnd);
  check(/data-aster-social-frame\]:not\(\[data-aster-social-frame="holo-veil-2"\]\).*data-aster-surface="safe-fullscreen"/.test(shellCss), 'legacy safe-fullscreen recipes explicitly exclude Holo Veil 2');
  check(/\.aster-standalone-main\s*\{[^}]*overflow-x:\s*hidden[^}]*overflow-y:\s*auto[^}]*overscroll-behavior:\s*contain/.test(holoRecipe), 'Holo Veil social.main owns the contained content scroll');
  check(/\.aster-social-list\s*\{[^}]*overflow:\s*visible/.test(holoRecipe), 'Holo Veil lists do not create competing nested vertical scrollers');
  check(/\.aster-social-portrait\s*\{[^}]*z-index:\s*1/.test(holoRecipe) && /\.aster-standalone-main\s*\{[^}]*z-index:\s*2/.test(holoRecipe), 'portrait backdrop stays below social.main');
  check(/\.aster-standalone-close\s*\{[^}]*width:\s*44px[^}]*height:\s*44px/.test(holoRecipe), 'Holo Veil close control keeps a 44px target');
  check(/\.aster-social-filter,[\s\S]*?\.aster-social-sort\s*\{[^}]*min-height:\s*44px/.test(holoRecipe), 'Holo Veil filters and sorts keep 44px targets');
  check(/:focus-visible\s*\{[^}]*outline:\s*2px/.test(holoRecipe), 'Holo Veil supplies an explicit keyboard focus indicator');
  check(!/(?:font-size:\s*|font:[^;]*\s)(?:8|9|10)(?:\.5)?px/.test(holoRecipe), 'Holo Veil contains no readable metadata below 11px');
  const mobile394Start = shellCss.search(/@media\s*\(max-width:\s*394px\)/);
  const mobile394End = mobile394Start < 0 ? -1 : shellCss.indexOf('@media', mobile394Start + 1);
  const mobile394Css = mobile394Start < 0 ? '' : shellCss.slice(mobile394Start, mobile394End < 0 ? shellCss.length : mobile394End);
  check(/data-social-index="live"[^{}]*\.aster-social-list\s*\{[^}]*grid-template-columns:\s*1fr/.test(mobile394Css), '390/394px live presentation is statically locked to one card column');
  check(/pointerdown/.test(capabilitySource) && /pointermove/.test(capabilitySource) && /pointerup/.test(capabilitySource), 'Core capability implements pointer drag lifecycle');
  check(!/attachDrag/.test(shellSource), 'plugin fragment owns no private drag implementation');
  check(runtimeManifest.permissions.includes('file'), 'runtime plugin declares the official file permission required by resource management');
  const nonSkinCss = inventory.filter((row) => !row.source.startsWith('src-modules/skin/')).filter((row) => /^--- css$/m.test(fs.readFileSync(path.join(ROOT, row.source), 'utf8')));
  equal(nonSkinCss.length, 0, 'all module CSS sections live exclusively in Skin book');

  const report = {
    ok: true, checks, modules: inventory.length, books: 5, panels: 25, apps: 16, parameters: 62,
    preferenceTypes: 6, preferenceSlots: 6, resourceSlots: 6, tools: 26, workbenches: 5, managementAdapters: 5,
    blueprintModules: 83, interfaceContracts: 19,
    componentTypes: 3, styles: 5, effects: 4, commands: 10, selftest: 20,
    realBrowser: false, hostDevice: false
  };
  fs.writeFileSync(path.join(ROOT, 'reports/first-gate-test-results.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report));
}

main().catch((error) => { console.error(error.stack || error); process.exitCode = 1; });
