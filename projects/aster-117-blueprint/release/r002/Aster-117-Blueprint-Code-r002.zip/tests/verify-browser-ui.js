'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
let chromium = null;
try { chromium = require('playwright').chromium; } catch (ignored) {}

const ROOT = path.resolve(__dirname, '..');
const REPORTS = path.join(ROOT, 'reports');
let checks = 0;
function check(value, message) { assert.ok(value, message); checks += 1; }

function scriptSafe(value) { return String(value).replace(/<\/script/gi, '<\\/script'); }
function localAssetUrls() {
  const base = path.join(ROOT, 'assets');
  const rows = [
    ['scenes/world.webp', 'scene-world.webp', 'image/webp'],
    ['scenes/home.webp', 'scene-home.webp', 'image/webp'],
    ['scenes/celebration.webp', 'scene-celebration.webp', 'image/webp'],
    ['scenes/city.webp', 'scene-city.webp', 'image/webp'],
    ['scenes/station.webp', 'scene-station.webp', 'image/webp'],
    ['scenes/qa.webp', 'scene-qa.webp', 'image/webp'],
    ['icons/hud/team.svg', 'hud-team.svg', 'image/svg+xml'],
    ['icons/hud/encounter.svg', 'hud-encounter.svg', 'image/svg+xml'],
    ['icons/hud/check.svg', 'hud-check.svg', 'image/svg+xml'],
    ['icons/hud/spell.svg', 'hud-spell.svg', 'image/svg+xml'],
    ['icons/hud/marker.svg', 'hud-marker.svg', 'image/svg+xml']
  ];
  return Object.fromEntries(rows.map(([relative, storedName, mime]) => [storedName, 'data:' + mime + ';base64,' + fs.readFileSync(path.join(base, relative)).toString('base64')]));
}
function pageSource() {
  const books = ['核心', '功能', '图鉴', '系统', '皮肤'].map((suffix) => JSON.parse(fs.readFileSync(path.join(ROOT, 'out', 'Aster·' + suffix + '.json'), 'utf8')));
  const payload = JSON.stringify(books).replace(/</g, '\\u003c');
  const assetPayload = JSON.stringify(localAssetUrls()).replace(/</g, '\\u003c');
  const mock = `(function () {
    const source = ${payload};
    const assetUrls = ${assetPayload};
    const books = source.map((book, index) => ({ id: index + 1, name: book.name, entries: book.entries }));
    const stores = { chat: new Map(), global: new Map(), message: new Map() };
    const sidebar = {};
    window.tavo = {
      get(key, scope = 'chat') { const value = stores[scope].get(key); return value == null ? value : JSON.parse(JSON.stringify(value)); },
      set(key, value, scope = 'chat') { stores[scope].set(key, JSON.parse(JSON.stringify(value))); return value; },
      update(key, value, scope = 'chat') { const before = stores[scope].get(key); const next = before && value && typeof before === 'object' ? Object.assign({}, before, value) : value; stores[scope].set(key, next); return next; },
      unset(key, scope = 'chat') { stores[scope].delete(key); },
      lorebook: {
        async all() { return books.map((book) => ({ id: book.id, name: book.name, entries: book.entries.length })); },
        async get(id) { return books.find((book) => book.id === id); },
        async find(name) { return books.filter((book) => book.name === name); },
        async create(value) { return value; }, async update(value) { return value; }, async delete() {}
      },
      regex: { async all() { return []; } },
      theme: { async all() { return []; } },
      file: {
        async list() { return { files: [], nextCursor: null }; }, async import() { return []; }, async export(path) { return { path }; },
        async save(path) { return { path }; }, async load() { return ''; }, async delete() { return true; },
        async exists(path) { return !!assetUrls[String(path).split('/').pop()]; },
        async url(path) { const name = String(path).split('/').pop(); return assetUrls[name] || 'mock://file/' + encodeURIComponent(path); }
      },
      app: { async versionNumber() { return 930; }, async version() { return '0.93.0'; } },
      utils: { toast(message) { window.__toasts = (window.__toasts || []).concat(String(message)); } },
      plugin: {
        config: { get() {}, all() { return {}; } },
        i18n: { requestedLocale: 'zh-CN', locale: 'zh-CN', defaultLocale: 'en', t(key) { return key; }, onChange() { return function () {}; } },
        on() {}, onSidebarAction(id, action) { sidebar[id] = action; }, onInputAction() {}
      }
    };
    window.__browserMock = { stores, sidebar };
  }());`;
  const shell = fs.readFileSync(path.join(ROOT, 'plugin-runtime/ui/shell.html'), 'utf8');
  const runtime = fs.readFileSync(path.join(ROOT, 'plugin-runtime/entry.js'), 'utf8');
  return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>' +
    '<script>' + scriptSafe(mock) + '</script>' + shell + '<script>' + scriptSafe(runtime) + '</script></body></html>';
}

async function insideViewport(page, selector, label) {
  const result = await page.locator(selector).first().evaluate((node) => {
    const box = node.getBoundingClientRect();
    return { x: box.x, y: box.y, right: box.right, bottom: box.bottom, width: box.width, height: box.height, vw: innerWidth, vh: innerHeight };
  });
  check(result.width > 0 && result.height > 0, label + ' has a rendered box');
  check(result.x >= -1 && result.right <= result.vw + 1, label + ' fits viewport horizontally');
  check(result.y >= -1 && result.bottom <= result.vh + 1, label + ' fits viewport vertically');
}

async function createPage(browser, viewport) {
  const page = await browser.newPage({ viewport });
  await page.setContent(pageSource(), { waitUntil: 'load' });
  await page.waitForFunction(() => window.Aster && window.Aster.boot.state().booted && window.Aster.shell && window.Aster.shell.connected);
  await page.evaluate(() => {
    document.body.style.margin = '0';
    document.body.style.minHeight = '100vh';
    document.body.style.background = 'radial-gradient(circle at 50% 20%,#182b38,#03070b 62%)';
  });
  return page;
}

async function activateOrbitRoute(page, id, activated) {
  const button = page.locator('[data-orbit-entry="' + id + '"]');
  await button.click();
  if (!(await activated())) {
    const ringName = await button.evaluate((node) => {
      const ring = node.closest('[data-orbit-ring]');
      return ring && ring.getAttribute('data-orbit-ring');
    });
    check(!!ringName, id + ' belongs to a keyboard-operable orbit ring');
    await page.locator('[data-orbit-ring="' + ringName + '"]').press('Enter');
  }
  check(await activated(), id + ' activates after focus plus Enter when needed');
}

async function socialScreenshot(page, filename) {
  if (filename) await page.locator('[data-aster-social-frame="holo-veil-2"]').screenshot({ path: path.join(REPORTS, filename) });
}

async function verifyPhone(page, viewport, screenshot) {
  await page.locator('#aster-shell-phone').click();
  await page.locator('[data-aster-phone-state="home"]').waitFor();
  check(await page.locator('[data-aster-phone-state]').count() === 1, viewport.width + ' phone shows one state');
  check(await page.locator('[data-aster-phone-key]').count() === 3, viewport.width + ' phone shows ○×△');
  await insideViewport(page, '.aster-phone-frame', viewport.width + ' phone frame');
  await insideViewport(page, '.aster-phone-quickbar', viewport.width + ' quick-key bar');
  check(await page.locator('.aster-phone-screen').evaluate((node) => getComputedStyle(node).overflowY === 'auto'), viewport.width + ' phone scroll stays inside the active state');
  const interactive = await page.locator('[data-aster-phone-key="drawer"]').evaluate((node) => getComputedStyle(node).pointerEvents);
  check(interactive !== 'none', viewport.width + ' phone quick keys accept pointer events');
  const beforePage = await page.evaluate(() => window.Aster.phone.state().page);
  await page.locator('[data-aster-phone-state="home"]').dispatchEvent('pointerdown', { pointerId: 31, clientX: 330, clientY: 540 });
  await page.locator('[data-aster-phone-state="home"]').dispatchEvent('pointerup', { pointerId: 31, clientX: 55, clientY: 540 });
  check(await page.evaluate((before) => window.Aster.phone.state().page !== before, beforePage), viewport.width + ' phone horizontal swipe changes page');
  if (screenshot) await page.screenshot({ path: path.join(REPORTS, screenshot), fullPage: true });
  await page.locator('[data-aster-phone-key="drawer"]').click();
  await page.locator('[data-aster-phone-state="drawer"]').waitFor();
  check(await page.locator('[data-aster-phone-state]').count() === 1, viewport.width + ' drawer replaces home');
  check(await page.locator('[data-aster-app="data-manager"]').count() > 0, viewport.width + ' drawer contains Data Manager');
  check(await page.locator('[data-aster-app="parameters"]').count() === 0, viewport.width + ' drawer hides developer parameters');
  await page.locator('[data-aster-phone-key="home"]').click();
  await page.locator('[data-aster-phone-world="true"]').click();
  await page.locator('[data-aster-dev-enter="true"]').click();
  await page.locator('[data-aster-phone-state="developer"]').waitFor();
  check(await page.locator('[data-aster-app="parameters"]').count() > 0, viewport.width + ' explicit developer state reveals parameters');
  await page.locator('[data-aster-phone-key="back"]').click();
  await page.locator('[data-aster-phone-key="back"]').click();
  await page.waitForFunction(() => !window.Aster.overlay.isOpen('phone'));
}

async function verifyDashboard(page, viewport, screenshot, socialScreenshots) {
  socialScreenshots = socialScreenshots || {};
  await page.locator('#aster-shell-dashboard').click();
  await page.locator('.aster-worlddash').waitFor();
  check(await page.locator('.aster-overlay-header').count() === 0, viewport.width + ' dashboard has no generic outer shell header');
  await insideViewport(page, '.aster-overlay-panel', viewport.width + ' dashboard panel');
  check(await page.locator('[data-aster-dashboard-frame]').getAttribute('data-layout-revision') === 'orbit-2', viewport.width + ' dashboard uses the compact orbit-2 namespace');
  check(await page.locator('[data-gameplay-tab]').count() === 4, viewport.width + ' dashboard exposes four gameplay modes');
  check(await page.locator('[data-orbit-ring="inner"] [data-orbit-entry]').count() === 5, viewport.width + ' dashboard exposes five inner-orbit actions');
  check(await page.locator('[data-orbit-ring="outer"] [data-orbit-entry]').count() === 4, viewport.width + ' dashboard exposes four outer-orbit routes');
  check(await page.locator('[data-orbit-entry]').evaluateAll((nodes) => nodes.every((node) => !!node.querySelector('.aster-worlddash-satellite-icon'))), viewport.width + ' every orbit action uses the common satellite icon wrapper');
  check(await page.locator('[data-aster-dashboard-phone]').count() === 0, viewport.width + ' dashboard has no phone navigation');
  check(await page.locator('[data-aster-scroll-key="world-dashboard"]').count() === 1, viewport.width + ' dashboard owns exactly one internal scroll document');
  const dashboardGeometry = await page.locator('.aster-worlddash').evaluate((frame) => {
    const panel = frame.closest('.aster-overlay-panel');
    const scroll = frame.querySelector('[data-aster-scroll-key="world-dashboard"]');
    const box = frame.getBoundingClientRect();
    const panelBox = panel.getBoundingClientRect();
    const style = getComputedStyle(scroll);
    const player = frame.querySelector('.aster-worlddash-player').getBoundingClientRect();
    const orbit = frame.querySelector('.aster-worlddash-orbit').getBoundingClientRect();
    const gameplay = frame.querySelector('.aster-worlddash-gameplay-stage').getBoundingClientRect();
    return { widthDelta: Math.abs(box.width - panelBox.width), heightDelta: Math.abs(box.height - panelBox.height), scrollY: style.overflowY, playerHeight: player.height, orbitHeight: orbit.height, gameplayHeight: gameplay.height, rightOverflow: Math.max(0, box.right - innerWidth), leftOverflow: Math.max(0, -box.left) };
  });
  check(dashboardGeometry.widthDelta < 2 && dashboardGeometry.heightDelta < 2, viewport.width + ' dashboard fills its host-safe fullscreen panel');
  check(['auto', 'scroll'].includes(dashboardGeometry.scrollY), viewport.width + ' dashboard content scroll is isolated inside the panel');
  check(dashboardGeometry.playerHeight >= 160 && dashboardGeometry.playerHeight <= 210, viewport.width + ' player hero stays inside the compact 160–210px target band');
  check(dashboardGeometry.orbitHeight >= 350 && dashboardGeometry.orbitHeight <= 440, viewport.width + ' orbit stays inside the compact 350–440px target band');
  check(dashboardGeometry.gameplayHeight >= 220 && dashboardGeometry.gameplayHeight <= 300, viewport.width + ' gameplay stays inside the compact 220–300px target band');
  check(dashboardGeometry.leftOverflow < 2 && dashboardGeometry.rightOverflow < 2, viewport.width + ' dashboard never overflows the mobile viewport horizontally');
  await page.locator('[data-gameplay-tab="pet"]').click();
  check(await page.locator('[data-gameplay-stage]').getAttribute('data-gameplay-stage') === 'pet', viewport.width + ' gameplay tab is clickable');
  await page.locator('[data-map-node="archive"]').click();
  check(await page.locator('[data-map-popup="archive"]').count() === 1, viewport.width + ' map point opens its registered location card');

  await page.evaluate(() => {
    window.__orbitDragActivations = 0;
    window.Aster.dashboard.registerRoute('drag-neighbour-browser', { label: '拖动前项', description: '浏览器拖动测试', icon: '◇', open() {}, order: 50 });
    window.Aster.dashboard.registerRoute('drag-target-browser', { label: '拖动目标', description: '浏览器拖动测试', icon: '◇', open() { window.__orbitDragActivations += 1; }, order: 60 });
  });
  await page.locator('[data-orbit-entry="drag-neighbour-browser"]').click();
  await page.evaluate(() => { window.__orbitDragActivations = 0; });
  const outerRing = page.locator('[data-orbit-ring="outer"]');
  await outerRing.dispatchEvent('pointerdown', { pointerId: 71, clientX: 280, clientY: 520, bubbles: true });
  await outerRing.dispatchEvent('pointermove', { pointerId: 71, clientX: 170, clientY: 520, bubbles: true });
  await outerRing.dispatchEvent('pointerup', { pointerId: 71, clientX: 150, clientY: 520, bubbles: true });
  const dragTarget = page.locator('[data-orbit-entry="drag-target-browser"]');
  check(await dragTarget.getAttribute('aria-selected') === 'true', viewport.width + ' orbit drag snaps to the next browser test route');
  await dragTarget.dispatchEvent('click', { bubbles: true, cancelable: true });
  check(await page.evaluate(() => window.__orbitDragActivations) === 0, viewport.width + ' orbit drag suppresses the browser follow-up click');
  await dragTarget.click();
  check(await page.evaluate(() => window.__orbitDragActivations) === 1, viewport.width + ' the next intentional orbit click still executes');
  await page.evaluate(() => {
    window.Aster.dashboard.unregisterRoute('drag-target-browser');
    window.Aster.dashboard.unregisterRoute('drag-neighbour-browser');
  });

  if (screenshot) await page.screenshot({ path: path.join(REPORTS, screenshot), fullPage: true });
  await activateOrbitRoute(page, 'world-social', () => page.evaluate(() => window.Aster.overlay.isOpen('panel:world-social')));
  await page.locator('[data-aster-social-frame="holo-veil-2"]').waitFor();
  const fullscreenState = await page.evaluate(() => ({ dashboard: window.Aster.overlay.isOpen('dashboard'), social: window.Aster.overlay.isOpen('panel:world-social'), depth: window.Aster.overlay.depth() }));
  check(!fullscreenState.dashboard && fullscreenState.social && fullscreenState.depth === 1, viewport.width + ' world social replaces rather than stacks over the dashboard');
  check(await page.locator('[data-aster-social-mode]').count() === 3, viewport.width + ' social sidebar exposes message/forum/live modes');
  check(await page.locator('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation') === 'messages', viewport.width + ' social root starts in the messages presentation');
  const markerIdentity = await page.locator('[data-aster-social-frame="holo-veil-2"]').evaluate((root) => {
    function ids(attribute) {
      return Array.from(root.querySelectorAll('[' + attribute + ']')).map((node) => {
        const entry = node.closest('[data-aster-social-item]');
        return entry && entry.getAttribute('data-aster-social-item');
      }).filter(Boolean);
    }
    const unread = ids('data-aster-social-unread');
    const online = ids('data-aster-social-online');
    return { unread, online, unreadUnique: new Set(unread).size, onlineUnique: new Set(online).size };
  });
  check(markerIdentity.unread.length >= 3 && markerIdentity.unreadUnique === markerIdentity.unread.length, viewport.width + ' unread markers map one-to-one to message entries');
  check(markerIdentity.online.length > 0 && markerIdentity.onlineUnique === markerIdentity.online.length, viewport.width + ' online markers map one-to-one to social entries');
  await socialScreenshot(page, socialScreenshots.messages);
  await page.locator('[data-aster-social-mode="forum"]').click();
  check(await page.evaluate(() => window.Aster.social.state().mode) === 'forum', viewport.width + ' social mode switch is live');
  check(await page.locator('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation') === 'forum', viewport.width + ' social root switches to the forum presentation');
  await socialScreenshot(page, socialScreenshots.forum);
  const forumInitial = await page.evaluate(() => window.Aster.social.state('forum').total);
  await page.locator('[data-aster-social-search="forum"]').fill('家园');
  const forumFiltered = await page.evaluate(() => window.Aster.social.state('forum').total);
  check(forumFiltered > 0 && forumFiltered < forumInitial, viewport.width + ' forum search filters registered posts');
  await page.locator('[data-aster-social-search-clear="forum"]').click();
  check(await page.evaluate(() => window.Aster.social.state('forum').total) === forumInitial, viewport.width + ' forum search clear restores posts');
  await page.locator('[data-aster-social-filter="forum:board:guide"]').click();
  check(await page.evaluate(() => window.Aster.social.state('forum').filters.board) === 'guide', viewport.width + ' forum board filter is live');
  await page.locator('[data-aster-social-sort="forum:replies"]').click();
  check(await page.evaluate(() => window.Aster.social.state('forum').sort) === 'replies', viewport.width + ' forum reply sort is live');
  await page.locator('[data-aster-social-mode="live"]').click();
  check(await page.evaluate(() => window.Aster.social.state().mode) === 'live', viewport.width + ' live mode switch is live');
  check(await page.locator('[data-aster-social-frame="holo-veil-2"]').getAttribute('data-social-presentation') === 'live', viewport.width + ' social root switches to the live presentation');
  if (viewport.width <= 394) {
    const liveLayout = await page.locator('[data-social-index="live"] .aster-social-list').evaluate((node) => {
      const box = node.getBoundingClientRect();
      const columns = getComputedStyle(node).gridTemplateColumns.trim().split(/\s+/).filter(Boolean).length;
      const fullWidthCards = Array.from(node.children).every((card) => card.getBoundingClientRect().width >= box.width - 2);
      return { columns, fullWidthCards };
    });
    check(liveLayout.columns === 1 && liveLayout.fullWidthCards, viewport.width + ' live cards use one full-width column at the 390/394px host widths');
  }
  await socialScreenshot(page, socialScreenshots.live);
  check(await page.locator('[data-aster-social-frame="holo-veil-2"] .aster-social-rail').count() === 1, viewport.width + ' social keeps one vertical mode rail');
  check(await page.locator('[data-aster-social-frame="holo-veil-2"] [data-aster-orbit-asset-state="ready"]').count() > 0, viewport.width + ' selected runtime art resolves from the canonical asset set');
  await insideViewport(page, '[data-aster-social-frame="holo-veil-2"]', viewport.width + ' social shell');
}

async function verifyDataEditor(page, viewport, screenshot) {
  await page.evaluate(() => window.Aster.apps.open('data-manager'));
  await page.locator('[data-aster-manager-edit="lorebook:1"]').waitFor();
  await page.locator('[data-aster-manager-edit="lorebook:1"]').click();
  await page.locator('[data-aster-standalone="data-record-editor"]').waitFor();
  await insideViewport(page, '[data-aster-standalone="data-record-editor"]', viewport.width + ' data editor');
  check(await page.locator('[data-aster-editor-toolbar="lorebook"]').count() === 1, viewport.width + ' data editor has one functional object toolbar');
  check(await page.locator('[data-aster-entry-sidebar="lorebook"]').count() === 1, viewport.width + ' data editor has one internal entry sidebar');
  const layout = await page.locator('[data-aster-standalone="data-record-editor"]').evaluate((root) => {
    const body = root.querySelector('[data-aster-workbench-body="record-editor"]');
    const sidebar = root.querySelector('[data-aster-entry-sidebar]');
    const main = root.querySelector('[data-aster-entry-editor]');
    const header = root.querySelector('.aster-standalone-header');
    const toolbarButton = root.querySelector('[data-aster-editor-toolbar] .aster-button');
    const control = root.querySelector('.aster-control');
    const box = root.getBoundingClientRect();
    const sideBox = sidebar.getBoundingClientRect();
    const mainBox = main.getBoundingClientRect();
    return {
      height: box.height,
      width: box.width,
      sideRatio: sideBox.width / (sideBox.width + mainBox.width),
      mainOverflow: getComputedStyle(main).overflowY,
      bodyOverflow: getComputedStyle(body).overflow,
      headerHeight: header.getBoundingClientRect().height,
      toolbarButtonHeight: toolbarButton.getBoundingClientRect().height,
      buttonRadius: getComputedStyle(toolbarButton).borderRadius,
      buttonClip: getComputedStyle(toolbarButton).clipPath,
      controlRadius: getComputedStyle(control).borderRadius
    };
  });
  check(layout.height > viewport.height * 0.78, viewport.width + ' data editor fills the available safe-area height');
  check(layout.width > Math.min(viewport.width * 0.94, 920), viewport.width + ' data editor uses a full-width independent panel');
  check(layout.sideRatio > 0.24 && layout.sideRatio < 0.30, viewport.width + ' data editor keeps the dense 27/73 split');
  check(layout.mainOverflow === 'auto', viewport.width + ' data editor scroll remains inside the form pane');
  check(layout.headerHeight <= 52, viewport.width + ' data editor header is compact');
  check(layout.toolbarButtonHeight <= 26, viewport.width + ' data editor toolbar uses dense controls');
  check(layout.buttonRadius === '0px' && layout.controlRadius === '0px', viewport.width + ' data editor removes bulky rounded controls');
  check(layout.buttonClip !== 'none', viewport.width + ' data editor buttons use the glass cut-corner treatment');
  if (screenshot) await page.screenshot({ path: path.join(REPORTS, screenshot), fullPage: true });
  await page.evaluate(() => window.Aster.overlay.closeAll());
}

async function main() {
  fs.mkdirSync(REPORTS, { recursive: true });
  if (!chromium) {
    const skipped = { ok: null, skipped: true, realBrowser: false, hostDevice: false, reason: 'Playwright package is not installed; the selected-UI browser contract is present but was not executed' };
    fs.writeFileSync(path.join(REPORTS, 'browser-ui-test-results.json'), JSON.stringify(skipped, null, 2) + '\n');
    console.log(JSON.stringify(skipped));
    return;
  }
  const executablePath = process.env.ASTER_CHROMIUM_EXECUTABLE || chromium.executablePath();
  if (!fs.existsSync(executablePath)) {
    const skipped = { ok: null, skipped: true, realBrowser: false, hostDevice: false, reason: 'Playwright Chromium executable is not installed' };
    fs.writeFileSync(path.join(REPORTS, 'browser-ui-test-results.json'), JSON.stringify(skipped, null, 2) + '\n');
    console.log(JSON.stringify(skipped));
    return;
  }
  const extraArgs = String(process.env.ASTER_CHROMIUM_ARGS || '').split(/\s+/).filter(Boolean);
  const browser = await chromium.launch({ headless: true, executablePath, args: ['--no-sandbox'].concat(extraArgs) });
  const sizes = [
    { width: 390, height: 844, phone: 'browser-phone-390x844.png', editor: 'browser-data-editor-390x844.png', dashboard: 'browser-dashboard-390x844.png', social: { messages: 'browser-social-messages-390x844.png', forum: 'browser-social-forum-390x844.png', live: 'browser-social-live-390x844.png' } },
    { width: 394, height: 853 },
    { width: 768, height: 1024 },
    { width: 1440, height: 1000, dashboard: 'browser-dashboard-1440x1000.png' }
  ];
  try {
    for (const size of sizes) {
      const page = await createPage(browser, size);
      await verifyPhone(page, size, size.phone);
      await verifyDataEditor(page, size, size.editor);
      await verifyDashboard(page, size, size.dashboard, size.social);
      const noHorizontalOverflow = await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1);
      check(noHorizontalOverflow, size.width + ' viewport has no document-level horizontal overflow');
      await page.close();
    }
  } finally {
    await browser.close();
  }
  const report = { ok: true, checks, realBrowser: true, hostDevice: false, viewports: sizes.map(({ width, height }) => ({ width, height })) };
  fs.writeFileSync(path.join(REPORTS, 'browser-ui-test-results.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report));
}

main().catch((error) => { console.error(error.stack || error); process.exitCode = 1; });
