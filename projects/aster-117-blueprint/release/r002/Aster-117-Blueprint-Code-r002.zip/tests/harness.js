'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { webcrypto } = require('crypto');
const { TextEncoder } = require('util');
const { createDOM, FakeEvent, FakeCustomEvent } = require('./fake-dom');

function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }

function createTavo(initialBooks = []) {
  let nextId = 1;
  const books = initialBooks.map((book) => ({ id: nextId++, name: book.name, entries: clone(book.entries) }));
  const regexes = [{ id: nextId++, name: 'Aster UI probe', entries: [{ find: 'probe', replace: 'ok' }] }];
  const themes = [{ id: nextId++, name: 'Tavo Night', mode: 'dark', tokens: { accent: '#62e8ff' } }];
  const characters = [{ id: nextId++, name: '星轨旅人', description: 'Aster character fixture', personality: 'calm', scenario: 'terminal district', firstMes: '你好。', mesExample: '', creatorNotes: '', systemPrompt: '', postHistoryInstructions: '', tags: ['fixture'] }];
  const presets = [{ id: nextId++, name: 'Aster Story', basicPrompts: { chatStart: '[Aster]' }, entries: [{ identifier: 'main', name: 'Main', content: 'Fixture prompt', enabled: true, active: true, type: 'custom', role: 'system' }] }];
  const files = {
    chat: [{ path: 'files/chat/aster-notes.json', name: 'aster-notes.json', size: 24, mimeType: 'application/json', content: '{"ready":true}' }],
    global: [{ path: 'files/global/aster-avatar.png', name: 'aster-avatar.png', size: 128, mimeType: 'image/png', content: 'mock-image' }]
  };
  const fileImportQueue = [];
  const exports = [];
  const stores = { chat: new Map(), global: new Map(), message: new Map() };
  const hooks = Object.create(null);
  const sidebar = Object.create(null);
  const inputActions = Object.create(null);
  const toasts = [];
  const reads = [];
  const writes = [];
  const catalog = {
    'shell.phone': 'Open Aster phone', 'shell.dashboard': 'Open world dashboard',
    'runtime.scanning': 'Scanning', 'runtime.ready': 'Ready {count}', 'runtime.empty': 'Empty', 'runtime.failed': 'Failed {message}',
    'ui.title': 'Aster Five-Book Import', 'ui.lead': 'Only exact Aster books', 'ui.placeholder': 'Paste JSON',
    'ui.queue': 'Add to queue', 'ui.importAll': 'Import all', 'ui.clear': 'Clear queue', 'ui.close': 'Close',
    'ui.empty': 'Queue is empty', 'ui.ready': 'Ready', 'ui.importing': 'Importing'
  };
  const tavo = {
    get(key, scope = 'chat') { return clone(stores[scope].get(key)); },
    set(key, value, scope = 'chat') { writes.push({ op: 'set', key, scope, value: clone(value) }); stores[scope].set(key, clone(value)); return clone(value); },
    update(key, value, scope = 'chat') {
      const before = stores[scope].get(key);
      const next = before && value && typeof before === 'object' && typeof value === 'object' ? Object.assign({}, before, value) : value;
      stores[scope].set(key, clone(next)); return clone(next);
    },
    unset(key, scope = 'chat') { stores[scope].delete(key); },
    lorebook: {
      async all() { return books.map((book) => ({ id: book.id, name: book.name, entries: Array.isArray(book.entries) ? book.entries.length : Object.keys(book.entries || {}).length })); },
      async get(id) { reads.push(id); return clone(books.find((book) => book.id === id) || null); },
      async find(name, options = {}) {
        const match = options.match || 'exact';
        return clone(books.filter((book) => match === 'exact' ? book.name === name : book.name.includes(name)));
      },
      async create(book) { const row = { id: nextId++, name: book.name, entries: clone(book.entries || []) }; books.push(row); writes.push({ op: 'lorebook.create', id: row.id, name: row.name }); return row.id; },
      async update(book) {
        const index = books.findIndex((row) => row.id === book.id);
        if (index < 0) throw new Error('book not found: ' + book.id);
        let entries = clone(book.entries || []);
        /* Real Tavo readback decorates lorebook entries with host-owned fields.
           Resource-book no-op detection must ignore these fields. */
        if (book.name === 'Aster·资源书') entries = entries.map((entry, at) => Object.assign({}, entry, {
          _tavoEntryId: 'host-' + book.id + '-' + at,
          _tavoParentId: book.id
        }));
        books[index] = { id: book.id, name: book.name, entries }; writes.push({ op: 'lorebook.update', id: book.id, name: book.name }); return book.id;
      },
      async import(book) { const row = { id: nextId++, name: book.name || 'Imported lorebook', entries: clone(book.entries || []) }; books.push(row); return row.id; },
      async delete(id) { const index = books.findIndex((book) => book.id === (id && id.id || id)); if (index >= 0) books.splice(index, 1); }
    },
    regex: {
      async all() { return regexes.map((row) => ({ id: row.id, name: row.name, entries: (row.entries || []).length })); },
      async get(id) { return clone(regexes.find((row) => row.id === id) || null); },
      async find(name) { return clone(regexes.filter((row) => row.name === name)); },
      async create(value) { const row = Object.assign({ id: nextId++, name: 'Regex ' + nextId, entries: [] }, clone(value || {})); regexes.push(row); return row.id; },
      async update(value) { const index = regexes.findIndex((row) => row.id === value.id); if (index < 0) throw new Error('regex not found: ' + value.id); regexes[index] = clone(value); return value.id; },
      async delete(id) { const index = regexes.findIndex((row) => row.id === (id && id.id || id)); if (index >= 0) regexes.splice(index, 1); },
      async import(value) { const row = Object.assign({ id: nextId++, name: 'Imported regex', entries: [] }, clone(value || {})); regexes.push(row); return row.id; }
    },
    character: {
      async all() { return characters.map((row) => ({ id: row.id, name: row.name, tags: clone(row.tags || []) })); },
      async get(id) { return clone(characters.find((row) => row.id === id) || null); },
      async find(name) { return clone(characters.filter((row) => row.name === name)); },
      async create(value) { const row = Object.assign({ id: nextId++, name: 'Character ' + nextId, firstMes: 'Hello', tags: [] }, clone(value || {})); characters.push(row); return row.id; },
      async update(value) { const index = characters.findIndex((row) => row.id === value.id); if (index < 0) throw new Error('character not found: ' + value.id); characters[index] = clone(value); return value.id; },
      async delete(id) { const index = characters.findIndex((row) => row.id === (id && id.id || id)); if (index >= 0) characters.splice(index, 1); },
      async import(value) { const row = Object.assign({ id: nextId++, name: 'Imported character', firstMes: 'Hello', tags: [] }, clone(value || {})); characters.push(row); return row.id; }
    },
    preset: {
      async all() { return presets.map((row) => ({ id: row.id, name: row.name, entries: (row.entries || []).length })); },
      async get(id) { return clone(presets.find((row) => row.id === id) || null); },
      async find(name) { return clone(presets.filter((row) => row.name === name)); },
      async create(value) { const row = Object.assign({ id: nextId++, name: 'Preset ' + nextId, basicPrompts: {}, entries: [] }, clone(value || {})); presets.push(row); return row.id; },
      async update(value) { const index = presets.findIndex((row) => row.id === value.id); if (index < 0) throw new Error('preset not found: ' + value.id); presets[index] = clone(value); return value.id; },
      async delete(id) { const index = presets.findIndex((row) => row.id === (id && id.id || id)); if (index >= 0) presets.splice(index, 1); },
      async import(value) { const row = Object.assign({ id: nextId++, name: 'Imported preset', basicPrompts: {}, entries: [] }, clone(value || {})); presets.push(row); return row.id; }
    },
    theme: {
      async all() { return themes.map((row) => ({ id: row.id, name: row.name, mode: row.mode })); },
      async get(id) { return clone(themes.find((row) => row.id === id) || null); },
      async find(name) { return clone(themes.filter((row) => row.name === name)); },
      async create(value) { const row = Object.assign({ id: nextId++, name: 'Theme ' + nextId }, clone(value || {})); themes.push(row); return row.id; },
      async update(id, value) { const index = themes.findIndex((row) => row.id === id); if (index < 0) throw new Error('theme not found: ' + id); themes[index] = Object.assign({}, clone(value || {}), { id }); return id; },
      async delete(id) { const index = themes.findIndex((row) => row.id === (id && id.id || id)); if (index >= 0) themes.splice(index, 1); },
      async import(filePath) { const row = { id: nextId++, name: path.basename(String(filePath || 'Imported.thm')), mode: 'dark' }; themes.push(row); return row.id; },
      async export(id) {
        const row = themes.find((item) => item.id === id); if (!row) throw new Error('theme not found: ' + id);
        const filePath = 'chat/' + row.name.replace(/\s+/g, '-') + '.thm';
        files.chat.push({ path: filePath, name: path.basename(filePath), size: 64, mime: 'application/octet-stream', content: JSON.stringify(row) });
        return { path: filePath };
      }
    },
    file: {
      async list(options = {}) {
        const scope = options.scope || 'chat';
        return { files: (files[scope] || []).map((row) => { const copy = clone(row); delete copy.content; return copy; }), nextCursor: null };
      },
      async import(options = {}) {
        const queued = fileImportQueue.shift(); if (!queued) return [];
        const scope = options.scope || queued.scope || 'chat';
        const batch = Array.isArray(queued) ? queued : [queued];
        return batch.map((source) => {
          const row = Object.assign({ path: 'files/' + scope + '/' + (source.name || path.basename(source.path || 'import.json')), name: source.name || path.basename(source.path || 'import.json'), size: String(source.content || '').length, mimeType: 'application/json', content: source.content || '' }, clone(source));
          if (!row.path) row.path = 'files/' + scope + '/' + row.name;
          const target = files[scope] || (files[scope] = []); const old = target.findIndex((item) => item.path === row.path); if (old >= 0) target.splice(old, 1); target.push(row);
          const copy = clone(row); delete copy.content; return copy;
        });
      },
      async save(filePath, content, options = {}) {
        const scope = options.scope || (String(filePath).startsWith('files/global/') ? 'global' : 'chat');
        const name = path.basename(String(filePath));
        const virtualPath = String(filePath).startsWith('files/') ? String(filePath) : 'files/' + scope + '/' + name;
        const row = { path: virtualPath, name, size: String(content || '').length, mimeType: options.mime || 'application/octet-stream', content: String(content || '') };
        const target = files[scope] || (files[scope] = []); const old = target.findIndex((item) => item.path === row.path); if (old >= 0) target.splice(old, 1); target.push(row); return virtualPath;
      },
      async load(filePath) { for (const scope of Object.keys(files)) { const row = files[scope].find((item) => item.path === filePath); if (row) return row.content; } throw new Error('file not found: ' + filePath); },
      async delete(filePath) { for (const scope of Object.keys(files)) { const index = files[scope].findIndex((row) => row.path === filePath); if (index >= 0) { files[scope].splice(index, 1); return true; } } return false; },
      async exists(filePath) { return Object.keys(files).some((scope) => files[scope].some((row) => row.path === filePath)); },
      async url(filePath, scope = 'chat') { return 'mock://file/' + encodeURIComponent(String(filePath).startsWith('files/') ? filePath : 'files/' + scope + '/' + filePath); },
      async export(filePath, content) { if (content !== undefined) await this.save(filePath, content); exports.push({ path: filePath, content }); return { path: filePath, exported: true }; }
    },
    app: { async versionNumber() { return 930; }, async version() { return '0.93.0'; } },
    utils: { toast(message) { toasts.push(String(message)); } },
    plugin: {
      config: { get() { return undefined; }, all() { return {}; } },
      i18n: {
        requestedLocale: 'en', locale: 'en', defaultLocale: 'en',
        t(key, vars = {}) { let value = catalog[key] || key; Object.keys(vars || {}).forEach((name) => { value = value.replace('{' + name + '}', vars[name]); }); return value; },
        onChange() { return () => {}; }
      },
      on(type, handler) { (hooks[type] || (hooks[type] = [])).push(handler); },
      onSidebarAction(id, handler) { sidebar[id] = handler; },
      onInputAction(id, handler) { inputActions[id] = handler; }
    }
  };
  return {
    tavo, books, regexes, themes, characters, presets, files, stores, hooks, sidebar, inputActions, toasts, reads, writes, exports,
    queueFileImport(value) { fileImportQueue.push(clone(value)); }
  };
}

function makeContext(tavo, width = 390, height = 844) {
  const dom = createDOM(width, height);
  const context = vm.createContext({
    window: dom.window, document: dom.document, tavo, console, Event: FakeEvent, CustomEvent: FakeCustomEvent,
    crypto: webcrypto, TextEncoder, Uint8Array,
    atob(value) { return Buffer.from(String(value), 'base64').toString('binary'); },
    setTimeout(fn, ms, ...args) { const timer = setTimeout(fn, ms, ...args); if (timer.unref) timer.unref(); return timer; },
    clearTimeout, Date, Math, JSON, Promise, Object, Array, String, Number, Boolean, RegExp, Error, TypeError,
    isFinite, parseFloat, parseInt
  });
  dom.window.Event = FakeEvent; dom.window.CustomEvent = FakeCustomEvent;
  return { context, ...dom };
}

function runFile(context, filename) {
  const source = fs.readFileSync(filename, 'utf8');
  return vm.runInContext(source, context, { filename });
}

function runFragment(context, filename) {
  const source = fs.readFileSync(filename, 'utf8');
  const scripts = Array.from(source.matchAll(/<script>([\s\S]*?)<\/script>/g)).map((match) => match[1]);
  if (!scripts.length) throw new Error('no script in fragment: ' + filename);
  scripts.forEach((script, index) => vm.runInContext(script, context, { filename: filename + '#script-' + index }));
}

async function waitFor(check, label, timeout = 3000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    try { const value = check(); if (value) return value; } catch (error) {}
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
  throw new Error('timeout waiting for ' + label);
}

function loadBooks(root) {
  return ['核心', '功能', '图鉴', '系统', '皮肤'].map((suffix) => JSON.parse(fs.readFileSync(path.join(root, 'out', 'Aster·' + suffix + '.json'), 'utf8')));
}

module.exports = { createTavo, makeContext, runFile, runFragment, waitFor, loadBooks, FakeEvent };
