'use strict';

const assert = require('assert');
const crypto = require('crypto');
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const FIXTURE = path.join(ROOT, 'out', 'Aster-complete-mod-fixture-1.1.0.zip');
// The organized handoff workspace can run without a writable /tmp. Keep
// ephemeral delta builds under reports/ and remove them in main()'s finally.
const DELTA_OUTPUT = fs.mkdtempSync(path.join(ROOT, 'reports', '.aster-mod-importer-deltas-'));
const DELTA = path.join(DELTA_OUTPUT, 'Aster-data-workbench-trash-delta-0.8.2.zip');
const SOCIAL_DELTA = path.join(DELTA_OUTPUT, 'Aster-social-terminal-delta-0.9.1.zip');
const DASHBOARD_DELTA = path.join(DELTA_OUTPUT, 'Aster-world-dashboard-fullscreen-delta-1.1.0.zip');
const ENTRY = path.join(ROOT, 'plugin-mod-importer', 'entry.js');
let checks = 0;
function check(value, message) { assert.ok(value, message); checks += 1; }
function equal(actual, expected, message) { assert.strictEqual(actual, expected, message); checks += 1; }
function deepEqual(actual, expected, message) { assert.deepStrictEqual(actual, expected, message); checks += 1; }
function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
function sha256(buffer) { return crypto.createHash('sha256').update(buffer).digest('hex'); }

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) crc = crc & 1 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function makeStoredZip(entries) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const [name, raw] of entries) {
    const nameBytes = Buffer.from(name, 'utf8');
    const content = Buffer.from(raw);
    const crc = crc32(content);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(content.length, 18);
    local.writeUInt32LE(content.length, 22);
    local.writeUInt16LE(nameBytes.length, 26);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(0x0314, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(content.length, 20);
    central.writeUInt32LE(content.length, 24);
    central.writeUInt16LE(nameBytes.length, 28);
    central.writeUInt32LE((0o100644 << 16) >>> 0, 38);
    central.writeUInt32LE(offset, 42);
    locals.push(local, nameBytes, content);
    centrals.push(central, nameBytes);
    offset += local.length + nameBytes.length + content.length;
  }
  const centralBytes = Buffer.concat(centrals);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralBytes.length, 12);
  eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, centralBytes, eocd]);
}

function normalizeEntries(entries) {
  if (Array.isArray(entries)) return clone(entries);
  return Object.keys(entries || {}).map((key) => clone(entries[key]));
}

function normalizeStoredEntity(value, entryKind) {
  const row = clone(value);
  if (['lorebook', 'preset', 'regex'].includes(entryKind)) row.entries = normalizeEntries(row.entries);
  if (entryKind === 'preset') {
    const platformDefaults = [
      { identifier: 'personaDescription', name: 'Persona Description', enabled: true, active: true, type: 'marker' },
      { identifier: 'scenario', name: 'Scenario', enabled: true, active: true, type: 'marker' }
    ];
    for (const entry of platformDefaults) {
      if (!row.entries.some((candidate) => candidate.identifier === entry.identifier)) row.entries.push(clone(entry));
    }
    row.basicPrompts = Object.assign({ persona: '{0}', scenario: '{0}' }, row.basicPrompts || {});
  }
  return row;
}

function createHost(options = {}) {
  let nextId = 100;
  const initialBook = { id: 1, name: 'Unrelated existing book', entries: [] };
  const lorebooks = [initialBook];
  const presets = [];
  const regexes = [];
  const characters = [];
  const themes = [];
  const sidebar = Object.create(null);
  const fileImports = [];
  const files = new Map();
  const variables = { chat: new Map(), global: new Map(), message: new Map() };
  const toasts = [];
  const exports = [];
  const asks = [];
  let themeImportCalls = 0;
  let ignoredZipDelete = false;
  let chat = { id: 7, name: 'Mod fixture chat', lorebooks: [{ id: 1, name: initialBook.name }], regexes: [], preset: null, theme: null };

  function makeCollection(storage, entryKind) {
    return {
      async all() { return storage.map((row) => ({ id: row.id, name: row.name, entries: row.entries ? row.entries.length : undefined })); },
      async get(id) { return clone(storage.find((row) => row.id === id) || null); },
      async find(name, findOptions = {}) {
        const match = findOptions.match || 'exact';
        return clone(storage.filter((row) => match === 'exact' ? row.name === name : row.name.includes(name)));
      },
      async create(value) {
        if (entryKind === 'regex' && options.failRegex) return null;
        const row = normalizeStoredEntity(value, entryKind);
        if (entryKind === 'preset' && options.corruptPreset) {
          const main = row.entries.find((entry) => entry.identifier === 'main');
          if (main) main.content = 'platform-corrupted-content';
        }
        row.id = nextId++;
        storage.push(row);
        return row.id;
      },
      async update(value) {
        if (entryKind === 'regex' && options.failRegex) return null;
        if (entryKind === 'lorebook' && options.failLorebookUpdateId != null && value.id === options.failLorebookUpdateId) return null;
        const index = storage.findIndex((row) => row.id === value.id);
        if (index < 0) throw new Error(entryKind + ' not found: ' + value.id);
        const row = normalizeStoredEntity(value, entryKind);
        storage[index] = row;
        return row.id;
      },
      async delete(id) {
        const target = id && id.id || id;
        const index = storage.findIndex((row) => row.id === target);
        if (index >= 0) storage.splice(index, 1);
      }
    };
  }

  const lorebookApi = makeCollection(lorebooks, 'lorebook');
  const presetApi = makeCollection(presets, 'preset');
  const regexApi = makeCollection(regexes, 'regex');
  const characterApi = makeCollection(characters, 'character');
  const themeApi = {
    async all() { return clone(themes); },
    async get(id) { return clone(themes.find((row) => row.id === id) || null); },
    async find(name) { return clone(themes.filter((row) => row.name === name)); },
    async create(value) {
      if (options.failPortableTheme && value.name === '[Fixture] Aster THM 主题') return null;
      const row = Object.assign({}, clone(value), { id: nextId++ });
      themes.push(row);
      return row.id;
    },
    async update(id, patch) {
      const index = themes.findIndex((row) => row.id === id);
      if (index < 0) throw new Error('theme not found: ' + id);
      themes[index] = Object.assign({}, themes[index], clone(patch), { id });
      return id;
    },
    async delete(id) { const index = themes.findIndex((row) => row.id === (id && id.id || id)); if (index >= 0) themes.splice(index, 1); },
    async import() {
      themeImportCalls += 1;
      if (options.rejectUnsupportedTheme !== false) throw new Error('Unsupported chat theme specification');
      const existing = themes.find((row) => row.name === '[Fixture] Aster THM 主题');
      if (existing) return existing.id;
      const row = { id: nextId++, name: '[Fixture] Aster THM 主题', imported: true };
      themes.push(row);
      return row.id;
    },
    async export(id) {
      const row = themes.find((value) => value.id === id);
      if (!row) throw new Error('theme not found: ' + id);
      const filePath = 'files/chat/theme-backup-' + id + '.thm';
      files.set(filePath, Buffer.from(JSON.stringify(row)));
      return { path: filePath };
    }
  };

  const catalog = {
    'runtime.selecting': 'Select ZIP',
    'runtime.cancelled': 'Cancelled',
    'runtime.preflighting': 'Preflight',
    'runtime.confirmQuestion': 'Import {name} {version} {items}/{creates}/{updates}/{skips}',
    'runtime.confirmImport': 'Import',
    'runtime.confirmCancel': 'Cancel',
    'runtime.committing': 'Commit {count}',
    'runtime.success': 'Success {name} {count}',
    'runtime.failed': 'Failed {message}',
    'runtime.busy': 'Busy',
    'runtime.noReceipt': 'No receipt',
    'runtime.receiptExported': 'Receipt exported'
  };

  const tavo = {
    get(key, scope = 'chat') { return clone(variables[scope].get(key)); },
    set(key, value, scope = 'chat') { variables[scope].set(key, clone(value)); return clone(value); },
    unset(key, scope = 'chat') { variables[scope].delete(key); },
    lorebook: lorebookApi,
    character: characterApi,
    preset: presetApi,
    regex: regexApi,
    theme: themeApi,
    chat: {
      async current() { return clone(chat); },
      async update(patch) {
        if (options.failChatUpdate) throw new Error('chat update unavailable');
        if (Object.prototype.hasOwnProperty.call(patch, 'lorebooks')) chat.lorebooks = patch.lorebooks.map((id) => ({ id, name: lorebooks.find((row) => row.id === id)?.name || 'book' }));
        if (Object.prototype.hasOwnProperty.call(patch, 'regexes')) chat.regexes = patch.regexes.map((id) => ({ id, name: regexes.find((row) => row.id === id)?.name || 'regex' }));
        if (Object.prototype.hasOwnProperty.call(patch, 'preset')) chat.preset = patch.preset == null ? null : { id: patch.preset, name: presets.find((row) => row.id === patch.preset)?.name || 'preset' };
        if (Object.prototype.hasOwnProperty.call(patch, 'theme')) chat.theme = patch.theme == null ? null : { id: patch.theme, name: themes.find((row) => row.id === patch.theme)?.name || 'theme' };
        return clone(chat);
      }
    },
    file: {
      async import() {
        const queued = fileImports.shift();
        if (!queued) return [];
        const base = queued.name.replace(/\.zip$/i, '');
        let name = queued.name;
        let index = 2;
        while (files.has('files/chat/' + name)) name = base + ' (' + index++ + ').zip';
        const filePath = 'files/chat/' + name;
        files.set(filePath, Buffer.from(queued.bytes));
        return [{ path: filePath, name, originalName: queued.name, size: queued.bytes.length, mimeType: 'application/zip' }];
      },
      async save(name, content, saveOptions = {}) {
        const scope = saveOptions.scope || 'chat';
        const filePath = String(name).startsWith('files/') ? String(name) : 'files/' + scope + '/' + name;
        const bytes = saveOptions.encoding === 'base64' ? Buffer.from(content, 'base64') : Buffer.from(String(content), 'utf8');
        files.set(filePath, bytes);
        return filePath;
      },
      async load(name, loadOptions = {}) {
        const filePath = String(name).startsWith('files/') ? String(name) : 'files/' + (loadOptions.scope || 'chat') + '/' + name;
        const bytes = files.get(filePath);
        if (!bytes) return null;
        return loadOptions.encoding === 'base64' ? bytes.toString('base64') : bytes.toString('utf8');
      },
      async delete(name, deleteOptions = {}) {
        const filePath = String(name).startsWith('files/') ? String(name) : 'files/' + (deleteOptions.scope || 'chat') + '/' + name;
        if (options.ignoreFirstFullPathZipDelete && !ignoredZipDelete && String(name).startsWith('files/chat/') && /\.zip$/i.test(String(name))) {
          ignoredZipDelete = true;
          return;
        }
        files.delete(filePath);
      },
      async exists(name, existsOptions = {}) {
        const filePath = String(name).startsWith('files/') ? String(name) : 'files/' + (existsOptions.scope || 'chat') + '/' + name;
        return files.has(filePath);
      },
      url(name, scope = 'chat') { return String(name).startsWith('files/') ? String(name) : 'files/' + scope + '/' + name; },
      async export(filePath) { exports.push(filePath); }
    },
    utils: {
      toast(text) { toasts.push(String(text)); },
      async ask(question) { asks.push(clone(question)); return { status: 'answered', answer: 'import', source: 'option' }; }
    },
    plugin: {
      config: {
        get(key) {
          if (key === 'confirmBeforeCommit') return true;
          if (key === 'activateCurrentChat') return true;
          if (key === 'deleteSourceAfterSuccess') return true;
          return null;
        }
      },
      i18n: {
        t(key, params = {}) {
          let value = catalog[key] || key;
          for (const [name, replacement] of Object.entries(params)) value = value.replace('{' + name + '}', String(replacement));
          return value;
        }
      },
      onSidebarAction(id, handler) { sidebar[id] = handler; }
    }
  };

  return {
    tavo, sidebar, fileImports, files, variables, toasts, exports, asks,
    lorebooks, characters, presets, regexes, themes,
    get chat() { return clone(chat); },
    get themeImportCalls() { return themeImportCalls; },
    queue(name, bytes) { fileImports.push({ name, bytes: Buffer.from(bytes) }); }
  };
}

function loadPlugin(host) {
  const context = vm.createContext({
    tavo: host.tavo,
    console,
    crypto: globalThis.crypto,
    atob: globalThis.atob,
    btoa: globalThis.btoa,
    Blob: globalThis.Blob,
    Response: globalThis.Response,
    DecompressionStream: globalThis.DecompressionStream,
    TextDecoder: globalThis.TextDecoder,
    Uint8Array,
    Uint32Array,
    DataView,
    ArrayBuffer,
    Map,
    Set,
    Date,
    Math,
    JSON,
    Object,
    Array,
    String,
    Number,
    Boolean,
    RegExp,
    Error,
    TypeError,
    Promise
  });
  vm.runInContext(fs.readFileSync(ENTRY, 'utf8'), context, { filename: ENTRY });
}

function fixtureManifest() {
  const output = execFileSync('python3', ['-c', [
    'import json,sys,zipfile',
    'with zipfile.ZipFile(sys.argv[1]) as z:',
    ' print(json.dumps(json.loads(z.read("aster-mod.json"))))'
  ].join('\n'), FIXTURE], { encoding: 'utf8' });
  return JSON.parse(output);
}

function zipJson(zipPath, member) {
  const output = execFileSync('python3', ['-c', [
    'import sys,zipfile',
    'with zipfile.ZipFile(sys.argv[1]) as z:',
    ' sys.stdout.buffer.write(z.read(sys.argv[2]))'
  ].join('\n'), zipPath, member]);
  return JSON.parse(output.toString('utf8'));
}

function moduleIdOf(entry) {
  const content = String(entry && entry.content || '');
  if (!content.includes('⟦aster·module⟧')) return '';
  const match = content.match(/(?:^|\n)@id\s+(aster\.[a-z0-9._-]+)\s*(?:\n|$)/i);
  return match ? match[1] : '';
}

function moduleDuplicates(books) {
  const groups = new Map();
  for (const book of books) for (const entry of normalizeEntries(book.entries)) {
    const id = moduleIdOf(entry);
    if (!id) continue;
    groups.set(id, (groups.get(id) || 0) + 1);
  }
  return Array.from(groups.entries()).filter(([, count]) => count > 1);
}

async function verifyAsterDeltaPackage(delta) {
  const manifest = zipJson(DELTA, 'aster-mod.json');
  equal(manifest.spec, 'aster.mod/v1', 'delta uses the verified Aster Mod package specification');
  equal(manifest.items.length, 3, 'delta declares only the three changed lorebook entries');
  equal(manifest.repair.asterModules, 'deduplicate', 'delta explicitly authorizes scoped Aster module deduplication');
  check(!manifest.activate, 'delta does not alter current-chat activation bindings');

  const host = createHost();
  const seeded = new Map();
  manifest.items.forEach((item, index) => {
    const payload = zipJson(DELTA, item.path);
    const expected = normalizeEntries(payload.entries)[0];
    const bookPath = path.join(ROOT, 'out', item.name + '.json');
    const book = JSON.parse(fs.readFileSync(bookPath, 'utf8'));
    book.id = 20 + index;
    book.entries = normalizeEntries(book.entries);
    const target = book.entries.find((row) => row.identifier === expected.identifier);
    check(target, 'baseline contains delta target entry: ' + expected.identifier);
    target.content = 'stale-before-delta:' + expected.identifier;
    target.name = '旧版待替换条目';
    const manual = {
      identifier: 'manual-delta-' + index,
      name: '用户自建条目 ' + index,
      content: '增量导入必须保留',
      enabled: false
    };
    book.entries.push(manual);
    const untouched = book.entries.filter((row) => row.identifier !== expected.identifier);
    seeded.set(item.name, { expected, manual, untouched: clone(untouched), count: book.entries.length, id: book.id });
    host.lorebooks.push(book);
    if (item.name === 'Aster·功能') {
      const duplicate = clone(book);
      duplicate.id = 70;
      duplicate.entries = duplicate.entries.filter((row) => moduleIdOf(row));
      const staleManual = { identifier: 'manual-from-old-version', name: '旧版本独有手工条目', content: '合并后必须迁入主书', enabled: false };
      duplicate.entries.push(staleManual);
      seeded.get(item.name).staleManual = staleManual;
      seeded.get(item.name).count += 1;
      host.lorebooks.push(duplicate);
    }
    if (item.name === 'Aster·皮肤') {
      const backup = clone(book);
      backup.id = 71;
      backup.name = 'Aster 皮肤历史备份';
      backup.entries = backup.entries.filter((row) => moduleIdOf(row));
      backup.entries.push({ identifier: 'backup-note', name: '备份说明', content: '不属于模块，不应删除', enabled: false });
      host.lorebooks.push(backup);
    }
  });
  check(moduleDuplicates(host.lorebooks).length > 0, 'device fixture reproduces duplicate Aster modules across same-name and backup books');
  const bookCountBefore = host.lorebooks.length;
  const chatBefore = host.chat;
  loadPlugin(host);
  host.queue(path.basename(DELTA), delta);
  const first = await host.sidebar['import-mod-package']();
  equal(first.status, 'success', 'entry-only delta imports successfully');
  equal(first.package.items, 3, 'delta receipt accounts for exactly three changed items');
  equal(first.operations.length, 5, 'delta records three writes, module repair, and exact-name old-version cleanup');
  check(first.operations.every((row) => row.verified), 'every delta and repair operation has readback verification');
  const repair = first.operations.find((row) => row.itemId === '$aster-module-repair');
  check(repair && repair.action === 'deduplicate' && repair.removed > 0, 'delta removes pre-existing duplicate module copies');
  check(repair.books.length >= 2, 'repair covers same-name and differently named backup books');
  equal(moduleDuplicates(host.lorebooks).length, 0, 'all Aster module IDs are unique after repair readback');
  const sameNameCleanup = first.operations.find((row) => row.itemId === '$same-name-cleanup');
  check(sameNameCleanup && sameNameCleanup.candidates === 1 && sameNameCleanup.deleted === 1, 'exact-name cleanup deletes the superseded duplicate world book after merge');
  equal(host.lorebooks.length, bookCountBefore - 1, 'the superseded exact-name book is removed while differently named backups remain');
  deepEqual(host.chat, chatBefore, 'delta leaves current-chat book, regex, preset, and theme bindings untouched');
  equal(first.sourceCleanup.status, 'deleted', 'delta source ZIP is deleted after verified success');
  check(!host.files.has('files/chat/' + path.basename(DELTA)), 'temporary delta ZIP copy is absent after import');

  for (const item of manifest.items) {
    const state = seeded.get(item.name);
    const targetBook = host.lorebooks.find((book) => book.id === state.id);
    equal(targetBook.name, item.name, 'delta updates the selected exact-name world book in place: ' + item.name);
    equal(targetBook.entries.length, state.count, 'delta changes no unrelated entry count: ' + item.name);
    const imported = targetBook.entries.filter((row) => row.identifier === state.expected.identifier);
    equal(imported.length, 1, 'changed identifier is unique after delta merge: ' + state.expected.identifier);
    deepEqual(imported[0], state.expected, 'changed entry matches the built source payload: ' + state.expected.identifier);
    state.untouched.forEach((untouched) => {
      deepEqual(targetBook.entries.find((row) => row.identifier === untouched.identifier), untouched, 'existing non-target entry remains unchanged: ' + untouched.identifier);
    });
    check(targetBook.entries.some((row) => row.identifier === state.manual.identifier), 'manual entry survives delta merge: ' + item.name);
    if (state.staleManual) deepEqual(targetBook.entries.find((row) => row.identifier === state.staleManual.identifier), state.staleManual, 'old-version-only manual entry is merged into the canonical book before deletion');
  }
  check(!host.lorebooks.some((book) => book.id === 70), 'deleted exact-name old version is absent by ID after readback');
  const historicalBackup = host.lorebooks.find((book) => book.id === 71);
  deepEqual(historicalBackup.entries, [{ identifier: 'backup-note', name: '备份说明', content: '不属于模块，不应删除', enabled: false }], 'repair removes only duplicate Aster modules and preserves backup notes');

  host.queue(path.basename(DELTA), delta);
  const second = await host.sidebar['import-mod-package']();
  equal(second.status, 'success', 'same delta is safely re-importable');
  equal(host.lorebooks.length, bookCountBefore - 1, 'second delta import creates no additional world book');
  const secondRepair = second.operations.find((row) => row.itemId === '$aster-module-repair');
  equal(secondRepair.action, 'verify-unique', 'second import verifies uniqueness without deleting anything');
  equal(secondRepair.removed, 0, 'second import has no repeated repair work');
  equal(moduleDuplicates(host.lorebooks).length, 0, 'second import keeps module IDs globally unique');
  for (const item of manifest.items) {
    const state = seeded.get(item.name);
    const book = host.lorebooks.find((row) => row.id === state.id);
    equal(book.entries.length, state.count, 'second import keeps entry count stable: ' + item.name);
    equal(book.entries.filter((row) => row.identifier === state.expected.identifier).length, 1, 'second import keeps changed entry unique: ' + item.name);
    check(book.entries.some((row) => row.identifier === state.manual.identifier), 'second import still preserves manual entry: ' + item.name);
  }
  equal(host.asks.length, 2, 'delta shows one consolidated confirmation per import');
}

async function verifyAsterRepairRollback(delta) {
  const manifest = zipJson(DELTA, 'aster-mod.json');
  const host = createHost({ failLorebookUpdateId: 71 });
  manifest.items.forEach((item, index) => {
    const book = JSON.parse(fs.readFileSync(path.join(ROOT, 'out', item.name + '.json'), 'utf8'));
    book.id = 20 + index;
    book.entries = normalizeEntries(book.entries);
    host.lorebooks.push(book);
    if (item.name === 'Aster·功能') {
      const duplicate = clone(book); duplicate.id = 70; host.lorebooks.push(duplicate);
    }
    if (item.name === 'Aster·皮肤') {
      const duplicate = clone(book); duplicate.id = 71; duplicate.name = 'Aster 皮肤回滚验证'; host.lorebooks.push(duplicate);
    }
  });
  const before = clone(host.lorebooks);
  loadPlugin(host);
  host.queue(path.basename(DELTA), delta);
  const result = await host.sidebar['import-mod-package']();
  equal(result.status, 'failed', 'repair write cancellation fails the whole delta transaction');
  equal(result.error.code, 'E_WRITE_CANCELLED', 'repair cancellation exposes a stable error code');
  check(result.rollback.length > 0 && result.rollback.every((row) => row.ok), 'repair failure compensates prior target writes and earlier repair writes');
  deepEqual(host.lorebooks, before, 'repair rollback restores every world book and duplicate entry exactly');
  check(host.files.has('files/chat/' + path.basename(DELTA)), 'failed repair retains its source ZIP for diagnosis and retry');
}

async function verifySocialTerminalDelta(delta) {
  const manifest = zipJson(SOCIAL_DELTA, 'aster-mod.json');
  equal(manifest.spec, 'aster.mod/v1', 'social terminal delta uses the verified Aster Mod specification');
  equal(manifest.items.length, 3, 'social terminal delta groups four changed modules into three canonical books');
  equal(manifest.repair.asterModules, 'deduplicate', 'social terminal delta requests scoped module deduplication');
  const host = createHost();
  const seeded = new Map();
  manifest.items.forEach((item, index) => {
    const payload = zipJson(SOCIAL_DELTA, item.path);
    const expected = normalizeEntries(payload.entries);
    const book = JSON.parse(fs.readFileSync(path.join(ROOT, 'out', item.name + '.json'), 'utf8'));
    book.id = 200 + index; book.entries = normalizeEntries(book.entries);
    expected.forEach((row) => {
      const target = book.entries.find((entry) => entry.identifier === row.identifier);
      check(target, 'social delta baseline contains target: ' + row.identifier);
      target.content = 'stale-social-module:' + row.identifier;
    });
    const manual = { identifier: 'manual-social-' + index, name: '用户通讯扩展 ' + index, content: '必须保留', enabled: false };
    book.entries.push(manual); host.lorebooks.push(book);
    seeded.set(item.name, { id: book.id, count: book.entries.length, expected, manual });
  });
  loadPlugin(host);
  host.queue(path.basename(SOCIAL_DELTA), delta);
  const first = await host.sidebar['import-mod-package']();
  equal(first.status, 'success', 'registered social terminal delta imports successfully');
  check(first.operations.every((row) => row.verified), 'social terminal delta verifies every write and repair operation');
  equal(moduleDuplicates(host.lorebooks).length, 0, 'social terminal import leaves all Aster module IDs unique');
  for (const item of manifest.items) {
    const state = seeded.get(item.name), book = host.lorebooks.find((row) => row.id === state.id);
    equal(book.entries.length, state.count, 'social delta preserves unrelated entry count: ' + item.name);
    state.expected.forEach((expected) => {
      const matches = book.entries.filter((row) => row.identifier === expected.identifier);
      equal(matches.length, 1, 'social changed module is unique after merge: ' + expected.identifier);
      deepEqual(matches[0], expected, 'social changed module matches built source: ' + expected.identifier);
    });
    deepEqual(book.entries.find((row) => row.identifier === state.manual.identifier), state.manual, 'social delta preserves manual entry: ' + item.name);
  }
  equal(first.sourceCleanup.status, 'deleted', 'verified social delta removes its temporary ZIP');
  host.queue(path.basename(SOCIAL_DELTA), delta);
  const second = await host.sidebar['import-mod-package']();
  equal(second.status, 'success', 'social terminal delta is idempotent');
  for (const item of manifest.items) {
    const state = seeded.get(item.name), book = host.lorebooks.find((row) => row.id === state.id);
    equal(book.entries.length, state.count, 'second social import keeps entry count stable: ' + item.name);
    state.expected.forEach((expected) => equal(book.entries.filter((row) => row.identifier === expected.identifier).length, 1, 'second social import keeps module unique: ' + expected.identifier));
  }
}

async function verifyDashboardDelta(delta) {
  const manifest = zipJson(DASHBOARD_DELTA, 'aster-mod.json');
  equal(manifest.spec, 'aster.mod/v1', 'fullscreen dashboard delta uses the verified Aster Mod specification');
  equal(manifest.items.length, 4, 'fullscreen dashboard delta contains Core, Function, System, and Skin changed entries');
  equal(manifest.repair.asterModules, 'deduplicate', 'fullscreen dashboard delta requests scoped module deduplication');
  const host = createHost();
  const seeded = new Map();
  manifest.items.forEach((item, index) => {
    const payload = zipJson(DASHBOARD_DELTA, item.path);
    const expected = normalizeEntries(payload.entries);
    const book = JSON.parse(fs.readFileSync(path.join(ROOT, 'out', item.name + '.json'), 'utf8'));
    book.id = 240 + index; book.entries = normalizeEntries(book.entries);
    expected.forEach((row) => {
      const target = book.entries.find((entry) => entry.identifier === row.identifier);
      check(target, 'dashboard delta baseline contains target: ' + row.identifier);
      target.content = 'stale-dashboard-module:' + row.identifier;
    });
    const manual = { identifier: 'manual-dashboard-' + index, name: '用户仪表盘扩展 ' + index, content: '必须保留', enabled: false };
    book.entries.push(manual); host.lorebooks.push(book);
    seeded.set(item.name, { id: book.id, count: book.entries.length, expected, manual });
  });
  loadPlugin(host);
  host.queue(path.basename(DASHBOARD_DELTA), delta);
  const first = await host.sidebar['import-mod-package']();
  equal(first.status, 'success', 'fullscreen dashboard delta imports successfully');
  check(first.operations.every((row) => row.verified), 'fullscreen dashboard delta verifies every write and repair operation');
  equal(first.sourceCleanup.status, 'deleted', 'verified dashboard delta removes its temporary ZIP');
  for (const item of manifest.items) {
    const state = seeded.get(item.name), book = host.lorebooks.find((row) => row.id === state.id);
    equal(book.entries.length, state.count, 'dashboard delta preserves unrelated entry count: ' + item.name);
    state.expected.forEach((expected) => {
      const matches = book.entries.filter((row) => row.identifier === expected.identifier);
      equal(matches.length, 1, 'dashboard changed module is unique after merge: ' + expected.identifier);
      deepEqual(matches[0], expected, 'dashboard changed module matches built source: ' + expected.identifier);
    });
    deepEqual(book.entries.find((row) => row.identifier === state.manual.identifier), state.manual, 'dashboard delta preserves manual entry: ' + item.name);
  }
  host.queue(path.basename(DASHBOARD_DELTA), delta);
  const second = await host.sidebar['import-mod-package']();
  equal(second.status, 'success', 'fullscreen dashboard delta is safely re-importable');
  equal(moduleDuplicates(host.lorebooks).length, 0, 'second dashboard import leaves every Aster module ID unique');
  for (const item of manifest.items) {
    const state = seeded.get(item.name), book = host.lorebooks.find((row) => row.id === state.id);
    equal(book.entries.length, state.count, 'second dashboard import keeps entry count stable: ' + item.name);
    state.expected.forEach((expected) => equal(book.entries.filter((row) => row.identifier === expected.identifier).length, 1, 'second dashboard import keeps module unique: ' + expected.identifier));
  }
}

async function verifySuccessAndIdempotence(fixture) {
  const host = createHost({ ignoreFirstFullPathZipDelete: true });
  loadPlugin(host);
  check(host.sidebar['import-mod-package'], 'native one-click Mod import action is registered');
  check(host.sidebar['export-last-receipt'], 'receipt export action is registered');
  host.queue('Aster-complete-mod-fixture-1.1.0.zip', fixture);
  const first = await host.sidebar['import-mod-package']();
  equal(first.status, 'success', 'all-format fixture imports successfully');
  equal(first.package.items, 21, 'receipt accounts for all 21 manifest items');
  equal(first.operations.length, 23, '21 item readbacks plus resource-book merge and chat activation are recorded');
  check(first.operations.every((row) => row.verified), 'every operation has explicit readback verification');
  equal(first.rollback.length, 0, 'successful import performs no rollback');
  equal(host.lorebooks.length, 8, 'six fixture books and one fixed resource book coexist with unrelated existing book');
  equal(host.presets.length, 1, 'preset is imported');
  equal(host.characters.length, 1, 'character card is imported');
  equal(host.characters[0].firstMes, '终端已连接。', 'character card fields survive semantic readback');
  check(host.presets[0].entries.length > 3, 'Tavo-style preset defaults are auto-filled during create');
  for (const identifier of ['main', 'worldInfoBefore', 'chatHistory']) {
    check(host.presets[0].entries.some((entry) => entry.identifier === identifier), 'explicit preset entry survives auto-fill: ' + identifier);
  }
  const presetOperation = first.operations.find((row) => row.itemId === 'preset-story');
  equal(presetOperation.entriesExpected, 3, 'receipt records explicit preset entry count');
  equal(presetOperation.entriesActual, 5, 'receipt records platform-expanded preset entry count');
  equal(host.regexes.length, 1, 'regex group is imported');
  equal(host.themes.length, 2, 'native JSON theme and portable THM theme are imported');
  equal(host.themeImportCalls, 0, 'raw ChatTheme package avoids the private native THM specification path');
  const portableTheme = host.themes.find((row) => row.name === '[Fixture] Aster THM 主题');
  equal(portableTheme.background.image, 'files/global/aster-fixture-map.svg', 'content-identical embedded theme image reuses the verified localized SVG');
  check(host.files.has(portableTheme.background.image), 'deduplicated portable-theme image exists in global storage');
  const themePackageOperation = first.operations.find((row) => row.itemId === 'theme-package');
  equal(themePackageOperation.format, 'portable', 'receipt distinguishes a portable raw ChatTheme package');
  equal(themePackageOperation.transport, 'tavo.theme.create', 'portable theme uses the documented create API');
  equal(themePackageOperation.assets, 1, 'receipt records localized embedded theme assets');
  equal(host.chat.lorebooks.length, 7, 'chat activation merges all fixture books without removing existing book');
  equal(host.chat.regexes.length, 1, 'chat activation binds imported regex');
  equal(host.chat.preset.id, host.presets[0].id, 'chat activation binds imported preset');
  equal(host.chat.theme.id, host.themes.find((row) => row.name === '[Fixture] Aster 本地主题').id, 'chat activation binds selected native theme');
  equal(host.variables.chat.get('aster.fixture.ready'), true, 'chat variable payload is written');
  equal(host.variables.chat.get('aster.fixture.wallpaper'), 'files/global/aster-fixture-wallpaper.png', 'variable resource token resolves to local Tavo path');
  const narrative = host.lorebooks.find((row) => row.name === '[Fixture] Aster·叙事书');
  check(narrative.entries[0].content.includes('files/global/aster-fixture-wallpaper.png'), 'lorebook resource token resolves before entity write');
  check(!narrative.entries[0].content.includes('{{aster.resource:'), 'no unresolved resource token reaches Tavo');
  const nativeTheme = host.themes.find((row) => row.name === '[Fixture] Aster 本地主题');
  equal(nativeTheme.background.image, 'files/global/aster-fixture-wallpaper.png', 'theme resource token resolves before theme write');
  check(host.files.has('files/global/aster-fixture-ui.ttf'), 'valid local font resource is present');
  check(host.files.has('files/global/aster-fixture-click.wav'), 'local audio resource is present');
  check(host.files.has('files/global/aster-fixture-loop.mp4'), 'local video resource is present');
  check(host.files.has('files/global/aster-fixture-wallpaper.png'), 'local image resource is present');
  check(host.files.has('files/global/aster-mod-last-receipt.json'), 'machine-readable receipt is persisted globally');
  check(!Array.from(host.files.keys()).some((name) => /Aster-complete-mod-fixture.*\.zip$/.test(name)), 'temporary selected ZIP copy is deleted after success');
  equal(first.sourceCleanup.status, 'deleted', 'source cleanup verifies deletion instead of assuming it');
  check(first.sourceCleanup.attempts.includes('name+chat-scope'), 'source cleanup falls back to filename plus chat scope when full-path deletion is ineffective');

  const globalResourceIndex = host.variables.global.get('aster.resource.index.v1');
  const chatResourceIndex = host.variables.chat.get('aster.resource.index.v1');
  const completeResourceIndex = globalResourceIndex.concat(chatResourceIndex);
  equal(completeResourceIndex.length, 9, 'standalone importer stores one canonical row for content-identical package and embedded-theme resources');
  check(completeResourceIndex.every((row) => row.name && row.storedName && row.path && row.localState === 'ready'), 'resource indexes have no empty names and record ready local render state');
  check(completeResourceIndex.some((row) => row.path === 'files/global/aster-fixture-map.svg' && (row.aliases || []).includes('aster-theme-theme-package-0-background.svg')), 'resource index preserves the skipped embedded-theme filename as a canonical alias');
  const resourceBook = host.lorebooks.find((row) => row.name === 'Aster·资源书');
  check(resourceBook, 'standalone importer creates the fixed Aster resource book');
  const resourceEntries = resourceBook.entries.filter((entry) => String(entry.identifier || '').startsWith('aster-resource:'));
  equal(resourceEntries.length, completeResourceIndex.length, 'resource book contains one non-triggering entry per indexed local resource');
  equal(new Set(resourceEntries.map((entry) => entry.identifier)).size, resourceEntries.length, 'resource-book identifiers are duplicate-free');
  check(resourceEntries.every((entry) => entry.enabled === false && /^\[(?:图片|音频|视频|字体|文本|文件)\] \S/.test(entry.name)), 'resource-book entries are disabled and use type-specific repaired display names');
  const persistedReceipt = JSON.parse(host.files.get('files/global/aster-mod-last-receipt.json').toString('utf8'));
  equal(persistedReceipt.sourceCleanup.status, 'deleted', 'receipt is persisted again after source cleanup readback');

  const manifest = fixtureManifest();
  for (const id of ['resource-png', 'resource-svg', 'resource-wav', 'resource-mp4', 'resource-font', 'resource-css', 'resource-json', 'resource-text', 'resource-ejs']) {
    const item = manifest.items.find((row) => row.id === id);
    const stored = host.files.get('files/' + (item.scope || 'global') + '/' + item.targetName);
    equal(sha256(stored), item.sha256, 'resource byte hash survives Tavo save/load: ' + id);
  }

  const manualEntry = { identifier: 'manual-user-entry', name: '用户手工条目', content: '不应被整书替换', enabled: false };
  narrative.entries.push(manualEntry);
  const incomingIdentity = clone(narrative.entries[0]);
  narrative.entries[0].identifier = 'legacy-' + incomingIdentity.identifier;
  const staleOnlyEntry = { identifier: 'stale-book-only-entry', name: '旧同名书独有条目', content: '清理旧书前必须汇入主书', enabled: false };
  const staleNarrative = clone(narrative);
  staleNarrative.id = 900;
  staleNarrative.entries.push(staleOnlyEntry);
  host.lorebooks.push(staleNarrative);
  host.presets.push(Object.assign({}, clone(host.presets[0]), { id: 901 }));
  host.regexes.push(Object.assign({}, clone(host.regexes[0]), { id: 902 }));
  host.characters.push(Object.assign({}, clone(host.characters[0]), { id: 903 }));
  host.themes.push(Object.assign({}, clone(nativeTheme), { id: 904 }));
  const resourceBookManual = { identifier: 'resource-book-manual-note', name: '资源书手工说明', content: '合并同名资源书时必须保留', enabled: false };
  const staleResourceBook = clone(resourceBook);
  staleResourceBook.id = 905;
  staleResourceBook.entries.push(resourceBookManual);
  host.lorebooks.push(staleResourceBook);
  host.queue('Aster-complete-mod-fixture-1.1.0.zip', fixture);
  const second = await host.sidebar['import-mod-package']();
  equal(second.status, 'success', 'same package can be imported a second time');
  equal(host.lorebooks.length, 8, 'second import updates books and the fixed resource book instead of duplicating them');
  equal(host.presets.length, 1, 'second import updates preset instead of duplicating it');
  equal(host.characters.length, 1, 'second import updates character instead of duplicating it');
  equal(host.regexes.length, 1, 'second import updates regex instead of duplicating it');
  equal(host.themes.length, 2, 'second import updates/skips themes instead of duplicating them');
  equal(host.themeImportCalls, 0, 'themePackage skip policy keeps the native import path unused');
  equal(host.chat.lorebooks.length, 7, 'merge activation remains duplicate-free on second import');
  check(host.lorebooks.find((row) => row.name === '[Fixture] Aster·叙事书').entries.some((entry) => entry.identifier === manualEntry.identifier), 'lorebook replace performs entry-level merge and preserves unrelated manual entries');
  const narrativeAfter = host.lorebooks.find((row) => row.name === '[Fixture] Aster·叙事书');
  equal(narrativeAfter.entries.filter((entry) => entry.name === incomingIdentity.name).length, 1, 'same-display-name lorebook entry replaces the changed legacy identifier instead of appending');
  equal(narrativeAfter.entries.find((entry) => entry.name === incomingIdentity.name).identifier, incomingIdentity.identifier, 'same-name entry is restored to the package identifier');
  deepEqual(narrativeAfter.entries.find((entry) => entry.identifier === staleOnlyEntry.identifier), staleOnlyEntry, 'unique entry from a superseded same-name book is merged into the canonical book');
  const resourceBookAfter = host.lorebooks.find((row) => row.name === 'Aster·资源书');
  equal(resourceBookAfter.entries.filter((entry) => String(entry.identifier || '').startsWith('aster-resource:')).length, resourceEntries.length, 'second import incrementally updates resource entries without duplicates');
  deepEqual(resourceBookAfter.entries.find((entry) => entry.identifier === resourceBookManual.identifier), resourceBookManual, 'fixed resource-book merge preserves notes from a superseded exact-name copy');
  const cleanup = second.operations.find((row) => row.itemId === '$same-name-cleanup');
  check(cleanup && cleanup.candidates === 6 && cleanup.deleted === 6 && cleanup.verified, 'second import deletes all superseded exact-name entity and resource-book versions');
  equal(host.lorebooks.filter((row) => row.name === '[Fixture] Aster·叙事书').length, 1, 'exact-name lorebook storage is canonicalized to one object');
  equal(host.lorebooks.filter((row) => row.name === 'Aster·资源书').length, 1, 'exact-name resource-book storage is canonicalized to one object');
  equal(host.presets.filter((row) => row.name === host.presets[0].name).length, 1, 'exact-name preset storage is canonicalized to one object');
  equal(host.characters.filter((row) => row.name === host.characters[0].name).length, 1, 'exact-name character storage is canonicalized to one object');
  equal(host.regexes.filter((row) => row.name === host.regexes[0].name).length, 1, 'exact-name regex storage is canonicalized to one object');
  equal(host.themes.filter((row) => row.name === nativeTheme.name).length, 1, 'exact-name theme storage is canonicalized to one object');
  equal(host.asks.length, 2, 'one consolidated preflight confirmation is shown per import');

  const exported = await host.sidebar['export-last-receipt']();
  equal(exported, true, 'last receipt exports through native file export');
  equal(host.exports.length, 1, 'receipt export opens one system share/save flow');
  return host;
}

async function verifyPreflightRejection(fixture) {
  const host = createHost();
  loadPlugin(host);
  const malicious = makeStoredZip([['../escape.txt', Buffer.from('no')]]);
  host.queue('malicious.zip', malicious);
  const result = await host.sidebar['import-mod-package']();
  equal(result.status, 'failed', 'unsafe archive fails');
  equal(result.error.code, 'E_ZIP_PATH', 'path traversal is rejected before payload processing');
  equal(host.lorebooks.length, 1, 'preflight rejection leaves entity storage untouched');
  equal(host.presets.length, 0, 'preflight rejection creates no preset');
  equal(host.characters.length, 0, 'preflight rejection creates no character');
  equal(host.regexes.length, 0, 'preflight rejection creates no regex');
  equal(host.themes.length, 0, 'preflight rejection creates no theme');

  const trailing = Buffer.concat([fixture, Buffer.from([0])]);
  host.queue('trailing-data.zip', trailing);
  const trailingResult = await host.sidebar['import-mod-package']();
  equal(trailingResult.status, 'failed', 'ZIP with appended bytes fails');
  equal(trailingResult.error.code, 'E_ZIP_TRAILING_DATA', 'trailing ZIP data is rejected');
  equal(host.lorebooks.length, 1, 'second preflight rejection still leaves entities untouched');
}

async function verifyRollback(fixture) {
  const host = createHost({ failRegex: true });
  loadPlugin(host);
  host.queue('rollback-fixture.zip', fixture);
  const result = await host.sidebar['import-mod-package']();
  equal(result.status, 'failed', 'late native API cancellation fails the import');
  equal(result.error.code, 'E_WRITE_CANCELLED', 'native cancellation has a stable error code');
  check(result.rollback.length > 0, 'failed import records compensating rollback operations');
  check(result.rollback.every((row) => row.ok), 'all compensating rollback operations succeed');
  equal(host.lorebooks.length, 1, 'rollback removes all six newly created fixture books');
  equal(host.presets.length, 0, 'rollback removes newly created preset');
  equal(host.characters.length, 0, 'rollback removes newly created character');
  equal(host.regexes.length, 0, 'cancelled regex leaves no regex');
  equal(host.themes.length, 0, 'failure before theme stage leaves no themes');
  equal(host.variables.chat.size, 0, 'failure before variable stage leaves no variables');
  check(!host.files.has('files/global/aster-fixture-wallpaper.png'), 'rollback removes already written global resources');
  check(host.files.has('files/chat/rollback-fixture.zip'), 'source ZIP is preserved after failure for diagnosis');
  check(host.files.has('files/global/aster-mod-last-receipt.json'), 'failure receipt is still persisted');
}

async function verifyPresetSemanticGuard(fixture) {
  const host = createHost({ corruptPreset: true });
  loadPlugin(host);
  host.queue('corrupt-preset-fixture.zip', fixture);
  const result = await host.sidebar['import-mod-package']();
  equal(result.status, 'failed', 'preset content mutation fails semantic readback');
  equal(result.error.code, 'E_READBACK_PRESET_FIELD', 'preset field mutation has a stable error code');
  check(result.rollback.length > 0 && result.rollback.every((row) => row.ok), 'preset semantic failure rolls back cleanly');
  equal(host.lorebooks.length, 1, 'preset semantic failure removes all newly created books');
  equal(host.presets.length, 0, 'preset semantic failure removes the corrupted preset');
  check(!host.files.has('files/global/aster-fixture-wallpaper.png'), 'preset semantic failure removes written resources');
}

async function verifyPortableThemeRollback(fixture) {
  const host = createHost({ failPortableTheme: true });
  loadPlugin(host);
  host.queue('portable-theme-rollback.zip', fixture);
  const result = await host.sidebar['import-mod-package']();
  equal(result.status, 'failed', 'portable theme cancellation fails the complete transaction');
  equal(result.error.code, 'E_WRITE_CANCELLED', 'portable theme cancellation has a stable error code');
  check(result.rollback.length > 0 && result.rollback.every((row) => row.ok), 'portable theme failure rolls back every completed stage');
  equal(host.lorebooks.length, 1, 'portable theme rollback removes imported books');
  equal(host.presets.length, 0, 'portable theme rollback removes imported preset');
  equal(host.regexes.length, 0, 'portable theme rollback removes imported regex');
  equal(host.themes.length, 0, 'portable theme rollback removes the earlier native JSON theme');
  check(!host.files.has('files/global/aster-theme-theme-package-0-background.svg'), 'portable theme rollback removes its localized embedded asset');
  check(!host.files.has('files/global/aster-fixture-wallpaper.png'), 'portable theme rollback removes prior outer resources');
}

async function verifyCatalogRollback(fixture) {
  const host = createHost({ failChatUpdate: true });
  loadPlugin(host);
  host.queue('catalog-rollback.zip', fixture);
  const result = await host.sidebar['import-mod-package']();
  equal(result.status, 'failed', 'activation failure after resource-book sync fails the transaction');
  check(result.rollback.length > 0 && result.rollback.every((row) => row.ok), 'resource catalog and earlier stages roll back cleanly');
  equal(host.lorebooks.length, 1, 'resource book and fixture books are removed by rollback');
  check(!host.variables.global.has('aster.resource.index.v1'), 'global resource index is restored to absent');
  check(!host.variables.chat.has('aster.resource.index.v1'), 'chat resource index is restored to absent');
  check(host.files.has('files/chat/catalog-rollback.zip'), 'failed import retains its source ZIP for diagnosis');
}

async function main() {
  try {
    const deltaEnvironment = Object.assign({}, process.env, { ASTER_DELTA_OUTPUT_DIR: DELTA_OUTPUT });
    execFileSync('python3', [path.join(ROOT, 'tools', 'build_delta_patch.py')], { cwd: ROOT, env: deltaEnvironment });
    execFileSync('python3', [path.join(ROOT, 'tools', 'build_social_terminal_delta.py')], { cwd: ROOT, env: deltaEnvironment });
    execFileSync('python3', [path.join(ROOT, 'tools', 'build_dashboard_fullscreen_delta.py')], { cwd: ROOT, env: deltaEnvironment });
    const fixture = fs.readFileSync(FIXTURE);
    const delta = fs.readFileSync(DELTA);
    const socialDelta = fs.readFileSync(SOCIAL_DELTA);
    const dashboardDelta = fs.readFileSync(DASHBOARD_DELTA);
    check(fixture.length > 0, 'complex fixture ZIP exists');
    check(delta.length > 0, 'entry-only Aster delta ZIP exists');
    check(socialDelta.length > 0, 'registered social terminal delta ZIP exists');
    check(dashboardDelta.length > 0, 'fullscreen dashboard delta ZIP exists');
    await verifyAsterDeltaPackage(delta);
    await verifyAsterRepairRollback(delta);
    await verifySocialTerminalDelta(socialDelta);
    await verifyDashboardDelta(dashboardDelta);
    await verifySuccessAndIdempotence(fixture);
    await verifyPreflightRejection(fixture);
    await verifyRollback(fixture);
    await verifyPresetSemanticGuard(fixture);
    await verifyPortableThemeRollback(fixture);
    await verifyCatalogRollback(fixture);

    const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'plugin-mod-importer', 'manifest.json'), 'utf8'));
    equal(manifest.specVersion, 2, 'plugin uses manifest v2');
    equal(manifest.version, '1.4.0', 'plugin minor version identifies exact-name merge and old-version cleanup');
    equal(manifest.minAppVersion, '1.0.0', 'plugin declares the API floor required by native ask');
    deepEqual(manifest.permissions, ['file', 'variable'], 'plugin declares only required documented permissions');
    const source = fs.readFileSync(ENTRY, 'utf8');
    check(!/window\.tavo|globalThis\.tavo/.test(source), 'plugin uses official unqualified tavo binding');
    check(!/\bfetch\s*\(|XMLHttpRequest|https?:\/\//.test(source), 'import path has no network dependency');
    check(!/\beval\s*\(|new Function/.test(source), 'importer never executes package content');

    const report = {
      ok: true,
      checks,
      fixtureBytes: fixture.length,
      manifestItems: 21,
      deltaItems: 3,
      deltaLorebookMerge: true,
      socialDeltaItems: 3,
      socialDeltaModules: 4,
      dashboardDeltaItems: 4,
      dashboardDeltaModules: 4,
      historicalDeltaOutputsUntouched: true,
      contentTypes: ['resource', 'character', 'lorebook', 'preset', 'regex', 'theme', 'themePackage', 'variables'],
      resourceFormats: ['png', 'svg', 'wav', 'mp4', 'ttf', 'css', 'json', 'txt', 'ejs'],
      idempotent: true,
      rollback: true,
      presetAutoFill: true,
      presetSemanticReadback: true,
      portableThemeFallback: true,
      embeddedThemeAssets: true,
      resourceBook: true,
      incrementalLorebooks: true,
      exactNameReplacement: true,
      sameNameEntryReplacement: true,
      staleVersionCleanup: true,
      verifiedSourceCleanup: true,
      realTavoDevice: false
    };
    fs.writeFileSync(path.join(ROOT, 'reports', 'mod-importer-test-results.json'), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify(report));
  } finally {
    fs.rmSync(DELTA_OUTPUT, { recursive: true, force: true });
  }
}

main().catch((error) => { console.error(error.stack || error); process.exitCode = 1; });
