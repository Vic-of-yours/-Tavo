'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');
const REPORT = path.join(ROOT, 'reports', 'mod-importer-browser-test-results.json');
const fixture = fs.readFileSync(path.join(ROOT, 'out', 'Aster-complete-mod-fixture-1.1.0.zip'));
const entry = fs.readFileSync(path.join(ROOT, 'plugin-mod-importer', 'entry.js'), 'utf8');
let checks = 0;
function check(value, message) { assert.ok(value, message); checks += 1; }
function equal(actual, expected, message) { assert.strictEqual(actual, expected, message); checks += 1; }
function scriptSafe(value) { return String(value).replace(/<\/script/gi, '<\\/script'); }

function pageSource() {
  const fixture64 = fixture.toString('base64');
  const mock = `(function () {
    let nextId = 10;
    const files = new Map();
    const stores = { chat: new Map(), global: new Map(), message: new Map() };
    const books = [];
    const presets = [];
    const characters = [];
    const regexes = [];
    const themes = [];
    const sidebar = {};
    let sourceAvailable = true;
    let chat = { id: 1, lorebooks: [], regexes: [], preset: null, theme: null };
    const clone = (value) => value == null ? value : JSON.parse(JSON.stringify(value));
    const idOf = (value) => value && typeof value === 'object' ? value.id : value;
    function collection(rows) {
      return {
        async all() { return clone(rows); },
        async get(id) { return clone(rows.find((row) => row.id === id) || null); },
        async find(name) { return clone(rows.filter((row) => row.name === name)); },
        async create(value) { const row = Object.assign(clone(value), { id: nextId++ }); rows.push(row); return row.id; },
        async update(value) { const index = rows.findIndex((row) => row.id === value.id); rows[index] = clone(value); return value.id; },
        async delete(id) { const index = rows.findIndex((row) => row.id === idOf(id)); if (index >= 0) rows.splice(index, 1); }
      };
    }
    const bookApi = collection(books);
    const presetApi = collection(presets);
    const characterApi = collection(characters);
    const regexApi = collection(regexes);
    const themeApi = collection(themes);
    themeApi.update = async function (id, patch) { const index = themes.findIndex((row) => row.id === id); themes[index] = Object.assign({}, themes[index], clone(patch), { id }); return id; };
    themeApi.import = async function () { const row = { id: nextId++, name: '[Fixture] Aster THM 主题' }; themes.push(row); return row.id; };
    themeApi.export = async function (id) { const path = 'files/chat/theme-backup-' + id + '.thm'; files.set(path, { content: '', encoding: 'base64' }); return { path }; };
    window.tavo = {
      get(key, scope = 'chat') { return clone(stores[scope].get(key)); },
      set(key, value, scope = 'chat') { stores[scope].set(key, clone(value)); return clone(value); },
      unset(key, scope = 'chat') { stores[scope].delete(key); },
      lorebook: bookApi,
      character: characterApi,
      preset: presetApi,
      regex: regexApi,
      theme: themeApi,
      chat: {
        async current() { return clone(chat); },
        async update(patch) {
          if ('lorebooks' in patch) chat.lorebooks = patch.lorebooks.map((id) => ({ id }));
          if ('regexes' in patch) chat.regexes = patch.regexes.map((id) => ({ id }));
          if ('preset' in patch) chat.preset = patch.preset == null ? null : { id: patch.preset };
          if ('theme' in patch) chat.theme = patch.theme == null ? null : { id: patch.theme };
          return clone(chat);
        }
      },
      file: {
        async import() {
          if (!sourceAvailable) return [];
          sourceAvailable = false;
          const path = 'files/chat/Aster-complete-mod-fixture-1.1.0.zip';
          files.set(path, { content: '${fixture64}', encoding: 'base64' });
          return [{ path, name: 'Aster-complete-mod-fixture-1.1.0.zip', originalName: 'Aster-complete-mod-fixture-1.1.0.zip', size: ${fixture.length}, mimeType: 'application/zip' }];
        },
        async save(name, content, options = {}) {
          const path = String(name).startsWith('files/') ? String(name) : 'files/' + (options.scope || 'chat') + '/' + name;
          files.set(path, { content, encoding: options.encoding || 'utf8' });
          return path;
        },
        async load(name, options = {}) {
          const path = String(name).startsWith('files/') ? String(name) : 'files/' + (options.scope || 'chat') + '/' + name;
          const row = files.get(path);
          if (!row) return null;
          if (options.encoding === 'base64') {
            if (row.encoding === 'base64') return row.content;
            return btoa(unescape(encodeURIComponent(row.content)));
          }
          return row.content;
        },
        async delete(name, options = {}) { const path = String(name).startsWith('files/') ? String(name) : 'files/' + (options.scope || 'chat') + '/' + name; files.delete(path); },
        async exists(name, options = {}) { const path = String(name).startsWith('files/') ? String(name) : 'files/' + (options.scope || 'chat') + '/' + name; return files.has(path); },
        url(name, scope = 'chat') { return String(name).startsWith('files/') ? String(name) : 'files/' + scope + '/' + name; },
        async export() {}
      },
      utils: {
        toast() {},
        async ask() { return { status: 'answered', answer: 'import', source: 'option' }; }
      },
      plugin: {
        config: { get(key) { return key === 'deleteSourceAfterSuccess' || key === 'confirmBeforeCommit' || key === 'activateCurrentChat'; } },
        i18n: { t(key) { return key; } },
        onSidebarAction(id, handler) { sidebar[id] = handler; }
      }
    };
    window.__modHost = { sidebar, files, books, characters, presets, regexes, themes, stores, getChat: () => clone(chat) };
  }());`;
  return '<!doctype html><html><head><meta charset="utf-8"></head><body><script>' + scriptSafe(mock) + '</script><script>' + scriptSafe(entry) + '</script></body></html>';
}

async function main() {
  const executablePath = chromium.executablePath();
  if (!fs.existsSync(executablePath)) {
    const skipped = { ok: null, skipped: true, realBrowser: false, realTavoDevice: false, reason: 'Playwright Chromium executable is not installed' };
    fs.writeFileSync(REPORT, JSON.stringify(skipped, null, 2) + '\n');
    console.log(JSON.stringify(skipped));
    return;
  }
  const browser = await chromium.launch({ headless: true, executablePath, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
    await page.setContent(pageSource(), { waitUntil: 'load' });
    const capabilities = await page.evaluate(() => ({
      decomposition: typeof DecompressionStream === 'function',
      raw: (() => { try { new DecompressionStream('deflate-raw'); return true; } catch (error) { return false; } })(),
      crypto: !!(crypto && crypto.subtle)
    }));
    check(capabilities.decomposition, 'Chromium exposes DecompressionStream');
    check(capabilities.raw, 'Chromium accepts deflate-raw ZIP streams');
    check(capabilities.crypto, 'Chromium exposes Web Crypto SHA-256');
    const result = await page.evaluate(async () => {
      const receipt = await window.__modHost.sidebar['import-mod-package']();
      return {
        status: receipt.status,
        error: receipt.error || null,
        items: receipt.package && receipt.package.items,
        operations: receipt.operations.length,
        books: window.__modHost.books.length,
        characters: window.__modHost.characters.length,
        presets: window.__modHost.presets.length,
        regexes: window.__modHost.regexes.length,
        themes: window.__modHost.themes.length,
        chat: window.__modHost.getChat(),
        receiptSaved: window.__modHost.files.has('files/global/aster-mod-last-receipt.json'),
        sourceDeleted: !window.__modHost.files.has('files/chat/Aster-complete-mod-fixture-1.1.0.zip')
      };
    });
    equal(result.status, 'success', 'all-format ZIP imports inside real Chromium');
    equal(result.items, 21, 'browser receipt accounts for all manifest items');
    equal(result.operations, 23, 'browser performs all item readbacks, resource-book sync, and activation');
    equal(result.books, 7, 'browser mock receives six lorebooks and the fixed resource book');
    equal(result.characters, 1, 'browser mock receives character card');
    equal(result.presets, 1, 'browser mock receives preset');
    equal(result.regexes, 1, 'browser mock receives regex');
    equal(result.themes, 2, 'browser mock receives both theme formats');
    equal(result.chat.lorebooks.length, 6, 'browser activation binds all fixture books');
    check(result.receiptSaved, 'browser path persists receipt');
    check(result.sourceDeleted, 'browser path removes temporary ZIP after success');
    await page.close();
  } finally {
    await browser.close();
  }
  const report = { ok: true, checks, realBrowser: true, realTavoDevice: false, viewport: { width: 390, height: 844 }, fixtureBytes: fixture.length };
  fs.writeFileSync(REPORT, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report));
}

main().catch((error) => { console.error(error.stack || error); process.exitCode = 1; });
