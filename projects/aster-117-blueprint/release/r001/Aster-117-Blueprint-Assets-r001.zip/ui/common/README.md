# Aster 跨世界通用 UI 素材 1.0.0

本目录只包含可跨世界 Mod 复用的视觉件，不包含人物、地点、地图内容、玩法场景、帖子/直播封面或可变文字。

## 目录

- `icons/`：60 个独立 `currentColor` SVG 与 `aster-icons.svg` symbol sprite。
- `masks/`：6 个可伸缩控件遮罩与总定义文件。
- `wallpapers/`：3 张 1440 × 3200 sRGB WebP 壁纸。
- `textures/`：噪点、微网格、电路线、扫描线四张无缝 alpha 母版。
- `decor/`：8 个终端装饰 symbol。
- `motion/`：脉冲环帧图、透明粒子 WebP、故障扫光 WebP，以及每组静态 fallback。
- `工作区/04_REFERENCE_ASSETS/Aster通用UI素材/production-sources/`：三张壁纸的高质量 WebP 生成源与提示词记录；不进入运行时 Mod，也不在本目录保留副本。
- `asset-catalog.json`：尺寸、字节数和 SHA-256 清单。
- `SHA256SUMS.txt`：82 个运行时文件与清单文件的校验值。

## 构建与验收

```bash
/data/data/com.termux/files/usr/bin/bash ../../06_TOOLING/run-common-ui-python.sh tools/build_common_ui_assets.py
/data/data/com.termux/files/usr/bin/bash ../../06_TOOLING/run-common-ui-python.sh tools/verify_common_ui_assets.py
```

构建临时生成 `out/Aster-common-ui-assets-1.0.0.zip`；它是一次性载入包，导入并回读成功后应删除。包规范为 `aster.mod/v1`，包 ID 为 `io.aster.ui.common-assets`。可调用备份另行管理，不以载入包充当备份。

## 接入原则

- 图标颜色、hover/focus/disabled 状态由 Skin 控制；SVG 不烘焙主题色。
- 壁纸通过 `Aster.assets` 注册后绑定既有 `phone.wallpaper` 三个值；CSS 渐变继续作为未安装/失败 fallback。
- SVG 纹理优先作为 `mask-image` 使用，由 CSS token 着色。
- 动图不是信息载体；`prefers-reduced-motion` 或 Aster reduced motion 状态下改用同名静态 fallback。
- 本素材包导入后只安装本地资源。它不会自行修改当前五书，也不会在未接入前改变 UI。

## 资产来源

图标、遮罩、纹理、装饰与动效由本项目生成脚本原创生成；三张壁纸使用内置图像生成流程制作并经人工裁切/对象修正。未复制参考插件或第三方图标库代码。
